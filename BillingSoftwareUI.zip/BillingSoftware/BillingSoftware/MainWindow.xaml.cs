﻿using BillingSoftware.Pages;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;

namespace BillingSoftware
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoadPage(UserControl page)
        {
            MainContent.Children.Clear();
            MainContent.Children.Add(page);
        }

        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new DashboardPage());
        }

        private void Billing_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new BillingPage());
        }

        private void Customers_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new CustomersPage());
        }

        private void Products_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new ProductsPage());
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new ReportsPage());
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new SettingsPage());
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new LoginPage());
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            LoadPage(new RegisterPage());

        }
    }
}
