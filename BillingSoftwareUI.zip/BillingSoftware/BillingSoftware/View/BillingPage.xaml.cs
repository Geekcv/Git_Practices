﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BillingSoftware.Pages
{
    public partial class BillingPage : UserControl
    {
        public ObservableCollection<Product1> Products { get; set; }
        public ObservableCollection<Product1> BillingItems { get; set; }

        public BillingPage()
        {
            InitializeComponent();
            Products = new ObservableCollection<Product1>
            {
                new Product1 { ProductId = 1, Name = "Laptop", Price = 50000 },
                new Product1 { ProductId = 2, Name = "Mouse", Price = 800 },
                new Product1 { ProductId = 3, Name = "Keyboard", Price = 1500 },
                new Product1 { ProductId = 4, Name = "Monitor", Price = 12000 }
            };
            BillingItems = new ObservableCollection<Product1>();
            BillingGrid.ItemsSource = BillingItems;
        }

        private void SearchProduct_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            string searchText = SearchBox.Text.ToLower();
            var filteredProducts = Products.Where(p => p.Name.ToLower().Contains(searchText)).ToList();

            if (filteredProducts.Count > 0)
            {
                MessageBox.Show($"Matching Products: {string.Join(", ", filteredProducts.Select(p => p.Name))}");
            }
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            string searchText = SearchBox.Text.ToLower();
            var selectedProduct = Products.FirstOrDefault(p => p.Name.ToLower().Contains(searchText));

            if (selectedProduct != null)
            {
                var existingProduct = BillingItems.FirstOrDefault(p => p.ProductId == selectedProduct.ProductId);

                if (existingProduct != null)
                {
                    existingProduct.Quantity++;
                    existingProduct.Total = existingProduct.Price * existingProduct.Quantity;
                }
                else
                {
                    BillingItems.Add(new Product1
                    {
                        ProductId = selectedProduct.ProductId,
                        Name = selectedProduct.Name,
                        Price = selectedProduct.Price,
                        Quantity = 1,
                        Total = selectedProduct.Price
                    });
                }

                BillingGrid.ItemsSource = null;
                BillingGrid.ItemsSource = BillingItems;
                UpdateTotalAmount();
            }
            else
            {
                MessageBox.Show("Product not found!");
            }
        }

        private void RemoveProduct_Click(object sender, RoutedEventArgs e)
        {
            if (BillingGrid.SelectedItem is Product1 selectedProduct)
            {
                BillingItems.Remove(selectedProduct);
                UpdateTotalAmount();
            }
            else
            {
                MessageBox.Show("Please select a product to remove.");
            }
        }

        private void UpdateTotalAmount()
        {
            decimal totalAmount = BillingItems.Sum(p => p.Total);
            TotalAmountText.Text = totalAmount.ToString("F2");
        }

        private void GenerateInvoice_Click(object sender, RoutedEventArgs e)
        {
            if (BillingItems.Count == 0)
            {
                MessageBox.Show("Please add products to the bill.");
                return;
            }

            string invoiceDetails = "Invoice:\n";
            foreach (var item in BillingItems)
            {
                invoiceDetails += $"{item.Name} x {item.Quantity} = {item.Total:C}\n";
            }
            invoiceDetails += $"\nTotal: {TotalAmountText.Text}";

            MessageBox.Show(invoiceDetails, "Invoice Generated");
        }
    }

    public class Product1
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; } = 1;
        public decimal Total { get; set; }
    }
}
