﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BillingSoftware.Pages
{
    public partial class CustomersPage : UserControl
    {
        public ObservableCollection<Customer> Customers { get; set; }
        private Customer _selectedCustomer;
        private bool _isEditing = false;

        public CustomersPage()
        {
            InitializeComponent();
            Customers = new ObservableCollection<Customer>
            {
                new Customer { CustomerId = 1, Name = "John Doe", Email = "john@example.com", Phone = "9876543210", Address = "New York, USA" },
                new Customer { CustomerId = 2, Name = "Jane Smith", Email = "jane@example.com", Phone = "9988776655", Address = "London, UK" },
                new Customer { CustomerId = 3, Name = "Michael Brown", Email = "michael@example.com", Phone = "8899776655", Address = "Sydney, Australia" }
            };
            CustomersGrid.ItemsSource = Customers;
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string searchText = SearchBox.Text.ToLower();
            CustomersGrid.ItemsSource = string.IsNullOrEmpty(searchText)
                ? Customers
                : new ObservableCollection<Customer>(Customers.Where(c => c.Name.ToLower().Contains(searchText)));
        }

        private void ShowAddCustomerPopup(object sender, RoutedEventArgs e)
        {
            _isEditing = false;
            _selectedCustomer = null;
            NameBox.Text = "";
            EmailBox.Text = "";
            PhoneBox.Text = "";
            AddressBox.Text = "";
            PopupGrid.Visibility = Visibility.Visible;
        }

        private void EditCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (CustomersGrid.SelectedItem is Customer customer)
            {
                _isEditing = true;
                _selectedCustomer = customer;
                NameBox.Text = customer.Name;
                EmailBox.Text = customer.Email;
                PhoneBox.Text = customer.Phone;
                AddressBox.Text = customer.Address;
                PopupGrid.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Please select a customer to edit.");
            }
        }

        private void SaveCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text) ||
                string.IsNullOrWhiteSpace(EmailBox.Text) ||
                string.IsNullOrWhiteSpace(PhoneBox.Text) ||
                string.IsNullOrWhiteSpace(AddressBox.Text))
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            if (_isEditing && _selectedCustomer != null)
            {
                // Update existing customer
                _selectedCustomer.Name = NameBox.Text;
                _selectedCustomer.Email = EmailBox.Text;
                _selectedCustomer.Phone = PhoneBox.Text;
                _selectedCustomer.Address = AddressBox.Text;
            }
            else
            {
                // Add new customer
                int newId = Customers.Count > 0 ? Customers.Max(c => c.CustomerId) + 1 : 1;
                Customers.Add(new Customer
                {
                    CustomerId = newId,
                    Name = NameBox.Text,
                    Email = EmailBox.Text,
                    Phone = PhoneBox.Text,
                    Address = AddressBox.Text
                });
            }

            CustomersGrid.ItemsSource = null;
            CustomersGrid.ItemsSource = Customers;
            PopupGrid.Visibility = Visibility.Collapsed;
        }

        private void DeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (CustomersGrid.SelectedItem is Customer customer)
            {
                if (MessageBox.Show("Are you sure you want to delete this customer?", "Confirm Delete", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Customers.Remove(customer);
                    CustomersGrid.ItemsSource = null;
                    CustomersGrid.ItemsSource = Customers;
                }
            }
            else
            {
                MessageBox.Show("Please select a customer to delete.");
            }
        }

        private void ClosePopup(object sender, RoutedEventArgs e)
        {
            PopupGrid.Visibility = Visibility.Collapsed;
        }
    }

    public class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }
}
