﻿using System.Windows.Controls;

namespace BillingSoftware.Pages
{
    public partial class DashboardPage : UserControl
    {
        public DashboardPage()
        {
            InitializeComponent();
        }

        private void GenerateReportButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }

        private void ViewOrdersButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }

        private void ManageCustomersButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }
    }
}
