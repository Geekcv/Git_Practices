﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BillingSoftware.Pages
{
    public partial class ProductsPage : UserControl
    {
        public ObservableCollection<Product> Products { get; set; }
        private Product _selectedProduct;
        private bool _isEditing = false;

        public ProductsPage()
        {
            InitializeComponent();
            Products = new ObservableCollection<Product>
            {
                new Product { ProductId = 1, ProductName = "Laptop", Category = "Electronics", Price = 50000, Stock = 10 },
                new Product { ProductId = 2, ProductName = "Mobile Phone", Category = "Electronics", Price = 20000, Stock = 15 },
                new Product { ProductId = 3, ProductName = "Headphones", Category = "Accessories", Price = 3000, Stock = 25 }
            };
            ProductsGrid.ItemsSource = Products;
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string searchText = SearchBox.Text.ToLower();
            ProductsGrid.ItemsSource = string.IsNullOrEmpty(searchText)
                ? Products
                : new ObservableCollection<Product>(Products.Where(p => p.ProductName.ToLower().Contains(searchText)));
        }

        private void ShowAddProductPopup(object sender, RoutedEventArgs e)
        {
            _isEditing = false;
            _selectedProduct = null;
            ProductNameBox.Text = "";
            CategoryBox.Text = "";
            PriceBox.Text = "";
            StockBox.Text = "";
            PopupGrid.Visibility = Visibility.Visible;
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem is Product product)
            {
                _isEditing = true;
                _selectedProduct = product;
                ProductNameBox.Text = product.ProductName;
                CategoryBox.Text = product.Category;
                PriceBox.Text = product.Price.ToString();
                StockBox.Text = product.Stock.ToString();
                PopupGrid.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Please select a product to edit.");
            }
        }

        private void SaveProduct_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ProductNameBox.Text) ||
                string.IsNullOrWhiteSpace(CategoryBox.Text) ||
                !double.TryParse(PriceBox.Text, out double price) ||
                !int.TryParse(StockBox.Text, out int stock))
            {
                MessageBox.Show("Invalid input. Please check the values.");
                return;
            }

            if (_isEditing && _selectedProduct != null)
            {
                // Update existing product
                _selectedProduct.ProductName = ProductNameBox.Text;
                _selectedProduct.Category = CategoryBox.Text;
                _selectedProduct.Price = price;
                _selectedProduct.Stock = stock;
            }
            else
            {
                // Add new product
                int newId = Products.Count > 0 ? Products.Max(p => p.ProductId) + 1 : 1;
                Products.Add(new Product
                {
                    ProductId = newId,
                    ProductName = ProductNameBox.Text,
                    Category = CategoryBox.Text,
                    Price = price,
                    Stock = stock
                });
            }

            ProductsGrid.ItemsSource = null;
            ProductsGrid.ItemsSource = Products;
            PopupGrid.Visibility = Visibility.Collapsed;
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem is Product product)
            {
                if (MessageBox.Show("Are you sure you want to delete this product?", "Confirm Delete", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Products.Remove(product);
                    ProductsGrid.ItemsSource = null;
                    ProductsGrid.ItemsSource = Products;
                }
            }
            else
            {
                MessageBox.Show("Please select a product to delete.");
            }
        }

        private void ClosePopup(object sender, RoutedEventArgs e)
        {
            PopupGrid.Visibility = Visibility.Collapsed;
        }
    }

    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }
    }
}
