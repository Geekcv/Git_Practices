﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BillingSoftware.Pages
{
    public partial class ReportsPage : UserControl
    {
        public ReportsPage()
        {
            InitializeComponent();
        }

        // Event handler for "Generate Report" button
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            var reportType = ((ComboBoxItem)ReportTypeComboBox.SelectedItem)?.Content.ToString();
            var startDate = StartDatePicker.SelectedDate;
            var endDate = EndDatePicker.SelectedDate;

            // Fetch and filter report data based on selected filters
            var reportData = GetReportData(reportType, startDate, endDate);

            // Bind the data to the DataGrid
            ReportDataGrid.ItemsSource = reportData;
        }

        // Mock method to fetch report data based on filters
        private List<ReportData> GetReportData(string reportType, DateTime? startDate, DateTime? endDate)
        {
            // Replace this with actual data fetching logic
            // For demonstration, returning a static list
            return new List<ReportData>
            {
                new ReportData { ProductId = 1, ProductName = "Product A", Quantity = 10, Price = 100, Total = 1000 },
                new ReportData { ProductId = 2, ProductName = "Product B", Quantity = 5, Price = 200, Total = 1000 },
                new ReportData { ProductId = 3, ProductName = "Product C", Quantity = 15, Price = 50, Total = 750 }
            };
        }

        // Event handler for exporting report to PDF
        private void ExportToPdf_Click(object sender, RoutedEventArgs e)
        {
            // Implement the PDF export logic here (e.g., using PdfSharp)
            MessageBox.Show("Exporting to PDF...");
        }

        // Event handler for exporting report to Excel
        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            // Implement the Excel export logic here (e.g., using EPPlus)
            MessageBox.Show("Exporting to Excel...");
        }
    }

    // Sample data class for report
    public class ReportData
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal Total { get; set; }
    }
}
