﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace BillingSoftware.Pages
{
    public partial class SettingsPage : UserControl
    {
        public SettingsPage()
        {
            InitializeComponent();
        }

        // Event handler for saving account settings
        private void SaveAccountSettings_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;

            // Logic to save account settings (e.g., update database or application settings)
            MessageBox.Show($"Account settings saved: {username}, {email}");
        }

        // Event handler for applying the selected theme
        private void ApplyTheme_Click(object sender, RoutedEventArgs e)
        {
            if (LightThemeRadioButton.IsChecked == true)
            {
                // Apply light theme
                MessageBox.Show("Light theme applied.");
            }
            else if (DarkThemeRadioButton.IsChecked == true)
            {
                // Apply dark theme
                MessageBox.Show("Dark theme applied.");
            }
            else
            {
                MessageBox.Show("No theme selected.");
            }
        }

        // Event handler for saving notification settings
        private void SaveNotificationSettings_Click(object sender, RoutedEventArgs e)
        {
            bool emailNotificationsEnabled = EmailNotificationsCheckBox.IsChecked ?? false;
            bool pushNotificationsEnabled = PushNotificationsCheckBox.IsChecked ?? false;

            // Logic to save notification settings
            MessageBox.Show($"Email Notifications: {emailNotificationsEnabled}, Push Notifications: {pushNotificationsEnabled}");
        }

        // Event handler for saving all settings
        private void SaveAllSettings_Click(object sender, RoutedEventArgs e)
        {
            // Implement logic to save all settings at once
            MessageBox.Show("All settings have been saved.");
        }
    }
}
