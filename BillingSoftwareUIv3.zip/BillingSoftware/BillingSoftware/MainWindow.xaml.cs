﻿using BillingSoftware.Pages;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BillingSoftware
{
    public partial class MainWindow : Window
    {
        private Button _selectedButton; // Store the currently selected button

        public MainWindow()
        {
            InitializeComponent();
        }

        // Toggle Quick Menu Visibility
        private void ToggleQuickMenu(object sender, RoutedEventArgs e)
        {
            if (_selectedButton != null)
            {
                _selectedButton.Background = Brushes.Transparent;
                _selectedButton.Foreground = Brushes.White;
            }

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //clickedButton.Background = Brushes.Yellow;
                clickedButton.Foreground = Brushes.Yellow;
                _selectedButton = clickedButton;
            }

            QuickMenuPanel.Visibility = QuickMenuPanel.Visibility == Visibility.Visible
                ? Visibility.Collapsed
                : Visibility.Visible;
        }

        // Highlight the selected menu button
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedButton != null)
            {
                _selectedButton.Background = Brushes.Transparent;
                _selectedButton.Foreground = Brushes.White;
            }

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //clickedButton.Background = Brushes.Yellow;
                clickedButton.Foreground = Brushes.Yellow;
                _selectedButton = clickedButton;
            }
        }

        // Load POS Billing Page
        private void POSBilling_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedButton != null)
            {
                _selectedButton.Background = Brushes.Transparent;
                _selectedButton.Foreground = Brushes.White;
            }

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //clickedButton.Background = Brushes.Yellow;
                clickedButton.Foreground = Brushes.Blue;
                _selectedButton = clickedButton;
            }

            ContentFrame.Content = new POSBilling(); // Load POSBillingPage.xaml
        }

        // Load Previous Bill Page
        private void PreviousBill_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedButton != null)
            {
                _selectedButton.Background = Brushes.Transparent;
                _selectedButton.Foreground = Brushes.White;
            }

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //clickedButton.Background = Brushes.Yellow;
                clickedButton.Foreground = Brushes.Blue;
                _selectedButton = clickedButton;
            }

            ContentFrame.Content = new PreviousBill(); // Load PreviousBillPage.xaml
        }

        private void ToggleQuickMenuReports(object sender, RoutedEventArgs e)
        {
            QuickMenuPanelReports.Visibility = QuickMenuPanelReports.Visibility == Visibility.Visible
               ? Visibility.Collapsed
               : Visibility.Visible;
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Content = new Reports();
            
        }

        private void ToggleQuickMenuPriceList(object sender, RoutedEventArgs e)
        {
            QuickMenuPriceList.Visibility = QuickMenuPriceList.Visibility == Visibility.Visible
                           ? Visibility.Collapsed
                           : Visibility.Visible;
        }

        private void PriceList_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Content = new PriceList();

        }

        private void PaymentHistory_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Content = new PaymentHistory();
            
        }

        private void ToggleQuickMenuSale(object sender, RoutedEventArgs e)
        {
            QuickMenuSale.Visibility = QuickMenuSale.Visibility == Visibility.Visible
                          ? Visibility.Collapsed
                          : Visibility.Visible;
        }

        private void Sale_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Content = new SalesBill();
            
        }
    }
}
