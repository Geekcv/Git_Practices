﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BillingSoftware.Pages
{
    /// <summary>
    /// Interaction logic for PaymentHistory.xaml
    /// </summary>
    public partial class PaymentHistory : Page
    {
        private ObservableCollection<Payment> paymentList;

        public PaymentHistory()
        {
            InitializeComponent();
            paymentList = new ObservableCollection<Payment>
            {
                new Payment { Date = "05/02/2025", Time = "11:20:33 AM", SerialNo = 5, MobileNo = "9789454542", Amount = 1747.50 },
                new Payment { Date = "05/02/2025", Time = "01:20:33 PM", SerialNo = 4, MobileNo = "9789454541", Amount = 2622.50 },
                new Payment { Date = "05/02/2025", Time = "01:40:39 PM", SerialNo = 3, MobileNo = "9789454540", Amount = 1800.60 },
                new Payment { Date = "05/02/2025", Time = "03:26:53 PM", SerialNo = 2, MobileNo = "9789454539", Amount = 651.60 },
                new Payment { Date = "05/02/2025", Time = "03:45:63 PM", SerialNo = 1, MobileNo = "9789454538", Amount = 220.00 }
            };

            dgPayments.ItemsSource = paymentList;
            UpdateGrandTotal();
        }

        private void AddEntry_Click(object sender, RoutedEventArgs e)
        {
            paymentList.Add(new Payment { Date = "05/02/2025", Time = "04:00:00 PM", SerialNo = paymentList.Count + 1, MobileNo = "9789454500", Amount = 500.00 });
            UpdateGrandTotal();
        }

        private void RemoveEntry_Click(object sender, RoutedEventArgs e)
        {
            if (dgPayments.SelectedItem is Payment selectedPayment)
            {
                paymentList.Remove(selectedPayment);
                UpdateGrandTotal();
            }
        }

        private void DeleteEntry_Click(object sender, RoutedEventArgs e)
        {
            if (dgPayments.SelectedItem is Payment selectedPayment)
            {
                paymentList.Remove(selectedPayment);
                UpdateGrandTotal();
            }
        }

        private void UpdateGrandTotal()
        {
            double total = 0;
            foreach (var payment in paymentList)
            {
                total += payment.Amount;
            }
            txtGrandTotal.Text = total.ToString("F2");
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Printing Payment History...", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            //this.Close();
        }

        private void EditEntry_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

public class Payment
{
    public string Date { get; set; }
    public string Time { get; set; }
    public int SerialNo { get; set; }
    public string MobileNo { get; set; }
    public double Amount { get; set; }
}
