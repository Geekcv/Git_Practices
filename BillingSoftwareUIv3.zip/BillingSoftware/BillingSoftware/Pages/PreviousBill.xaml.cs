﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BillingSoftware.Pages
{
    /// <summary>
    /// Interaction logic for PreviousBill.xaml
    /// </summary>
    public partial class PreviousBill : Page
    {
        private ObservableCollection<Product> productList;

        public PreviousBill()
        {
            InitializeComponent();
            productList = new ObservableCollection<Product>();
            dgItems.ItemsSource = productList;
            txtTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
            txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            productList.Add(new Product { SerialNo = productList.Count + 1, Code = "0001", ItemName = "New Item", Quantity = 1, WeightKg = 1.00, WeightGm = 0.00, Price = 100.00, Total = 100.00 });
        }

        private void RemoveItem_Click(object sender, RoutedEventArgs e)
        {
            if (dgItems.SelectedItem is Product selectedProduct)
            {
                productList.Remove(selectedProduct);
            }
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Printing Receipt...", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            //this.Close();
        }

    }
}

public class Product
{
    public int SerialNo { get; set; }
    public string Code { get; set; }
    public string ItemName { get; set; }
    public int Quantity { get; set; }
    public double WeightKg { get; set; }
    public double WeightGm { get; set; }
    public double Price { get; set; }
    public double Total { get; set; }
}
