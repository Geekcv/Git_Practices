﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BillingSoftware.Pages
{
    /// <summary>
    /// Interaction logic for Reports.xaml
    /// </summary>
    public partial class Reports : Page
    {
               private ObservableCollection<ReportItem> reportItems;

        public Reports()
        {
            InitializeComponent();
            reportItems = new ObservableCollection<ReportItem>
            {
                new ReportItem { SerialNo = 1, Code = 3246, ItemName = "Sugar", PurchaseQty = "100.00 Kg", SaleQty = "85.00 Kg", InStock = "15.00 Kg", Price = 45.00 },
                new ReportItem { SerialNo = 2, Code = 3949, ItemName = "Jaggery(Gud)", PurchaseQty = "50.00 Kg", SaleQty = "35.00 Kg", InStock = "15.00 Kg", Price = 40.00 },
                new ReportItem { SerialNo = 3, Code = 3966, ItemName = "Red Chilli Powder", PurchaseQty = "15.00 Kg", SaleQty = "10.00 Kg", InStock = "05.00 Kg", Price = 180.00 },
                new ReportItem { SerialNo = 4, Code = 9442, ItemName = "Almond", PurchaseQty = "35.00 Kg", SaleQty = "28.00 Kg", InStock = "07.00 Kg", Price = 550.00 },
                new ReportItem { SerialNo = 5, Code = 8556, ItemName = "Hand Wash", PurchaseQty = "100 Pkt.", SaleQty = "90 Pkt.", InStock = "10 Pkt.", Price = 100.00 }
            };

            dgReports.ItemsSource = reportItems;
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Printing Report...", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            //this.Close();
        }

    }
}


public class ReportItem
{
    public int SerialNo { get; set; }
    public int Code { get; set; }
    public string ItemName { get; set; }
    public string PurchaseQty { get; set; }
    public string SaleQty { get; set; }
    public string InStock { get; set; }
    public double Price { get; set; }
}
