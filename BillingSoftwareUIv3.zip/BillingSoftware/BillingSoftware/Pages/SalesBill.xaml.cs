﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BillingSoftware.Pages
{
    /// <summary>
    /// Interaction logic for SalesBill.xaml
    /// </summary>
    public partial class SalesBill : Page
    {
        

        public ObservableCollection<SalesItem> SalesItems { get; set; }
        public double ShippingCharge { get; set; } = 465.00;
        public double GSTPercentage { get; set; } = 18.00;

        public SalesBill()
        {
            InitializeComponent();
            SalesItems = new ObservableCollection<SalesItem>
            {
                new SalesItem { SerialNo = 1, Code = "3246", ItemName = "Sugar", Quantity = 2, Kg = 50, Price = 40, Status = "Shipping" },
                new SalesItem { SerialNo = 2, Code = "3949", ItemName = "Jaggery(Gud)", Quantity = 5, Kg = 15, Price = 35, Status = "Shipping" },
                new SalesItem { SerialNo = 3, Code = "3966", ItemName = "Red Chilli Powder", Quantity = 2, Kg = 20, Price = 170, Status = "Shipping" },
                new SalesItem { SerialNo = 4, Code = "9442", ItemName = "Almond", Quantity = 1, Kg = 25, Price = 340, Status = "Shipping" },
                new SalesItem { SerialNo = 5, Code = "8556", ItemName = "Hand Wash", Quantity = 10, Kg = 0, Price = 100, Status = "Shipping" }
            };

            DataGridSales.ItemsSource = SalesItems;
            CalculateTotals();
        }

        private void CalculateTotals()
        {
            double totalAmount = 0;
            foreach (var item in SalesItems)
            {
                totalAmount += item.Total;
            }

            double gstAmount = (totalAmount * GSTPercentage) / 100;
            double grandTotal = totalAmount + ShippingCharge + gstAmount;

            //TotalAmountText.Text = $"Total: {totalAmount:C}";
            //GSTAmountText.Text = $"GST ({GSTPercentage}%): {gstAmount:C}";
            //ShippingChargeText.Text = $"Shipping Charge: {ShippingCharge:C}";
            //GrandTotalText.Text = $"Grand Total: {grandTotal:C}";
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            SalesItems.Add(new SalesItem { SerialNo = SalesItems.Count + 1, Code = "0000", ItemName = "New Item", Quantity = 1, Kg = 1, Price = 100, Status = "Pending" });
            CalculateTotals();
        }

        private void RemoveItem_Click(object sender, RoutedEventArgs e)
        {
            if (DataGridSales.SelectedItem is SalesItem selectedItem)
            {
                SalesItems.Remove(selectedItem);
                CalculateTotals();
            }
        }

        private void SaveOrder_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Order Saved Successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void PrintReceipt_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Printing Receipt...", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void PlaceOrder_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Order Placed Successfully!", "Order", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

    }
}


public class SalesItem
{
    public int SerialNo { get; set; }
    public string Code { get; set; }
    public string ItemName { get; set; }
    public int Quantity { get; set; }
    public double Kg { get; set; }
    public double Price { get; set; }
    public double Total => Quantity * Kg * Price;
    public string Status { get; set; }
}
