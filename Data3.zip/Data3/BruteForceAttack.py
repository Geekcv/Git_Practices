import itertools
import string

def brute_force_attack(target_password, max_length=3):
    characters = string.ascii_lowercase  # Limiting to lowercase letters for simplicity
    
    for length in range(1, max_length + 1):
        for guess in itertools.product(characters, repeat=length):
            if "".join(guess) == target_password:
                return f"Password found: {''.join(guess)}"
    
    return "Password not found."

print(brute_force_attack("abc"))
