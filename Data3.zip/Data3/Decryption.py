
def caesar_encrypt(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            result += chr((ord(char) - shift_base + shift) % 26 + shift_base)
        else:
            result += char  # Keep non-alphabetic characters unchanged
    return result

text = "Hello World"
shift = 3
encrypted_text = caesar_encrypt(text, shift)






def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)

decrypted_text = caesar_decrypt(encrypted_text, shift)
print("Decrypted:", decrypted_text)
