import hashlib


def dictionary_attack(hashed_password, dictionary):
    import hashlib
    
    for word in dictionary:
        hashed_word = hashlib.md5(word.encode()).hexdigest()
        if hashed_word == hashed_password:
            return f"Password found: {word}"
    
    return "Password not found."

# Example dictionary and hash
dictionary = ["password", "123456", "hello", "security"]
hashed_password = hashlib.md5("hello".encode()).hexdigest()

print(dictionary_attack(hashed_password, dictionary))
