import numpy as np

def text_to_numbers(text):
    return [ord(char) - ord('A') for char in text.upper()]

def numbers_to_text(numbers):
    return ''.join(chr(num + ord('A')) for num in numbers)

def encrypt_hill_cipher(plain_text, key_matrix):
    n = len(key_matrix)
    plain_text = plain_text.upper().replace(" ", "")
    
    while len(plain_text) % n != 0:
        plain_text += 'X'  # Padding if needed
    
    text_numbers = text_to_numbers(plain_text)
    encrypted_numbers = []
    
    for i in range(0, len(text_numbers), n):
        chunk = np.array(text_numbers[i:i+n])
        encrypted_chunk = np.dot(key_matrix, chunk) % 26
        encrypted_numbers.extend(encrypted_chunk)
    
    return numbers_to_text(encrypted_numbers)

key_matrix = np.array([[6, 24], [1, 13]])  # Example 2x2 key matrix
plain_text = "HELP"
encrypted_text = encrypt_hill_cipher(plain_text, key_matrix)
print("Encrypted:", encrypted_text)
