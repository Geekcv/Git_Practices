def generate_playfair_matrix(keyword):
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    keyword = "".join(dict.fromkeys(keyword.upper().replace("J", "I")))  # Remove duplicates
    matrix_string = keyword + "".join(c for c in alphabet if c not in keyword)
    matrix = [list(matrix_string[i:i+5]) for i in range(0, 25, 5)]
    
    for row in matrix:
        print(row)

generate_playfair_matrix("SECURITY")
