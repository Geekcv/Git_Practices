def make_pairs(text):
    text = text.replace("J", "I")  # Playfair replaces J with I
    pairs = []
    i = 0
    while i < len(text):
        a = text[i]
        b = 'X' if (i + 1 == len(text) or text[i] == text[i + 1]) else text[i + 1]
        pairs.append(a + b)
        i += 2 if a != b else 1  # Skip one if identical, else move by two
    return pairs

text = "HELLO"
print(make_pairs(text))
