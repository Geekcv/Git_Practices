def vigenere_cipher(text, key, decrypt=False):
    text = text.upper()
    key = key.upper()
    result = ""
    key_index = 0
    key_length = len(key)
    
    for char in text:
        if char.isalpha():
            shift = ord(key[key_index % key_length]) - ord('A')
            shift = -shift if decrypt else shift
            new_char = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
            result += new_char
            key_index += 1
        else:
            result += char  # Preserve non-alphabetic characters
    
    return result

text = "HELLO"
key = "KEY"
encrypted_text = vigenere_cipher(text, key)
decrypted_text = vigenere_cipher(encrypted_text, key, decrypt=True)

print("Encrypted:", encrypted_text)
print("Decrypted:", decrypted_text)
