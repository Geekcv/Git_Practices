﻿using BillingSoftware.controller;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BillingSoftware
{
    /// <summary>
    /// Interaction logic for ActivationWindow.xaml
    /// </summary>
    public partial class ActivationWindow : Window
    {
        private static readonly HttpClient client = new HttpClient();

        public ActivationWindow()
        {
            InitializeComponent();
        }


        private async void Activate_Click(object sender, RoutedEventArgs e)
        {
            var payload = new
            {
                license_key = txtLicenseKey.Text,
                mac_address = MachineInfo.GetMacAddress()
            };

            try
            {
                bool isActivated = await Apicontroller.activateLicenseAsync(payload);

                if (!isActivated)
                {
                    MessageBox.Show("Activation Failed! Invalid License Key.");
                    return;
                }

                MessageBox.Show("Activation Successful!");

                //  Open main window after activation
                new MainWindow().Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}