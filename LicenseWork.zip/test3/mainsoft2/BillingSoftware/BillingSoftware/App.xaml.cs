﻿using System.Configuration;
using System.Data;
using System.IO;
using System.Windows;

namespace BillingSoftware
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            if (!File.Exists("license.lic") || !File.Exists("public.pem"))
            {
                // No license found → Show UserDetailsWindow first
                new UserDetailsWindow().Show();
            }
            else
            {
                // License exists → Verify before opening MainWindow
                if (LicenseValidator.ValidateLicense())
                {
                    new MainWindow().Show();
                }
                else
                {
                    new ActivationWindow().Show();
                }
            }
        }


    }

}
