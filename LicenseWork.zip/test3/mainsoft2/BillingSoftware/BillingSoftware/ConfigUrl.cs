﻿namespace Billing_Project
{
    public class Config
    {
        public string apiBaseURL { get; set; }
    }

    public class ConfigUrl
    {
        public static readonly Config ConfigSettings = new Config
        {

            //  apiBaseURL = "https://clientlogs.ftisindia.com"

            //apiBaseURL = "https://jsonplaceholder.typicode.com/posts"

            apiBaseURL = "http://localhost:3000"
        };

    }
}
