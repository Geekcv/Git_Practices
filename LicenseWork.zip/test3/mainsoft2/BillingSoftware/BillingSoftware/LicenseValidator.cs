﻿//using System;
//using System.IO;
//using System.Security.Cryptography;
//using System.Text;
//using Newtonsoft.Json;
//using Newtonsoft.Json.Linq;

//namespace BillingSoftware
//{
//    public class LicenseValidator
//    {
//        public static bool ValidateLicense()
//        {
//            if (!File.Exists("license.lic") || !File.Exists("public.pem"))
//                return false;

//            // Read License File & Public Key
//            string licenseJson = File.ReadAllText("license.lic").Trim();
//            string publicKey = File.ReadAllText("public.pem").Trim();

//            // Deserialize JSON to extract license data and signature
//            JObject licenseData = JObject.Parse(licenseJson);
//            string signatureBase64 = (string)licenseData["signature"];
//            licenseData.Remove("signature"); // Remove signature from the data

//            // Ensure consistent JSON serialization
//            string licenseContent = JsonConvert.SerializeObject(licenseData, Formatting.None);
//            byte[] licenseBytes = Encoding.UTF8.GetBytes(licenseContent);
//            byte[] signatureBytes = Convert.FromBase64String(signatureBase64);

//            using (RSA rsa = RSA.Create())
//            {
//                rsa.ImportFromPem(publicKey);
//                return rsa.VerifyData(
//                    licenseBytes,
//                    signatureBytes,
//                    HashAlgorithmName.SHA256,
//                    RSASignaturePadding.Pss // ✅ Must match backend
//                );
//            }
//        }
//    }
//}





using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BillingSoftware
{
    public class LicenseValidator
    {
        public static bool ValidateLicense()
        {
            if (!File.Exists("license.lic") || !File.Exists("public.pem"))
            {
                Console.WriteLine("❌ License file or public key is missing.");
                return false;
            }

            try
            {
                // Read License File & Public Key
                string licenseJson = File.ReadAllText("license.lic").Trim();
                string publicKey = File.ReadAllText("public.pem").Trim();

                // Deserialize JSON to extract license data and signature
                JObject licenseData = JObject.Parse(licenseJson);
                string signatureBase64 = (string)licenseData["signature"];
                string storedMacAddress = (string)licenseData["mac_address"];


                // Get current system MAC address
                string currentMacAddress = GetMacAddress();


                if (!string.Equals(currentMacAddress, storedMacAddress, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("MAC Address mismatch! License is not valid for this machine");
                    return false;
                }

                licenseData.Remove("signature"); // Remove signature from the data  
                //Removes signature from the license data (we only verify the actual data).


                // Convert license data to JSON and encode it
                string licenseContent = JsonConvert.SerializeObject(licenseData, Formatting.None);
                byte[] licenseBytes = Encoding.UTF8.GetBytes(licenseContent);
                byte[] signatureBytes = Convert.FromBase64String(signatureBase64);

                using (RSA rsa = RSA.Create())
                {
                    rsa.ImportFromPem(publicKey);
                    bool isValidSignature = rsa.VerifyData(
                        licenseBytes,
                        signatureBytes,
                        HashAlgorithmName.SHA256,
                        RSASignaturePadding.Pss // ✅ Must match backend
                    );

                    if (!isValidSignature)
                    {
                        Console.WriteLine("❌ License signature validation failed.");
                        return false;
                    }
                }

               

                Console.WriteLine("License validated successfully!");
                
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error during license validation: {ex.Message}");
                return false;
            }
        }

        // 📌 Function to get current system's MAC address
        private static string GetMacAddress()
        {
            return NetworkInterface
                .GetAllNetworkInterfaces()
                .Where(nic => nic.OperationalStatus == OperationalStatus.Up && nic.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .Select(nic => nic.GetPhysicalAddress().ToString())
                .FirstOrDefault() ?? "UNKNOWN";
        }
    }
}
