﻿using BillingSoftware.controller;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BillingSoftware
{
    /// <summary>
    /// Interaction logic for UserDetailsWindow.xaml
    /// </summary>
    public partial class UserDetailsWindow : Window
    {

        public UserDetailsWindow()
        {
            InitializeComponent();
            txtMac.Text = MachineInfo.GetMacAddress(); // Auto-fetch MAC address

        }


        //private async void GenerateLicense_Click(object sender, RoutedEventArgs e)
        //{
        //    var userDetails = new
        //    {
        //        name = txtName.Text,
        //        email = txtEmail.Text,
        //        mac_address = txtMac.Text
        //    };



        //    bool response = await Apicontroller.AddClientAsync(userDetails);


        //    if (response)
        //    {
        //        //string licenseKey = await response.Content.ReadAsStringAsync();
        //        //MessageBox.Show("License Key: " + licenseKey);
        //        new ActivationWindow().Show();
        //        this.Close();
        //    }
        //    else
        //    {
        //        MessageBox.Show("License generation failed.");
        //    }
        //}


        private async void GenerateLicense_Click(object sender, RoutedEventArgs e)
        {
            var userDetails = new
            {
                name = txtName.Text,
                email = txtEmail.Text,
                mac_address = txtMac.Text
            };

            string licenseKey = await Apicontroller.AddClientAsync(userDetails);

            if (!string.IsNullOrEmpty(licenseKey))
            {
                MessageBox.Show("License Key: " + licenseKey);

                // Save the license key to a local file
                File.WriteAllText("licenseKey.lic", licenseKey);

                new ActivationWindow().Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("License generation failed.");
            }
        }



    }
}
