﻿using BillingSoftware.connect_db;
using BillingSoftware.service;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Security.Claims;
using System.Text;
using System.Windows;

namespace BillingSoftware.controller
{
    public class Apicontroller
    {
        private const string JwtSecretKey = "ThisIsAStrongSecretKeyWithMoreThan32Chars";

        public static async Task<bool> LoginUserAsync(object logindata)
        {
            var loginData = new
            {
                fn = "common_fn",
                se = "lo_us",
                data = logindata
            };

            string response = await ApiService.PostUrlAsync(loginData, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("Login failed: Empty response");
                return false;
            }

            // encode response agian 
            string urlDecoded = Uri.UnescapeDataString(response);

            try
            {
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);

                if (result?.data?.token != null)
                {
                    ApiService.SaveToken(result.data.token.ToString());
                    return true;
                }
                else
                {
                    Console.WriteLine("Login failed: No token received");
                    return false;
                }
            }
            catch (JsonReaderException jex)
            {
                Console.WriteLine("JSON Parsing Error: " + jex.Message);
                Console.WriteLine("API Response: " + response);
                return false;
            }
        }



        public static async Task<bool> LoginUserpg(string username, string password)
        {
            string userTable1 = "public.users"; // Fixed table reference format

            Dictionary<string, object> conditions = new Dictionary<string, object>
    {
        { "AND", new Dictionary<string, object>
            {
                { "username", username },
                { "password", password } // ⚠️ Password should be hashed in a real application
            }
        }
    };

            // Fetch data asynchronously
            List<Dictionary<string, object>> userTable = await queries.FetchData(userTable1, conditions);

            if (userTable.Count > 0) // Corrected the check
            {
                var row = userTable[0]; // Access first item correctly
                int userId = Convert.ToInt32(row["user_id"]);
                string userName = row["username"].ToString();

                string token = GenerateJwtToken(userId, userName); // Ensure this method exists
                if (token!= null)
                {
                    ApiService.SaveToken(token);
                    return true;
                }
                else
                {
                    Console.WriteLine("Login failed: No token received");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false; // Return failure
            }
        }



        private static string GenerateJwtToken(int userId, string username)
        {

            var key = Encoding.UTF8.GetBytes(JwtSecretKey); // Ensure key is at least 32 characters
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
            new Claim("userId", userId.ToString()),
            new Claim("username", username)
        }),
                Expires = DateTime.UtcNow.AddHours(24),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature // Ensure correct algorithm
                )
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }












        //public static async Task<bool> AddClientAsync(object clientdata)
        //{
        //    var userData = new
        //    {
        //        fn = "common_fn",
        //        se = "gen_lic",
        //        data = clientdata
        //    };

        //    string response = await ApiService.PostUrlAsync(userData, "common");

        //    if (string.IsNullOrEmpty(response))
        //    {
        //        Console.WriteLine("Empty response");
        //        return false;
        //    }           

        //    string urlDecoded = Uri.UnescapeDataString(response);

        //    try
        //    {
        //        var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
        //        Console.WriteLine($"Parsed JSON: {result}");

        //        if (result != null && result.status == 0)
        //        {
        //            return true;
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    catch (JsonReaderException jex)
        //    {
        //        Console.WriteLine("JSON Parsing Error: " + jex.Message);
        //        Console.WriteLine(" API Response: " + response);
        //        return false;
        //    }
        //}



        public static async Task<string> AddClientAsync(object clientdata)
        {
            var userData = new
            {
                fn = "common_fn",
                se = "gen_lic",
                data = clientdata
            };

            string response = await ApiService.PostUrlAsync(userData, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("Empty response");
                return null;
            }

            string urlDecoded = Uri.UnescapeDataString(response);

            try
            {
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"Parsed JSON: {result}");

                if (result != null && result.status == 0)
                {
                    return result.data; // Return the license key
                }
            }
            catch (JsonReaderException jex)
            {
                Console.WriteLine("JSON Parsing Error: " + jex.Message);
                Console.WriteLine("API Response: " + response);
            }

            return null;
        }






        public static async Task<bool> activateLicenseAsync(object payload)
        {
            string response = await ApiService.PostUrlAsync(new { fn = "common_fn", se = "act_lice", data = payload }, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("Failed to activate license: Empty response");
                return false;
            }


            try
            {
                // Fix potential JSON formatting issues
                string jsonResponse = response.Trim();
                if (jsonResponse.StartsWith("[") && jsonResponse.EndsWith("]"))
                {
                    jsonResponse = jsonResponse.Trim('[', ']'); // Remove outer brackets if it's an array
                }

                string urlDecoded = Uri.UnescapeDataString(jsonResponse);

                // Deserialize JSON
                var jsonResult = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"Parsed Clients JSON: {jsonResult}");

               // var jsonResult = JsonConvert.DeserializeObject<JObject>(result);

                if (jsonResult == null || !jsonResult.ContainsKey("status") || jsonResult["status"].ToObject<int>() != 0)
                {
                    Console.WriteLine("❌ License activation failed.");
                    return false;
                }

                //  Extract "data" field safely
                var dataObj = jsonResult["data"];
                if (dataObj == null)
                {
                    Console.WriteLine(" No license data found.");
                    return false;
                }

                //  Extract "license" field and parse it as JSON
                var licenseJson = dataObj["license"]?.ToString();
                if (string.IsNullOrEmpty(licenseJson))
                {
                    Console.WriteLine(" License data is empty.");
                    return false;
                }

                var licenseData = JsonConvert.DeserializeObject<LicenseData>(licenseJson);
                if (licenseData == null)
                {
                    Console.WriteLine("Failed to parse license data.");
                    return false;
                }

                // Extract "public_key" separately
                string publicKey = dataObj["public_key"]?.ToString();
                if (string.IsNullOrEmpty(publicKey))
                {
                    Console.WriteLine("Public key data is empty.");
                    return false;
                }

                // Save license and public key separately
                File.WriteAllText("license.lic", JsonConvert.SerializeObject(licenseData, Formatting.Indented));
                File.WriteAllText("public.pem", publicKey);

                Console.WriteLine($" License Activated: {licenseData.Name}");
                return true;


            }
            catch (Exception ex)
            {
                Console.WriteLine($" Error parsing license: {ex.Message}");
                return false;

            }
        }

    }
}


public class Client1
{
    public string Name { get; set; }
    public string Description { get; set; }
}




public class LicenseData
{
    [JsonProperty("row_id")]
    public string RowId { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("email")]
    public string Email { get; set; }

    [JsonProperty("mac_address")]
    public string MacAddress { get; set; }

    [JsonProperty("license_key")]
    public string LicenseKey { get; set; }

    [JsonProperty("signature")]
    public string Signature { get; set; }
}
