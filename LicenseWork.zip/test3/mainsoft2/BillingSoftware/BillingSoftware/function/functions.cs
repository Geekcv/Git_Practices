﻿namespace BillingSoftware.function
{
    public class functions
    {
        public static string RandomId()
        {
            string randomTxt = "";
            string possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            Random random = new Random();
            for (int i = 0; i < 4; i++)
            {
                randomTxt += possible[random.Next(possible.Length)];
            }
            return GetTimeStamp() + "_" + randomTxt;
        }

        private static string GetTimeStamp()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmss");
        }

    }
}
