const crypto = require("crypto");
const fs = require("fs");

// Check if keys already exist
if (fs.existsSync("public.pem") || fs.existsSync("private.pem")) {
  console.log(
    "⚠️ RSA keys already exist. Delete them first if you want to regenerate."
  );
  process.exit(1);
}

// Generate RSA key pair
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048, // 🔥 Sets 2048-bit key length for strong encryption.
  publicKeyEncoding: { type: "spki", format: "pem" }, //Stored in SPKI PEM format (for sharing).
  privateKeyEncoding: { type: "pkcs8", format: "pem" }, //Stored in PKCS8 PEM format (for security).
});

//2048-bit RSA is secure and widely used in cryptography.

// Save keys asynchronously
Promise.all([
  fs.promises.writeFile("public.pem", publicKey),
  fs.promises.writeFile("private.pem", privateKey),
])
  .then(() => console.log("✅ Public & Private keys generated successfully!"))
  .catch((err) => console.error("❌ Error generating keys:", err));
