import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BandalComponent } from './bandal.component';

describe('BandalComponent', () => {
  let component: BandalComponent;
  let fixture: ComponentFixture<BandalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BandalComponent]
    });
    fixture = TestBed.createComponent(BandalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
