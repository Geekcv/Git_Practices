import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CenterWiseStudentComponent } from './center-wise-student.component';

describe('CenterWiseStudentComponent', () => {
  let component: CenterWiseStudentComponent;
  let fixture: ComponentFixture<CenterWiseStudentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CenterWiseStudentComponent]
    });
    fixture = TestBed.createComponent(CenterWiseStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
