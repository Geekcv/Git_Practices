import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CityWiseStudentComponent } from './city-wise-student.component';

describe('CityWiseStudentComponent', () => {
  let component: CityWiseStudentComponent;
  let fixture: ComponentFixture<CityWiseStudentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CityWiseStudentComponent]
    });
    fixture = TestBed.createComponent(CityWiseStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
