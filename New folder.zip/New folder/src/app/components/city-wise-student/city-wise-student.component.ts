import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-city-wise-student',
  templateUrl: './city-wise-student.component.html',
  styleUrls: ['./city-wise-student.component.css']
})
export class CityWiseStudentComponent {

  getSessionName(examId: any): string | null {
    const exam = this.exams.find(e => e.id === examId);
    // console.log("exam============",exam)
    return exam ? exam.name : null;
  }
  getStateName(examId: any): string | null {
    const exam = this.jsonlist.state.find(e => e.value === examId);
    // console.log("exam============",exam)
    return exam ? exam.title : null;
  }
  getCityName(examId: any): string | null {
    const exam = this.jsonlist.cities.find(e => e.value === examId);
    // console.log("exam============",exam)
    return exam ? exam.title : null;
  }
  // --- End of Helper methods ---

  exportData() {
    // Implement your export logic here (e.g., using exceljs or similar)
    console.log("Exporting data...", this.students);
    this.students.forEach((item: any) => {
      delete item.id;

    });
    this.utiltiesService.exportAsExcelFile(this.students, 'CityWiseStudentReport');
  }

  selectedGender: any = 'All'; // Default to 'All'
  fromDate: Date | null = null; // Initialize date properties
  toDate: Date | null = null;   // Initialize date properties
 printReport() {
  this.utiltiesService.printReport('report', 'CityWiseStudentReport');
    // const printElement = document.getElementById('report');
    // if (!printElement) {
    //   console.error('Element with ID "report" not found.');
    //   return;
    // }
  
    // const printContents = printElement.innerHTML;
    // const printWindow = window.open('', '_blank', 'width=800,height=600');
  
    // if (printWindow) {
    //   printWindow.document.open();
    //   printWindow.document.write(`
    //     <html>
    //       <head>
    //         <title>Print Report</title>
    //         <style>
    //           @media print {
    //             .no-print {
    //               display: none !important;
    //             }
    //             body, table {
    //               font-size: 10px;
    //             }
    //             table {
    //               border-collapse: collapse;
    //               width: 100%;
    //             }
    //             th, td {
    //               border: 1px solid #000;
    //               padding: 4px;
    //               text-align: left;
    //             }
    //           }
    //         </style>
    //       </head>
    //       <body>
    //         ${printContents}
    //         <script>
    //           window.onload = function() {
    //             window.print();
    //             setTimeout(() => window.close(), 500);
    //           };
    //         </script>
    //       </body>
    //     </html>
    //   `);
    //   printWindow.document.close();
    // } else {
    //   console.error('Failed to open print window');
    // }
  }

  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService,public jsonlist:JsonListService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.studentTableData.searchFields;
  students: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any =  this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 5;
  noofpage: any = 1;
  bundleNo:any;
  displayDialog: boolean = false;
  selectedStudent: any = null;
  exams: any[] = [];
  filteredCenters: any[] = [];
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedState: any = null;
  selectedCity: any = null;
  selectedStudents:any=[];

  ngOnInit() {
    this.loadInitialData();
  }

  loadInitialData() {
    this.exams = []; // Keep if needed elsewhere
    this.fetchExams();
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  // Method called when filters change or Submit button is clicked
  async onFilterChange() {
    this.students = []; // Clear previous student list
    // Fetch students based on the selected filters
    await this.fetchFilteredStudents();
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.exams = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.exams.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  // Fetch students based on selected filters
  async fetchFilteredStudents(page = 1, limit = 100) {


    var tempClientDAta = await this.apiController.fetchStudentByCityWise(
        this.selectedCity,
        this.selectedExam,
        this.selectedState, 
        page,
        limit
    );
    if (tempClientDAta != false) {
      this.students = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map API response fields to the fields expected by the table
        
        var age=this.utiltiesService.calculateAge(tempClientDAta[i].dob);
        this.students.push(
          {
            rollNo: tempClientDAta[i].roll_no,
            studentName: tempClientDAta[i].student_name,
            fatherName: tempClientDAta[i].father_name,
            address: tempClientDAta[i].address,
            aadharNo: tempClientDAta[i].aadhar_no, // Adjust field names as per your API response
            phone: tempClientDAta[i].phone,
            age: age,
            class: tempClientDAta[i].class_name, // Assuming class name is needed
            accountNo: tempClientDAta[i].account_no,
            accountName: tempClientDAta[i].account_name,
            ifscCode: tempClientDAta[i].ifsc_code,
            // Keep original data if needed for other operations
            originalData: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Use a unique ID for potential row operations
          }
        );
      }
      console.log("Fetched students:", this.students);
    } else {
        this.students = []; // Ensure students array is empty if fetch fails
        console.log("No students found or API error.");
    }
  }


  editClient(cl: any) {
    this.savedForm=cl.originalData;
    this.selectedRowId = cl.rowId;
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
    // Implement pagination for filtered results if needed
    // const page = row.page;
    // const limit = row.limit;
    // this.fetchFilteredStudents(page, limit);
  }
  async fetchCount() {
    // Adjust count logic if needed for filtered data
    // var totRec = await this.apiController.fetchCount('bandals'); // Or a specific count endpoint
    // if (totRec != false) {
    //   this.totalRecords = totRec;
    //   this.noofpage = Math.ceil(this.totalRecords / this.limit);
    // }
  }
}
