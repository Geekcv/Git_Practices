import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent {

 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService,public jsonlist:JsonListService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.studentTableData.searchFields;
  students: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any =  this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 5;
  noofpage: any = 1;
  bundleNo:any;
  displayDialog: boolean = false;
  selectedStudent: any = null;
  exams: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
  checkers: any[] = [];
  filteredCenters: any[] = [];
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedClass: any = null;
  selectedCenter: any = null;
  selectedChecker: any = null;
  selectedStudents:any=[];

  ngOnInit() {
    // Don't fetch all students initially, wait for filters
    // this.fetchStudents();
    this.loadInitialData();
  }

  loadInitialData() {
    this.exams = [];
    this.classes = [];
    this.centers = [];
    this.checkers = []; // Initialize checkers array
    // this.fetchClasses();
    this.fetchExams();
    // this.fetchExamCenter(); // Keep if needed elsewhere, but not directly for this component's main table
    this.fetchSheetChecker();
    this.fetchLatestBundlNo();
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  // Method called when Faculty, Exam, or Class dropdown changes
  async onFilterChange() {
    this.students = []; // Clear previous student list
    this.selectedStudents = []; // Clear selection
    if (this.selectedFaculty && this.selectedExam && this.selectedClass && this.selectedChecker) {
      // Fetch students based on the selected filters
      await this.fetchFilteredStudents();
    }
  }

  async fetchLatestBundlNo(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchLatestBundlNo(page, limit);
    if (tempClientDAta != false && tempClientDAta.length > 0) {
    // console.log("bundle_no========",tempClientDAta);
      // Increment the last bundle number or handle logic as needed
      this.bundleNo =tempClientDAta[0].bundle_no
    } else {
        // this.bundleNo = 1; // Start from 1 if none exist
    }
  }

  async fetchSheetChecker(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchSheetCheckers(page, limit);
    if (tempClientDAta != false) {
    // console.log("checkers========",tempClientDAta); // Corrected log message
      this.checkers = []; // Clear existing checkers
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.checkers.push(
          {
            title: tempClientDAta[i].name, // Use 'name' for optionLabel
            data: tempClientDAta[i],
            value: tempClientDAta[i].row_id // Use 'id' for optionValue
          }
        );
      }
    }
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
    // console.log("exams========",tempClientDAta);
      this.exams = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.exams.push(
          {
            title: tempClientDAta[i].session_name, // Use 'name' for optionLabel
            data: tempClientDAta[i],
            value: tempClientDAta[i].row_id // Use 'id' for optionValue
          }
        );
      }
    }
  }

  async fetchClasses(page = 1, limit = 500) {

    var tempClientDAta = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,page, limit);    if (tempClientDAta != false) {
    // console.log("classes========",tempClientDAta);
      this.classes = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.classes.push(
          {
            title: tempClientDAta[i].class_name, // Use 'name' for optionLabel
            data: tempClientDAta[i],
            value: tempClientDAta[i].row_id // Use 'id' for optionValue
          }
        );
      }
    }
  }

  // async fetchExamCenter(page = 1, limit = 500) {
  //   var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
  //   if (tempClientDAta != false) {
  //     this.centers = [];
  //     for (var i = 0; i < tempClientDAta.length; i++) {
  //     // console.log("centers========",tempClientDAta);
  //       this.centers.push(
  //         {
  //           title: tempClientDAta[i].center,
  //           data: tempClientDAta[i],
  //           value: tempClientDAta[i].row_id
  //         }
  //       );
  //     }
  //   }
  // }

  // Fetch students based on selected filters
  async fetchFilteredStudents(page = 1, limit = 100) {
    if (!this.selectedFaculty || !this.selectedExam || !this.selectedClass) {
        return; // Don't fetch if filters aren't set
    }
    // Pass filter values to the API call
    var tempClientDAta = await this.apiController.fetchStudentsByFilterWithChecker(
        this.selectedFaculty,
        this.selectedExam,
        this.selectedClass,
        this.selectedChecker,
        page,
        limit
    );
    if (tempClientDAta != false) {
      this.students = [];
      console.log("tempClientDAta========",tempClientDAta); 
      for (var i = 0; i < tempClientDAta.length; i++) {

        this.students.push(
          {
            name: tempClientDAta[i].student_name,
            rollNo: tempClientDAta[i].roll_no || `TEMP-${i}`,
            father_name: tempClientDAta[i].father_name,
            dob: tempClientDAta[i].dob,
            address: tempClientDAta[i].address,
            city: tempClientDAta[i].city,
            originalData: tempClientDAta[i],
            marks: tempClientDAta[i].marks,
            id: tempClientDAta[i].row_id // Use 'id' for dataKey
          }
        );
      }
      // Optionally update totalRecords if pagination is needed for filtered results
      // this.totalRecords = await this.apiController.fetchFilteredStudentCount(...)
    } else {
        this.students = []; // Ensure students array is empty if fetch fails
    }
  }


  editClient(cl: any) {
    this.savedForm=cl.originalData;
    this.selectedRowId = cl.rowId;
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
    // If pagination is needed for filtered results, call fetchFilteredStudents
    // const page = row.page;
    // const limit = row.limit;
    // this.fetchFilteredStudents(page, limit);
  }
  async fetchCount() {
    // This might need adjustment if counting filtered students
    var totRec = await this.apiController.fetchCount('qu');
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
    }
  }

  // --- Dialog methods (Keep if needed for other actions, remove if not) ---
  showActionDialog(student: any) {
    this.selectedStudent = student;
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedCenter = null;
    this.filteredCenters = [];
    this.displayDialog = true;
  }

  hideDialog() {
    this.displayDialog = false;
    this.selectedStudent = null;
  }

  searchCenter(event: any) {
    let query = event.query;
    this.filteredCenters = this.centers.filter(center => {
      return center.title.toLowerCase().includes(query.toLowerCase());
    });
  }
  // --- End of Dialog methods ---
  async submitMarks() {
    if (this.selectedStudents && this.selectedStudents.length > 0 && this.selectedChecker) {
    // console.log('Assigning Copies:', {
      //   students: this.selectedStudents.map((s:any) => s.id), // Send only IDs or necessary data
      //   examId: this.selectedExam,
      //   classId: this.selectedClass,
      //   facultyId: this.selectedFaculty,
      //   checkerId: this.selectedChecker,
      //   bundleNo: this.bundleNo
      // });
      var studentids: any[]=[];
console.log("this.selectedStudents========",this.selectedStudents);
      this.selectedStudents.forEach((student:any) => {
        studentids.push({"student_row_id":student.id, "marks":student.marks});
      }
      );
      // Call the API to create the bundle/assignment
       await this.apiController.addMarks(
        studentids, // Send the selected student objects or just IDs
          this.selectedExam,
          this.selectedClass,
          this.selectedFaculty, // Pass faculty
          this.selectedChecker,
          this.bundleNo
      );

   

    } else {
      console.error('Form is not complete. Select students and a checker.');
      // Optionally show a message to the user
    }
    }

}
