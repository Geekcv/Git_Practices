import { Component, OnInit } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-merit-list-center-wise',
  templateUrl: './merit-list-center-wise.component.html',
  styleUrls: ['./merit-list-center-wise.component.css']
})
export class MeritListCenterWiseComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  centers: any[] = [];
  classes: any[] = [];

  // Selected filter values
  selectedExamSession: any = null;
  selectedCenter: any = null;
  selectedFaculty: string = '0'; // Default value
  selectedClass: any = null;

  // Data for the report table
  centerWiseResults: any[] = [];
  submitted: boolean = false;

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService, public jsonlist: JsonListService
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions =  [];
    // Fetch centers
    this.centers =  [];
    
    this.fetchExams();
    this.fetchExamCenter();
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push(
          {
            name: tempClientDAta[i].center, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i], // Keep original data if needed (e.g., for code)
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchClasses() {
    this.selectedClass = null; // Reset class when faculty changes
    this.classes = [];
    this.centerWiseResults = []; // Clear previous results
    this.submitted = false;
    if (this.selectedFaculty) {
      this.classes = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,1,100) || [];
      // Map data if needed
    }
  }

  async fetchCenterWiseResults() {
    this.submitted = true;
    this.centerWiseResults = []; // Clear previous results
    if (!this.selectedExamSession || !this.selectedCenter || !this.selectedFaculty || !this.selectedClass) {
      console.error("Please select all filter values.");
      this.utiltiesService.openSnackBar("Please select Exam Session, Center, Faculty, and Class.");
      return;
    }

    console.log('Fetching center-wise results for:', this.selectedExamSession, this.selectedCenter, this.selectedFaculty, this.selectedClass);

    // Call API to fetch results based on all filters
    const fetchedData = await this.apiController.fetchCenterWiseResultsReport(
        this.selectedExamSession,
        this.selectedCenter,
        this.selectedFaculty,
        this.selectedClass
    ) || []; // Create this API call

    // Map fetchedData to the structure needed by the table
    this.centerWiseResults = fetchedData.map((item: any) => ({
        name: item.student_name, // Adjust field names based on API response
        fatherHusbandName: item.father_name,
        address: item.address,
        className: item.class_name,
        centerCode: item.center_code,
        rollNo: item.roll_no,
        phoneNo: item.phone,
        marks: item.marks,
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched center-wise results:', this.centerWiseResults);
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getFaculty(id: any): string | null {
    const item = this.jsonlist.faculty.find(c => c.value === id);
    return item ? item.title : null;
  }
  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }

   getCenterCode(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    // Adjust based on your center data structure
    return item ? item.data?.center_code : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.row_id === id);
    return item ? item.class_name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.centerWiseResults && this.centerWiseResults.length > 0) {
      console.log("Exporting data...", this.centerWiseResults);
      this.centerWiseResults.forEach((item: any) => {
        delete item.id; // Remove ID if not needed in export
        delete item.originalData; // Remove original data if not needed in export
      });
      const filename = `CenterWiseResult_${this.getCenterName(this.selectedCenter) || 'Export'}`;
      this.utiltiesService.exportAsExcelFile(this.centerWiseResults, filename);
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'MeritListCenterWiseReport'); // Adjust the ID of the report section
  }
}
