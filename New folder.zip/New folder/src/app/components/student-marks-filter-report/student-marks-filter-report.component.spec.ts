import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentMarksFilterReportComponent } from './student-marks-filter-report.component';

describe('StudentMarksFilterReportComponent', () => {
  let component: StudentMarksFilterReportComponent;
  let fixture: ComponentFixture<StudentMarksFilterReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentMarksFilterReportComponent]
    });
    fixture = TestBed.createComponent(StudentMarksFilterReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
