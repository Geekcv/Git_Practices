import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent {
  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.studentTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any =  this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  ngOnInit() {
    this.fetchCount();
    this.fetchStudents();
  }

  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.savestudent(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchStudents();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = 5) {
    var tempClientDAta = await this.apiController.fetchStudents(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push(
          {
            "student_name": tempClientDAta[i].student_name,
            "father_name": tempClientDAta[i].father_name,
            "dob": new Date(tempClientDAta[i].dob).toLocaleDateString(),
            "address": tempClientDAta[i].address,
            "mobile": tempClientDAta[i].mobile_no,
            "data": tempClientDAta[i],
            "rowId": tempClientDAta[i].row_id
          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
  editClient(cl: any) {
   // console.log(cl);
    this.savedForm=cl.data;
    this.savedForm.dob=new Date(cl.data.dob)
    
    this.selectedRowId = cl.rowId;
   // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('students');
 // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchStudents();
  }

}
