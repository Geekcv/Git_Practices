import { Injectable } from '@angular/core';
import { JsonListService } from './json-list.service';
import { FormControl, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class FormsService {

  constructor(private jsonList: JsonListService) { }
  /**
   * Forms Json Data
   */
  studentForm = {
    "formName": "Add New Student",
    "flex": "33",
    "elements": [
      
      {
        "type": "text",
        "id": "student_name",
        "value": "",
        "name": "student_name",
        "label": "Student Name",
        "required": true,
      },
      {
        "type": "text",
        "id": "father_name",
        "value": "",
        "name": "father_name",
        "label": "F/H Name",
        "required": true,
      },

      {
        "type": "radio",
        "id": "gender", "value": "",
        "name": "gender",
        "label": "Gender",
        "options": this.jsonList.gender,
        "required": true,
      },
      {
        "type": "text",
        "id": "address",
        "value": "",
        "name": "address",
        "label": "Address",
        "required": false,
      },
      {
        "type": "select-list",
        "id": "city", "value": "",
        "name": "city",
        "label": "City",
        "options": this.jsonList.cities,
        "required": false,
      },
      {
        "type": "select-list",
        "id": "state", "value": "",
        "name": "state",
        "label": "State",
        "options": this.jsonList.state,
        "required": false,
      },
  
      {
        "type": "num",
        "id": "zip_code",
        "value": "",
        "name": "zip_code",
        "label": "Zip Code",
        "required": false,
      },
      {
        "type": "date",
        "id": "dob",
        "value": "",
        "name": "dob",
        "label": "Date of Birth",
        "required": false,
      },

      {
        "type": "num",
        "id": "adhar_number",
        "value": "",
        "name": "adhar_number",
        "label": "Adhar Number",
        "required": false,
      },
      {
        "type": "num",
        "id": "phone_r",
        "value": "",
        "name": "phone_r",
        "label": "Phone (R)",
        "required": false,
      },

      {
        "type": "num",
        "id": "phone_o",
        "value": "",
        "name": "phone_o",
        "label": "Phone (O)",
        "required": false,
      },
      {
        "type": "num",
        "id": "mobile_no",
        "value": "",
        "name": "mobile_no",
        "label": "Mobile No.",
        "required": false,
      },
      
      {
        "type": "text",
        "id": "education",
        "value": "",
        "name": "education",
        "label": "Education",
        "required": false,
      },
      {
        "type": "select-list",
        "id": "medium", "value": "",
        "name": "medium",
        "label": "Medium",
        "options": this.jsonList.medium,
        "required": false,
      },

      {
        "type": "num",
        "id": "account_no",
        "value": "",
        "name": "account_no",
        "label": "Account No.",
        "required": false,
      },

      {
        "type": "text",
        "id": "account_name",
        "value": "",
        "name": "account_name",
        "label": "Account Name",
        "required": false,
      },
      {
        "type": "text",
        "id": "bank_name",
        "value": "",
        "name": "bank_name",
        "label": "Bank Name",
        "required": false,
      },
      {
        "type": "num",
        "id": "ifsc_code",
        "value": "",
        "name": "ifsc_code",
        "label": "IFSC Code",
        "required": false,
      },

      {
        "type": "text",
        "id": "remarks",
        "value": "",
        "name": "remarks",
        "label": "Remarks",
        "required": false,
      },


    ]
  };
  userForm = {
    "formName": "Add New User",
    "flex": "50",
    "elements": [
      {
        "type": "text",
        "id": "username",
        "value": "",
        "name": "username",
        "label": "Username",
        "required": false,
      },

      {
        "type": "text",
        "id": "password",
        "value": "",
        "name": "password",
        "label": "Password",
        "required": false,
      },
      {
        "type": "select-list",
        "id": "usertype",
        "value": "",
        "name": "usertype",
        "label": "User type",
        "required": false,
        "options": this.jsonList.userType
      },




    ]
  };
  branchForm = {
    "formName": "Add Branch",
    "flex": "33",
    "elements": [
      {
        "type": "text",
        "id": "branch_name",
        "value": "",
        "name": "branch_name",
        "label": "Branch Name",
        "required": false
      },
      {
        "type": "text",
        "id": "branch_head_name",
        "value": "",
        "name": "branch_head_name",
        "label": "Branch Head Name",
        "required": false
      },
      {
        "type": "text",
        "id": "address",
        "value": "",
        "name": "address",
        "label": "Address",
        "required": false
      },
      {
        "type": "select-list",
        "id": "city",
        "value": "",
        "name": "city",
        "label": "City",
        "options": this.jsonList.cities,
        "required": false
      },
      {
        "type": "num",
        "id": "mobile_no",
        "value": "",
        "name": "mobile_no",
        "label": "Mobile No.",
        "required": false
      }
    ]
  };
  examCenterForm ={
    "formName": "Add Center",
    "flex": "50",
    "elements": [
      {
        "type": "select-list",
        "id": "branch_id",
        "value": "",
        "name": "branch_id",
        "label": "Branch",
        "options": [],
        "required": true
      },
      {
        "type": "text",
        "id": "center",
        "value": "",
        "name": "center",
        "label": "Center Name",
        "required": true
      },
      {
        "type": "text",
        "id": "center_head_name",
        "value": "",
        "name": "center_head_name",
        "label": "Center Head Name",
        "required": true
      },
      {
        "type": "text",
        "id": "email",
        "value": "",
        "name": "email",
        "label": "Email",
        "required": false
      },
      {
        "type": "date",
        "id": "date_of_birth",
        "value": "",
        "name": "date_of_birth",
        "label": "Date of Birth",
        "required": false
      },
      {
        "type": "textarea",
        "id": "address",
        "value": "",
        "name": "address",
        "label": "Address",
        "required": true
      },
      
      {
        "type": "select-list",
        "id": "state",
        "value": "",
        "name": "state",
        "label": "State",
        "options": this.jsonList.state,
        "required": true
      },
      {
        "type": "select-list",
        "id": "city",
        "value": "",
        "name": "city",
        "label": "City",
        "options": this.jsonList.cities,
        "required": true
      },
      {
        "type": "num",
        "id": "std_code",
        "value": "",
        "name": "std_code",
        "label": "STD Code",
        "required": false
      },
      {
        "type": "num",
        "id": "phone_no",
        "value": "",
        "name": "phone_no",
        "label": "Phone No.",
        "required": false
      },
      {
        "type": "num",
        "id": "mobile_no",
        "value": "",
        "name": "mobile_no",
        "label": "Mobile No.",
        "required": false
      },
      {
        "type": "num",
        "id": "account_no",
        "value": "",
        "name": "account_no",
        "label": "Account Number",
        "required": false
      },
      {
        "type": "text",
        "id": "account_name",
        "value": "",
        "name": "account_name",
        "label": "Account Name",
        "required": false
      },
      {
        "type": "text",
        "id": "bank_name",
        "value": "",
        "name": "bank_name",
        "label": "Bank Name",
        "required": false
      },
      {
        "type": "text",
        "id": "branch_name",
        "value": "",
        "name": "branch_name",
        "label": "Branch Name",
        "required": false
      },
      {
        "type": "text",
        "id": "ifsc_code",
        "value": "",
        "name": "ifsc_code",
        "label": "IFSC Code",
        "required": false
      }
    ]
  };
  classesForm = {
    "formName": "Add Class",
    "flex": "33",
    "elements": [
      {
        "type": "select-list",
        "id": "faculty",
        "value": "",
        "name": "faculty",
        "label": "Faculty",
        "options": this.jsonList.faculty,
        "required": false
      },
      {
        "type": "text",
        "id": "name",
        "value": "",
        "name": "name",
        "label": "Name",
        "required": false
      },
      {
        "type": "num",
        "id": "first_price",
        "value": "",
        "name": "first_price",
        "label": "1st Price",
        "required": false
      },
      {
        "type": "num",
        "id": "second_price",
        "value": "",
        "name": "second_price",
        "label": "IInd Price",
        "required": false
      },
      {
        "type": "num",
        "id": "third_price",
        "value": "",
        "name": "third_price",
        "label": "IIIrd Price",
        "required": false
      },
      {
        "type": "num",
        "id": "merit_list_upto_10_price",
        "value": "",
        "name": "merit_list_upto_10_price",
        "label": "Merit List upto 10 (Price)",
        "required": false
      },
      {
        "type": "num",
        "id": "marks_greater_equal_to_90",
        "value": "",
        "name": "marks_greater_equal_to_90",
        "label": "Marks >= 90 (Price)",
        "required": false
      },
      {
        "type": "num",
        "id": "marks_70_to_less_then_90",
        "value": "",
        "name": "marks_70_to_less_then_90",
        "label": "Marks >= 70 and <90 (Price)",
        "required": false
      },
      {
        "type": "num",
        "id": "marks_50_to_less_then_70",
        "value": "",
        "name": "marks_50_to_less_then_70",
        "label": "Marks >= 50 and <70 (Price)",
        "required": false
      }
    ]
  };
  sheetCheckerForm = {
    "formName": "Add Sheet Checker",
    "flex": "50",
    "elements": [
      {
        "type": "text",
        "id": "name",
        "value": "",
        "name": "name",
        "label": "Name",
        "required": true
      },
     
      {
        "type": "num",
        "id": "mobile",
        "value": "",
        "name": "mobile",
        "label": "Mobile",
        "required": false
      }, {
        "type": "textarea",
        "id": "address",
        "value": "",
        "name": "address",
        "label": "Address",
        "required": false
      },
    ]
  };
  examForm = {
    "formName": "Add Exam Session",
    "flex": "33",
    "elements": [
      {
        "type": "text",
        "id": "name",
        "value": "",
        "name": "name",
        "label": "Name",
        "required": false
      },
      {
        "type": "date",
        "id": "exam_date",
        "value": "",
        "name": "exam_date",
        "label": "Exam Date",
        "required": false
      }
    ]
  };

  bundleForm = {
    "formName": "Bundle Issue",
    "flex": "33",
    "elements": [
      {
        "type": "select-list",
        "id": "faculty",
        "value": "",
        "name": "faculty",
        "options":this.jsonList.faculty,
        "label": "Faculty",
        "required": false,
      },

      {
        "type": "num",
        "id": "bandal_no",
        "value": "",
        "name": "bandal_no",
        "label": "Bundle No.",
        "required": false,
      },
     
      {
        "type": "select-list",
        "id": "exam_session",
        "value": "",
        "name": "exam_session",
        "options":[],
        "label": "Exam Session",
        "required": false,
      },
      {
        "type": "select-list",
        "id": "class_id",
        "value": "",
        "name": "class_id",
        "options":[],
        "label": "Class",
        "required": false,
      },
      {
        "type": "select-list",
        "id": "copy_checker_id",
        "value": "",
        "name": "copy_checker_id",
        "options":[],
        "label": "Copy Checker",
        "required": false,
      },


    ]
  };
  clientForm = {
    "formName": "Add New Client",
    "formid": "clientForm",
    "flex": "50",
    "elements": [
      {
        "type": "text",
        "id": "clientname",
        "value": "",
        "name": "clientName",
        "label": "Client Name",
        "required": false,
      },


      {
        "type": "num",
        "id": "contact", "value": 0,
        "name": "contactnumber",
        "label": "Contact Number",
        "required": false,
      }, {
        "type": "radio",
        "id": "clienttype", "value": "",
        "name": "clientType",
        "label": "Client Type",
        "options": this.jsonList.clientType,
        "required": false,
      }, {
        "type": "textarea",
        "id": "address", "value": "",
        "noofrows": 3,
        "noofcols": 10,
        "name": "clientAddress",
        "label": "Client Address",
        "required": false,
      },
    ],
    "formGroup": {
      "clientName": new FormControl('', Validators.required),
      "contactnumber": new FormControl(0, Validators.required),
      "clientType": new FormControl('', Validators.required),
      "clientAddress": new FormControl('', Validators.required),
    }
  };
  //=================================================================//

  /**
   * Table Data Json
   */
  userDataTable = {
    "title": "Users List",
    "searchFields": ["name","email", "city", "registerationno"],
    "tableDataHeader": [
      { "name": "name", "title": "Name" ,},
      { "name": "email", "title": "Email" },
      { "name": "city", "title": "City" },
      { "name": "registerationno", "title": "Registration No." },
      // { "name": "qrcode", "title": "QR Code Link" },
    ]
  }
  sheetCheckerTableData = {
    "title": "Sheet Checker List",
    "searchFields": ["checker_name"],
    "tableDataHeader": [
      { "name": "name", "title": "Checker Name" },
      { "name": "address", "title": "Address" },
      { "name": "mobile", "title": "Mobile" },
    ]
  }
  examCenterTableData = {
    "title": "Exam Center List",
    "searchFields": ["center", "center_head_name", "email"],
    "tableDataHeader": [
      { "name": "center", "title": "Center" },
      { "name": "center_head_name", "title": "Head Name" },
      { "name": "email", "title": "Email" },
      { "name": "mobile_no", "title": "Mobile" },
    ]
  }
  branchTableData = {
    "title": "Branch List",
    "searchFields": ["branch_name"],
    "tableDataHeader": [
      { "name": "branch_name", "title": "Branch" },
      { "name": "branch_head_name", "title": "Head Name" },

      { "name": "mobile", "title": "Mobile" },
    ]
  }
  studentTableData = {
    "title": "Student List",
    "searchFields": ["student_name"],
    "tableDataHeader": [
      { "name": "student_name", "title": "Student Name" },
      { "name": "father_name", "title": "Father Name" },
      { "name": "dob", "title": "Date Of Birth" },
      { "name": "mobile", "title": "Mobile" },
      { "name": "address", "title": "Address" },
    ]
  }


  classTableData = {
    "title": "Classes List",
    "searchFields": ["name"],
    "tableDataHeader": [
      { "name": "name", "title": "Class" },
      { "name": "first_price", "title": "First Price" },
      { "name": "second_price", "title": "Second Price" },
      { "name": "third_price", "title": "Third Price" },
    ]
  }
  examTableData = {
    "title": "Exam Session List",
    "searchFields": ["name"],
    "tableDataHeader": [
      { "name": "name", "title": "Exam Name" },
      { "name": "exam_date", "title": "Date" },
    ]
  }
  //======================================================================//
}
