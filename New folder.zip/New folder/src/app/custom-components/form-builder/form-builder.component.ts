import { Component, EventEmitter, Input, Output, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css'],
})
export class FormBuilderComponent  {
  @Input() forms: any;
  @Input() formdata: any;
  @Output() formdataChange: EventEmitter<any> = new EventEmitter<any>();
  // @Input() form: FormGroup;
  @Output() formChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() formValidityChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  Output: any = {};


  constructor(private cdr: ChangeDetectorRef, private utilities: UtiltiesService, private fb: FormBuilder) {
    // this.form = this.fb.group({});

  }
  // ngAfterViewInit() {
  //  // console.log(this.forms);
  //   var tempFbGroup: any = {};
  //   this.forms.elements.array.forEach((element:any) => {
  //   tempFbGroup[element.name] = new FormControl(element.value, element.required ? Validators.required : null);
  //   });
  //   this.form = this.fb.group(tempFbGroup);

  // }


}
