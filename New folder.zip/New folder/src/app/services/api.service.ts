import { HttpClient, HttpEvent, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {


  public serverUrl = 'http://192.168.68.87:3000'; 
  // public serverUrl = 'https://shikshansansthan.ratnasangh.com'; 
 
  public apiUrl = this.serverUrl + '/common/';
  private gAuthUrl = this.apiUrl + '/auth/google';
  private fbAuthUrl = this.apiUrl + '/auth/fb';
  private token: string | null | undefined;

  constructor(private http: HttpClient, private authService: AuthService) {
    this.token = this.authService.getToken();
    // console.log(this.token);
  }

  getFacebookAuthUrl(): string {
    return this.fbAuthUrl;
  }
  getGoogleAuthUrl(): string {
    return this.gAuthUrl;
  }
  private buildHeaders(): HttpHeaders {
    // Customize headers here if needed
    return new HttpHeaders({
      'Content-Type': 'application/json',

      "Authorization": "Bearer " + this.token,
      // Add more headers as required
    });
  }

  get<T>(url: string, params?: HttpParams): Observable<T> {
    const headers = this.buildHeaders();
    return this.http.get<T>(`${this.apiUrl}/${url}`, { headers, params });
  }

  postJson<T>(url: any, data: any) {
    return new Promise((resolve, reject) => {
      this.token = this.authService.getToken();
      const headers = this.buildHeaders();
      // console.log(data);
      // console.log("this.token=============");
      // console.log(this.token);
      var payload = (data);
      this.http.post(`${this.serverUrl}${url}`, payload, { headers: headers, responseType: 'text' as 'json' }).subscribe((data) => {
        // console.log(data);
        var respData: any = (data);
        // console.log(respData);
        if (respData.status != '2') {
          resolve(respData);
        } else {
          this.authService.logoutUser();
        }
      });
    });
  }
  postUrl<T>(data: any, url: any) {
    return new Promise((resolve, reject) => {
      this.token = this.authService.getToken();
      const headers = this.buildHeaders();
      // console.log(data);
      // console.log("this.token=============");
      // console.log(this.token);
      var payload = this.encodeReqData(data);
      this.http.post<T>(`${this.apiUrl}/${url}`, { "payload": payload }, { headers: headers, responseType: 'text' as 'json' }).subscribe((data) => {
        // console.log(data);
        var respData = this.decodeReqData(data);
        // console.log(respData);
        if (respData.status != '2') {
          resolve(respData);
        } else {
          this.authService.logoutUser();
        }
      });
    });
  }

  uploadMFiles<T>(formData: FormData, appId: any, userId: any) {
    return new Promise((resolve, reject) => {
      formData.append('appId', appId);
      formData.append('userId', userId);
      this.http.post<T>(`${this.apiUrl}/uploadM`, formData, {
        // headers: headers,
        reportProgress: true,
        responseType: 'json'
      }).subscribe((data: any) => {
        // console.log(data);

        // console.log(respData);
        if (data.status != '2') {
          resolve(data);
        } else {
          this.authService.logoutUser();
        }
      });
    });
  }
  uploadMFilesOb(formData: FormData, appId: any, userId: any): Observable<HttpEvent<any>> {

    // this.token = this.authService.getToken();
    // console.log(this.token);
    // const headers = this.buildHeaders();

    formData.append('appId', appId);
    formData.append('userId', userId);
    const req = new HttpRequest('POST', `${this.apiUrl}/uploadM`, formData, {
      // headers: headers,
      reportProgress: true,
      responseType: 'json'
    });

    return this.http.request(req);
  }
  post<T>(data: any) {
    return new Promise((resolve, reject) => {
      this.token = this.authService.getToken();
      const headers = this.buildHeaders();
    // console.log(data);
    // console.log("this.token=============");
    // console.log(this.token);
      var payload = this.encodeReqData(data);
      this.http.post<T>(`${this.apiUrl}`, { "payload": payload }, { headers: headers, responseType: 'text' as 'json' }).subscribe((data) => {
        // console.log(data);
        var respData = this.decodeReqData(data);
        // console.log(respData);
        if (respData.status != '2') {
          resolve(respData);
        } else {
          this.authService.logoutUser();
        }
      });
    });
  }
  encodeReqData(data: any) {
    return btoa(unescape(encodeURIComponent(JSON.stringify(data))));
  }
  decodeReqData(data: any) {
    return JSON.parse(decodeURIComponent((atob(data))));
  }
}
