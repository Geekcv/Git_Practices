import { TestBed } from '@angular/core/testing';

import { UtiltiesService } from './utilties.service';

describe('UtiltiesService', () => {
  let service: UtiltiesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UtiltiesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
