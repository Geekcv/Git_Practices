import { Routes } from '@angular/router';
import { AccountComponent } from 'app/modules/admin/account/account.component';

export default [
    {
        path: '',
        component: AccountComponent,
    },
] as Routes;
