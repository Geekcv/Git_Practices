import { Routes } from '@angular/router';
import { ResearchersDetailsComponent } from 'app/modules/admin/adminSide/researchers-details/researchers-details.component';

export default [
    {
        path: '',
        component: ResearchersDetailsComponent,
    },
] as Routes;
