import { CommonModule, NgClass, NgFor, NgIf, NgStyle, NgSwitch, NgSwitchCase } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?: string;
  margin?: string;
  width?: string;
  height?: string;
  bordercolor?: string;
  radius?: string;
  opacity?: string;
  rows?: any;
  cols?: any
  checked?: any
  min?: any
  max?: any
}

@Component({
  selector: 'app-form-preview',
  imports: [NgFor, NgSwitchCase, NgSwitch, NgStyle,NgClass,CommonModule,FormsModule],

  templateUrl: './form-preview.component.html',
  styleUrl: './form-preview.component.scss'
})
export class FormPreviewComponent {

  @Input() formItems: FormElement[];
  @Input() forms_row_id:string;

  formData: any = {};


  constructor(
        private Apicontroller: ApicontrollerService
    
  ){

  }

onCheckboxGroupChange(event: any, key: string) {
    if (!this.formData[key]) {
        this.formData[key] = [];
    }

    const value = event.target.value;
    if (event.target.checked) {
        this.formData[key].push(value);
    } else {
        this.formData[key] = this.formData[key].filter((v: any) => v !== value);
    }
}

onFileChange(event: any, key: string) {
    const file = event.target.files[0];
    this.formData[key] = file;
}

async submitForm() {
    console.log('Submitted Form:', this.formData);
    console.log("current form row_id ",this.forms_row_id)
    var formsubdata;
    var formId;

    var data =[
      formsubdata = this.formData,
      formId = this.forms_row_id
    ]

    console.log("data",data)

    const resp = await this.Apicontroller.SaveForms(data);
    console.log("resp:-",resp)
}


yourStyle(item: any) {
  return {
      'font-size': item.fontSize,
      color: item.fontColor,
      'font-family': item.fontFamily,
      'font-weight': item.fontWeight,
      'border-style': item.borderStyle,
      padding: item.padding,
      'background-color': item.bgColor,
      'border-width': item.borderWidth,
      margin: item.margin,
      height: item.height,
      width: item.width,
      'border-color': item.bordercolor,
      'border-radius': item.radius,
  };
}

blockSpace(event: KeyboardEvent) {
  if (event.key === ' ') {
    event.preventDefault(); // Block spacebar
  }
}

markTouched(key: string) {
  this.formTouched[key] = true;
}

isInvalidEmail(item: any): boolean {
  const value = this.formData[item.key];
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!this.formTouched[item.key]) return false;

  return item.required && (!value || !emailRegex.test(value));
}

formTouched: { [key: string]: boolean } = {};



  

}
