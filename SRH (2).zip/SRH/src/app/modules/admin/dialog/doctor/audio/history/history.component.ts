import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-history',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './history.component.html',
  styleUrl: './history.component.scss'
})
export class HistoryComponent {
  
  constructor(
        @Inject(MAT_DIALOG_DATA) public data: {patient: string},
            private dialogRef: MatDialogRef<HistoryComponent> // Inject MatDialogRef           
        
    ){
  
    }
  
    exitbtn(){
  
      this.dialogRef.close();
  
    }
}
