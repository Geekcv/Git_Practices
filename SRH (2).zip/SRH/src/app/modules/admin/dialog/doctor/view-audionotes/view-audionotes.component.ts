import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-view-audionotes',
  imports: [ MatDialogModule,MatButtonModule],
  templateUrl: './view-audionotes.component.html',
  styleUrl: './view-audionotes.component.scss'
})
export class ViewAudionotesComponent {

}
