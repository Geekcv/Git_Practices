import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }
   


@Component({
  selector: 'app-telepsychiatry-sessions',
  imports: [MatTableModule, MatButtonModule,
    MatIconModule,MatInputModule,MatPaginatorModule],
  templateUrl: './telepsychiatry-sessions.component.html',
  styleUrl:'./telepsychiatry-sessions.component.css'
})
export class TelepsychiatrySessionsComponent {
 displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      // 'patient_gender',

      'user_contact_number1',
      'user_contact_number2',
      'user_contact_number3',
      'user_contact_number4',
      'user_contact_number5',
      'user_contact_number6',
      'user_contact_number7',
      'user_contact_number8',
      'user_contact_number9',
      'user_contact_number10',

      'actions'
    ];
  

   role :any ='';

   isSearchActive = false;

    patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router,
       private _matDialog: MatDialog
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.Patients();
   }

   ngAfterViewInit() {
    this.patient.paginator = this.paginator; // Set paginator after view init
  }

   page: number = 1; // Default to first page
   async Patients() {
     try {
       const resp = await this.Apicontroller.fetchPatients('common',this.page);
      //  console.log("Patients", resp);
       this.patient.data = resp.data as Patient[]; // Type assert to Doctor[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 




  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
        this.isSearchActive = true;
        this.patient.filter = trimmedQuery;

        if (this.patient.paginator) {
            this.patient.paginator.firstPage(); // Reset to first page after search
        }
    } else {
        this.isSearchActive = false;
        this.patient.filter = ''; // Clear filter

        // Reset the paginator and restore original data
        setTimeout(() => {
            this.patient.paginator = this.paginator;
        });
    }
}

  exportToExcel(): void {
      const dataToExport = this.patient.data.map((patient) => ({
        ID: patient.user_row_id,
        Name: patient.patient_name,
        Email: patient.patient_email,
        Gender: patient.patient_gender,
        Contact: patient.user_contact_number,
      }));
  
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
  
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      saveAs(data, 'Patients_List.xlsx');
    }


    refresh(){
      console.log("refresh----")
      this.Patients();
      // window.location.reload();
    }
  
    addpatientdialog(){
        // const dialogRef = this._matDialog.open(AddpatientdialogComponent);
      }



      deletebtn(){
      
          const dialogRef = this._matDialog.open(DeldialogComponent);
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }


        viewteleDetails(patient_rowId: string) {
          console.log("viewdata",patient_rowId)
          this.router.navigate(['viewTeleSessionsdetails', patient_rowId]);
          // this.router.navigate(['patientpanel', patient_rowId]);

          
        }
}
