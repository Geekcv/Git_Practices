import { Routes } from '@angular/router';
import { ViewOpdSessionsdetailsComponent } from 'app/modules/admin/doctorSide/view-opd-sessionsdetails/view-opd-sessionsdetails.component';

export default [
    {
        path: '',
        component: ViewOpdSessionsdetailsComponent,
    },
] as Routes;
