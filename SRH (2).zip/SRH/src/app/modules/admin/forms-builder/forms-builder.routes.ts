import { Routes } from '@angular/router';
import { FormsBuilderComponent } from 'app/modules/admin/forms-builder/forms-builder.component'

export default [
    {
        path: '',
        component: FormsBuilderComponent,
    },
] as Routes;
