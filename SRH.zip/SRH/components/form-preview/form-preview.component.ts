import { NgClass, NgFor, NgIf, NgStyle, NgSwitch, NgSwitchCase, CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?: string;
  margin?: string;
  width?: string;
  height?: string;
  bordercolor?: string;
  radius?: string;
  opacity?: string;
  rows?: any;
  cols?: any
  checked?: any
  min?: any
  max?: any
}

@Component({
  selector: 'app-form-preview',
  imports: [NgFor, NgSwitchCase, NgSwitch, NgStyle,NgIf,NgClass,CommonModule,FormsModule],
  templateUrl: './form-preview.component.html',
  styleUrl: './form-preview.component.scss'
})
export class FormPreviewComponent {

  @Input() formItems: FormElement[];

  formData: any = {};

onCheckboxGroupChange(event: any, key: string) {
    if (!this.formData[key]) {
        this.formData[key] = [];
    }

    const value = event.target.value;
    if (event.target.checked) {
        this.formData[key].push(value);
    } else {
        this.formData[key] = this.formData[key].filter((v: any) => v !== value);
    }
}

onFileChange(event: any, key: string) {
    const file = event.target.files[0];
    this.formData[key] = file;
}

submitForm() {
    console.log('Submitted Form:', this.formData);
}


yourStyle(item: any) {
  return {
      'font-size': item.fontSize,
      color: item.fontColor,
      'font-family': item.fontFamily,
      'font-weight': item.fontWeight,
      'border-style': item.borderStyle,
      padding: item.padding,
      'background-color': item.bgColor,
      'border-width': item.borderWidth,
      margin: item.margin,
      height: item.height,
      width: item.width,
      'border-color': item.bordercolor,
      'border-radius': item.radius,
  };
}


  

}
