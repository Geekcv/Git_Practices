﻿using System;
using System.Data;
using Npgsql;

namespace StrongBillingSoftware
{
    public class DatabaseHelper
    {
        private string connectionString = "Host=localhost;Username=postgres;Password=Admin;Database=BillingSoft"; // Replace with your DB connection string

        public DataTable ExecuteQuery(string query, NpgsqlParameter[] parameters = null)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(query, conn);
                if (parameters != null)
                {
                    dataAdapter.SelectCommand.Parameters.AddRange(parameters);
                }
                DataTable dataTable = new DataTable();
                conn.Open();
                dataAdapter.Fill(dataTable);
                return dataTable;
            }
        }

        public void ExecuteNonQuery(string query, NpgsqlParameter[] parameters = null)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

}
