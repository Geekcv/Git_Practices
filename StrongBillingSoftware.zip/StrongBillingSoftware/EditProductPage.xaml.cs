﻿using System;
using System.Data;
using System.Windows;
using Npgsql;

namespace StrongBillingSoftware
{
    public partial class EditProductPage : Window
    {
        private DatabaseHelper db;
        private int productId;

        public EditProductPage(DataRow productRow)
        {
            InitializeComponent();
            db = new DatabaseHelper();
            LoadCategories();

            // Populate the fields with current product data
            productId = Convert.ToInt32(productRow["product_id"]);
            ProductNameTextBox.Text = productRow["name"].ToString();
            PriceTextBox.Text = productRow["price"].ToString();
            StockTextBox.Text = productRow["stock"].ToString();
            CategoryComboBox.SelectedValue = productRow["category_id"];
        }

        // Load categories from database
        private void LoadCategories()
        {
            string query = "SELECT * FROM categories";
            var categories = db.ExecuteQuery(query);

            CategoryComboBox.ItemsSource = categories.DefaultView;
            CategoryComboBox.DisplayMemberPath = "name";
            CategoryComboBox.SelectedValuePath = "category_id";
        }

        // Save Changes button click event
        private void OnSaveChangesClick(object sender, RoutedEventArgs e)
        {
            string productName = ProductNameTextBox.Text;
            decimal price = Convert.ToDecimal(PriceTextBox.Text);
            int stock = Convert.ToInt32(StockTextBox.Text);
            int categoryId = Convert.ToInt32(CategoryComboBox.SelectedValue);

            string query = "UPDATE products SET name = @name, price = @price, stock = @stock, category_id = @category_id WHERE product_id = @product_id";
            var parameters = new NpgsqlParameter[]
            {
                new NpgsqlParameter("@name", productName),
                new NpgsqlParameter("@price", price),
                new NpgsqlParameter("@stock", stock),
                new NpgsqlParameter("@category_id", categoryId),
                new NpgsqlParameter("@product_id", productId)
            };

            db.ExecuteNonQuery(query, parameters);
            MessageBox.Show("Product updated successfully.");
            this.Close();
        }

        // Cancel button click event
        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
