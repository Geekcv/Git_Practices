﻿using System;
using System.Windows;
using Npgsql;
using System.Security.Cryptography;
using System.Text;
using System.Data;

namespace StrongBillingSoftware
{
    public partial class LoginPage : Window
    {
        private DatabaseHelper db = new DatabaseHelper();

        public LoginPage()
        {
            InitializeComponent();
        }

        // Method to hash the password for comparison
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void OnLoginClick(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;
            string hashedPassword = HashPassword(password);

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            string query = "SELECT * FROM users WHERE username = @username AND password = @password";
            var parameters = new NpgsqlParameter[]
            {
                new NpgsqlParameter("@username", username),
                new NpgsqlParameter("@password", hashedPassword)
            };

            DataTable result = db.ExecuteQuery(query, parameters);

            if (result.Rows.Count > 0)
            {
                string role = result.Rows[0]["role"].ToString();
                MessageBox.Show("Login successful! Welcome " + role);
                // You can redirect to a new window based on the user role here
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        private void OnRegisterClick(object sender, RoutedEventArgs e)
        {
            RegisterPage registerPage = new RegisterPage();
            registerPage.Show();
            this.Close();
        }
    }
}
