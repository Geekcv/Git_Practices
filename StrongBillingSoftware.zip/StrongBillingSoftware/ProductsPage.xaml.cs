﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Npgsql;

namespace StrongBillingSoftware
{
    public partial class ProductsPage : Page
    {
        DatabaseHelper db = new DatabaseHelper();

        public ProductsPage()
        {
            InitializeComponent();
            LoadProducts();
        }

        // Load Products from the database and bind to DataGrid
        private void LoadProducts()
        {
            string query = "SELECT * FROM products";
            DataTable products = db.ExecuteQuery(query);
            ProductsGrid.ItemsSource = products.DefaultView;
        }

        // Add Product button click event
        private void OnAddProductClick(object sender, RoutedEventArgs e)
        {
            AddProductPage addProductPage = new AddProductPage();
            addProductPage.ShowDialog(); // Show as dialog to return to the page
            LoadProducts(); // Reload products after adding a new one
        }

        // Edit Product button click event
        private void OnEditProductClick(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (DataRowView)ProductsGrid.SelectedItem;
            if (selectedProduct != null)
            {
                EditProductPage editProductPage = new EditProductPage(selectedProduct.Row);
                editProductPage.ShowDialog();
                LoadProducts(); // Reload products after editing
            }
            else
            {
                MessageBox.Show("Please select a product to edit.");
            }
        }

        // Delete Product button click event
        private void OnDeleteProductClick(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (DataRowView)ProductsGrid.SelectedItem;
            if (selectedProduct != null)
            {
                int productId = Convert.ToInt32(selectedProduct["product_id"]);
                string query = "DELETE FROM products WHERE product_id = @id";
                var parameters = new NpgsqlParameter[] { new NpgsqlParameter("@id", productId) };

                db.ExecuteNonQuery(query, parameters);
                LoadProducts(); // Reload products after deletion
            }
            else
            {
                MessageBox.Show("Please select a product to delete.");
            }
        }
    }
}
