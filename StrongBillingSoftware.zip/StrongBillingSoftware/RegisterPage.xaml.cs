﻿using System;
using System.Windows;
using Npgsql;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Controls;

namespace StrongBillingSoftware
{
    public partial class RegisterPage : Window
    {
        private DatabaseHelper db = new DatabaseHelper();

        public RegisterPage()
        {
            InitializeComponent();
        }

        // Method to hash the password
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void OnRegisterClick(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;
            string hashedPassword = HashPassword(password);
            string role = (RoleComboBox.SelectedItem as ComboBoxItem).Content.ToString();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            string query = "INSERT INTO users (username, password, role) VALUES (@username, @password, @role)";
            var parameters = new NpgsqlParameter[]
            {
                new NpgsqlParameter("@username", username),
                new NpgsqlParameter("@password", hashedPassword),
                new NpgsqlParameter("@role", role)
            };

            try
            {
                db.ExecuteNonQuery(query, parameters);
                MessageBox.Show("User registered successfully!");
                this.Close(); // Close the registration window
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
