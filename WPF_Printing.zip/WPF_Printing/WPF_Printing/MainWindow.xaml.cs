﻿using System.Drawing.Printing;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Drawing.Printing;


namespace WPF_Printing
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }



private void LoadPrinters()
    {
        foreach (string printer in PrinterSettings.InstalledPrinters)
        {
            printerComboBox.Items.Add(printer);
        }
    }


    private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            string selectedPrinter = ((ComboBoxItem)printerComboBox.SelectedItem).Content.ToString();
            string textToPrint = printTextBox.Text;

            if (selectedPrinter == "Laser/Inkjet Printer")
            {
                PrintHelper.PrintToStandardPrinter(textToPrint);
            }
            else if (selectedPrinter == "Thermal Printer")
            {
                PrintHelper.PrintToThermalPrinter(textToPrint);
            }
        }

    }
}