﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.IO.Ports;
using ZXing.Common;
using ZXing;
using System.Drawing;
using PdfSharp.Drawing;
using PdfSharp.Pdf;


namespace WPF_Printing
{


    public static class PrintHelper
    {
        public static void PrintToStandardPrinter(string text)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                GeneratePDF("Invoice Content", "invoice.pdf");

                FlowDocument doc = new FlowDocument(new Paragraph(new Run(text)))
                {
                    FontSize = 14,
                    //FontFamily = new System.Drawing.FontFamily("Arial")
                };
                printDialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Print Job");
            }
        }






        public static void PrintToThermalPrinter(string text)
        {
            SerialPort serialPort = new SerialPort("COM3", 9600, Parity.None, 8, StopBits.One);
            try
            {
                serialPort.Open();
                serialPort.Write("\x1B\x40"); // ESC @ (Initialize printer)
                serialPort.Write(text + "\n");
                serialPort.Write("\x1D\x56\x00"); // Cut paper command
            }
            finally
            {
                serialPort.Close();
            }
        }




        //public static Bitmap GenerateBarcode(string text)
        //{
        //    BarcodeWriter writer = new BarcodeWriter
        //    {
        //        Format = BarcodeFormat.CODE_128, // Change to QR_CODE for QR
        //        Options = new EncodingOptions { Width = 300, Height = 100 },
        //        Renderer = new BitmapRenderer()
        //    };
        //    return writer.Write(text);
        //}



        //public static void PrintToStandardPrinter(string text)
        //{
        //    PrintDialog printDialog = new PrintDialog();
        //    if (printDialog.ShowDialog() == true)
        //    {
        //        FlowDocument doc = new FlowDocument();
        //        doc.Blocks.Add(new Paragraph(new Run(text)));

        //        // Generate Barcode Image
        //        Image barcodeImage = new Image();
        //        barcodeImage.Source = ConvertBitmapToImageSource(GenerateBarcode(text));

        //        BlockUIContainer container = new BlockUIContainer(barcodeImage);
        //        doc.Blocks.Add(container);

        //        printDialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Print Job");
        //    }
        //}



public static void GeneratePDF(string text, string filePath)
    {
        PdfDocument pdf = new PdfDocument();
        pdf.Info.Title = "Invoice";

        PdfPage page = pdf.AddPage();
        XGraphics gfx = XGraphics.FromPdfPage(page);
        XFont font = new XFont("Arial", 12);

        gfx.DrawString(text, font, XBrushes.Black, new XPoint(40, 50));

        pdf.Save(filePath);
    }

}


}
