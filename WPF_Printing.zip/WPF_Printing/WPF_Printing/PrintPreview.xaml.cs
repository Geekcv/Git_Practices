﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Printing
{
    /// <summary>
    /// Interaction logic for PrintPreview.xaml
    /// </summary>
    public partial class PrintPreview : Window
    {
        public PrintPreview()
        {
            InitializeComponent();
        }


        public static void ShowPrintPreview(string text)
        {
            PrintPreview previewWindow = new PrintPreview();

            FlowDocument doc = new FlowDocument(new Paragraph(new Run(text)));
            previewWindow.docViewer.Document = doc;

            previewWindow.ShowDialog();
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
