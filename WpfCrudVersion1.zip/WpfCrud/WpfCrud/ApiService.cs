﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace WpfCrud
{
    public class ApiService
    {
        private static readonly HttpClient client = new HttpClient { BaseAddress = new Uri("http://localhost:3000/") };
        private static string authToken = TokenHelper.GetToken(); // Load token from file

        // Constructor to set token if it exists
        static ApiService()
        {
            if (!string.IsNullOrEmpty(authToken))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
            }
        }

        // Set and store the token
        public static void SetAuthToken(string token)
        {
            authToken = token;
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            TokenHelper.SaveToken(token); // Save token to file
        }

        // Login and retrieve token
        public static async Task<bool> LoginAsync(string email, string password)
        {
            var user = new { email, password };
            var content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("login", content);

            if (response.IsSuccessStatusCode)
            {
                var result = JsonConvert.DeserializeObject<dynamic>(await response.Content.ReadAsStringAsync());
                string token = result.token;

                SetAuthToken(token); // Save token
                return true;
            }
            return false;
        }

        // Logout (Clear Token)
        public static void Logout()
        {
            TokenHelper.ClearToken(); // Remove token from file
            client.DefaultRequestHeaders.Authorization = null; // Remove from headers
        }

        // Get Clients (Requires Authentication)
        public static async Task<List<Client>> GetClientsAsync()
        {
            var response = await client.GetStringAsync("clients");
            return JsonConvert.DeserializeObject<List<Client>>(response);
        }

        // Add Client
        public static async Task<bool> AddClientAsync(Client clientData)
        {
            var content = new StringContent(JsonConvert.SerializeObject(clientData), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("clients", content);
            return response.IsSuccessStatusCode;
        }

        // Delete Client
        public static async Task<bool> DeleteClientAsync(int id)
        {
            var response = await client.DeleteAsync($"clients/{id}");
            return response.IsSuccessStatusCode;
        }
    }
}
