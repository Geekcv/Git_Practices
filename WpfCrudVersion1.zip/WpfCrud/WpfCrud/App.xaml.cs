﻿using System;
using System.Windows;

namespace WpfCrud
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            string token = TokenHelper.GetToken();

            if (!string.IsNullOrEmpty(token))
            {
                // Redirect to the client dashboard
                ClientsWindow clientsWindow = new ClientsWindow();
                clientsWindow.Show();
            }
            else
            {
                // Redirect to the login page
                MainWindow loginWindow = new MainWindow();
                loginWindow.Show();
            }
        }
    }
}
