﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;

namespace WpfCrud
{
    public partial class ClientsWindow : Window
    {
        private static readonly HttpClient client = new HttpClient { BaseAddress = new Uri("http://localhost:3000/") };

        public ClientsWindow()
        {
            InitializeComponent();
            LoadClients();
        }

        private async void LoadClients()
        {
            var clients = await ApiService.GetClientsAsync();
            ClientsGrid.ItemsSource = clients;
        }

        private async void AddClient_Click(object sender, RoutedEventArgs e)
        {
            var client = new Client
            {
                Name = txtClientName.Text,
                Email = txtClientEmail.Text,
                Phone = txtClientPhone.Text
            };

            bool success = await ApiService.AddClientAsync(client);
            if (success)
            {
                MessageBox.Show("Client added successfully!");
                LoadClients();
            }
            else
            {
                MessageBox.Show("Error adding client.");
            }
        }

        private async void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            if (ClientsGrid.SelectedItem is Client selectedClient)
            {
                bool success = await ApiService.DeleteClientAsync(selectedClient.Id);
                if (success)
                {
                    MessageBox.Show("Client deleted successfully!");
                    LoadClients();
                }
                else
                {
                    MessageBox.Show("Error deleting client.");
                }
            }
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            ApiService.Logout();
            MessageBox.Show("Logged out successfully!");

            // Redirect to Login Window
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }

    }
}
