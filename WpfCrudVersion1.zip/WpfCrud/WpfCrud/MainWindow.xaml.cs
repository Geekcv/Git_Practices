﻿using System;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;

namespace WpfCrud
{
    public partial class MainWindow : Window
    {
        private static readonly HttpClient client = new HttpClient { BaseAddress = new Uri("http://localhost:3000/") };

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Password;

            var token = await LoginAsync(email, password);
            if (!string.IsNullOrEmpty(token))
            {
                ApiService.SetAuthToken(token); // Store token in ApiService
                ClientsWindow clientsWindow = new ClientsWindow();
                clientsWindow.Show();
                this.Close();
            }
            else
            {
                lblMessage.Text = "Invalid email or password!";
            }
        }

        private static async Task<string> LoginAsync(string email, string password)
        {
            var user = new { email, password };
            var content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("login", content);

            if (response.IsSuccessStatusCode)
            {
                var result = JsonConvert.DeserializeObject<dynamic>(await response.Content.ReadAsStringAsync());
                return result.token;
            }
            return null;
        }

        private void OpenRegisterWindow_Click(object sender, RoutedEventArgs e)
        {
            RegisterWindow registerWindow = new RegisterWindow();
            registerWindow.Show();
            this.Close();
        }

    }
}
