﻿using System;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;

namespace WpfCrud
{
    public partial class RegisterWindow : Window
    {
        private static readonly HttpClient client = new HttpClient { BaseAddress = new Uri("http://localhost:3000/") };

        public RegisterWindow()
        {
            InitializeComponent();
        }

        private async void Register_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string email = txtEmail.Text;
            string password = txtPassword.Password;

            bool success = await RegisterUserAsync(name, email, password);
            if (success)
            {
                MessageBox.Show("Registration successful! Please log in.");
                MainWindow loginWindow = new MainWindow();
                loginWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Registration failed. Email might already be taken.");
            }
        }

        private void BackToLogin_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }

        private static async Task<bool> RegisterUserAsync(string name, string email, string password)
        {
            var user = new { name, email, password };
            var content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("register", content);
            return response.IsSuccessStatusCode;
        }
    }
}
