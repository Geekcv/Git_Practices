﻿using System;
using System.IO;

namespace WpfCrud
{
    public static class TokenHelper
    {
        private static readonly string TokenFilePath = "user_token.txt";

        // Save token to file
        public static void SaveToken(string token)
        {
            try
            {
                File.WriteAllText(TokenFilePath, token);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error saving token: " + ex.Message);
            }
        }

        // Retrieve token from file
        public static string GetToken()
        {
            return File.Exists(TokenFilePath) ? File.ReadAllText(TokenFilePath) : null;
        }

        // Delete token file (Logout)
        public static void ClearToken()
        {
            if (File.Exists(TokenFilePath))
            {
                File.Delete(TokenFilePath);
            }
        }
    }
}
