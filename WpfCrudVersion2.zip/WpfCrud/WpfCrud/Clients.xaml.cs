﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfCrud.controller;
using WpfCrud.service;

namespace WpfCrud
{
    /// <summary>
    /// Interaction logic for Clients.xaml
    /// </summary>
    public partial class Clients : Window
    {
        private List<Client1> clients = new List<Client1>();

        public Clients()
        {
            InitializeComponent();

           
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            ApiService.Logout();
            MessageBox.Show("Logged out successfully!");

            // Redirect to Login Window
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }

        // ✅ Add Client to List
        private async void AddClient_Click(object sender, RoutedEventArgs e)
        {
            string name = txtClientName.Text.Trim();
            string description = txtDescription.Text.Trim();


            string userId = Apicontroller.GetUserId();


            var clientdata = new
            {
                name,
                description,
                userId
            };

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Please enter both Client Name and Description.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            bool isLoggedIn = await Apicontroller.AddClientAsync(clientdata);


            if (isLoggedIn)
            {
                MessageBox.Show("Client added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                // Clear fields
                txtClientName.Clear();
                txtDescription.Clear();
            }
            else
            {
                MessageBox.Show("Client NOT added !", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }









        }

         //✅ Show All Clients in a MessageBox
        private async void ShowClients_Click(object sender, RoutedEventArgs e)
        {
            clients = await Apicontroller.GetClientsAsync();
            ClientDataGrid.ItemsSource = clients;

            if (clients.Count == 0)
            {
                MessageBox.Show("No clients available.", "Client List", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string clientList = "Client List:\n";
            foreach (var client in clients)
            {
                clientList += $"- {client.Name}: {client.Description}\n";
            }

            MessageBox.Show(clientList, "Client List", MessageBoxButton.OK, MessageBoxImage.Information);
        }

    }
}

public class Client1
{
    public string Name { get; set; }
    public string Description { get; set; }
}

