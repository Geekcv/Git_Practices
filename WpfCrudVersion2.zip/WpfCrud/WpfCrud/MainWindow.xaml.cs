﻿using System.Windows;
using WpfCrud.controller;
using WpfCrud.service;

namespace WpfCrud
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Check if user is already logged in
            if (ApiService.IsUserLoggedIn())
            {
                RedirectToClientWindow();
            }
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Password;

            var logindata = new
            {
                email,
                password
            };

            bool isLoggedIn = await Apicontroller.LoginUserAsync(logindata);
            if (isLoggedIn)
            {
                RedirectToClientWindow();
            }
            else
            {
                lblMessage.Text = "Invalid email or password!";
            }
        }

        private void RedirectToClientWindow()
        {
            Clients clientsWindow = new Clients();
            clientsWindow.Show();
            this.Close();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            ApiService.Logout();
            MessageBox.Show("Logged out successfully!");
            new MainWindow().Show();
            this.Close();
        }
    }
}
