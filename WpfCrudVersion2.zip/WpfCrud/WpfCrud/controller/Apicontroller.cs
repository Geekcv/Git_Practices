﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WpfCrud.service;

namespace WpfCrud.controller
{
    public class Apicontroller
    {
        public static async Task<bool> LoginUserAsync(object logindata)
        {


            var loginData = new
            {
                fn = "common_fn",
                se = "lo_us",
                data = logindata
            };

            string response = await ApiService.PostUrlAsync(loginData, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("❌ Login failed: Empty response");
                return false;
            }

            // 🔹 Print raw response for debugging
            Console.WriteLine($"📥 Raw API Response: {response}");


            string urlDecoded = Uri.UnescapeDataString(response);


            try
            {
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"✅ Parsed JSON: {result}");

                if (result?.data?.token != null)
                {
                    ApiService.SaveToken(result.data.token.ToString());
                    return true;
                }
                else
                {
                    Console.WriteLine("❌ Login failed: No token received");
                    return false;
                }
            }
            catch (JsonReaderException jex)
            {
                Console.WriteLine("❌ JSON Parsing Error: " + jex.Message);
                Console.WriteLine("❌ API Response: " + response);
                return false;
            }
        }


        public   static async Task<bool> AddClientAsync(object clientdata)
        {
            var loginData = new
            {
                fn = "common_fn",
                se = "cr_cl",
                data = clientdata
            };

            string response = await ApiService.PostUrlAsync(loginData, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("❌ Login failed: Empty response");
                return false;
            }

            // 🔹 Print raw response for debugging
            Console.WriteLine($"📥 Raw API Response: {response}");

            string urlDecoded = Uri.UnescapeDataString(response);

            try
            {
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"✅ Parsed JSON: {result}");

                if (result != null && result.status == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (JsonReaderException jex)
            {
                Console.WriteLine("❌ JSON Parsing Error: " + jex.Message);
                Console.WriteLine("❌ API Response: " + response);
                return false;
            }


        }





        public static async Task<List<Client1>> GetClientsAsync()
        {
            string response = await ApiService.PostUrlAsync(new { fn = "common_fn", se = "fe_cl" }, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("❌ Failed to fetch clients: Empty response");
                return new List<Client1>();
            }

            try
            {
                // ✅ Fix potential JSON formatting issues
                string jsonResponse = response.Trim();
                if (jsonResponse.StartsWith("[") && jsonResponse.EndsWith("]"))
                {
                    jsonResponse = jsonResponse.Trim('[', ']'); // Remove outer brackets if it's an array
                }

                string urlDecoded = Uri.UnescapeDataString(jsonResponse);

                // ✅ Deserialize JSON
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"✅ Parsed Clients JSON: {result}");

                // ✅ Extract client list
                var clientsList = new List<Client1>();
                foreach (var item in result.data)
                {
                    clientsList.Add(new Client1
                    {
                        //RowId = item.row_id,
                        Name = item.name,
                        Description = item.description
                    });
                }
                return clientsList;
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error parsing clients: " + ex.Message);
                return new List<Client1>();
            }
        }

































        // user id get 

        private const string TokenFilePath = "auth_token.txt"; // Store token in a file

        // ✅ Load Token from File (like localStorage in JS)
        private static string LoadToken()
        {
            return File.Exists(TokenFilePath) ? File.ReadAllText(TokenFilePath) : null;
        }

        // ✅ Get User ID from JWT Token
        public static string GetUserId()
        {
            string token = LoadToken();
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                // Split JWT and get the payload (2nd part)
                string[] parts = token.Split('.');
                if (parts.Length < 2)
                    throw new Exception("Invalid JWT format");

                // Convert Base64 URL to standard Base64
                string base64Payload = parts[1].Replace('-', '+').Replace('_', '/');
                while (base64Payload.Length % 4 != 0) // Add padding if needed
                {
                    base64Payload += "=";
                }

                // Decode Base64 payload
                string payloadJson = Encoding.UTF8.GetString(Convert.FromBase64String(base64Payload));

                // Parse JSON and extract userId
                using (JsonDocument doc = JsonDocument.Parse(payloadJson))
                {
                    if (doc.RootElement.TryGetProperty("userId", out JsonElement userIdElement))
                    {
                        return userIdElement.GetString();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error decoding token: " + ex.Message);
            }

            return null; // Return null if decoding fails
        }



    }
}
