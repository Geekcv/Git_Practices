﻿//using System.Configuration;
//using System.Data;
//using System.Windows;

//namespace YourWpfApp
//{
//    /// <summary>
//    /// Interaction logic for App.xaml
//    /// </summary>
//    public partial class App : Application
//    {
//    }

//}




using System;
using System.IO;
using System.Linq;
using System.Windows;
using Portable.Licensing;
using Portable.Licensing.Validation;

namespace YourWpfApp
{
    public partial class App : Application
    {
        private static readonly string PublicKeyPath = "publicKey.txt";
        private static readonly string LicensePath = "License.lic";

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            if (ValidateLicense())
            {
                // ✅ License is valid → Show Main Window
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
            }
            else
            {
                // ❌ Invalid License → Show License Activation Window
                LicenseActivationWindow licenseWindow = new LicenseActivationWindow();
                licenseWindow.Show();
            }
        }

        private bool ValidateLicense()
        {
            try
            {
                if (!File.Exists(PublicKeyPath) || !File.Exists(LicensePath))
                {
                    MessageBox.Show("❌ License or public key file is missing!", "License Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                string publicKey = File.ReadAllText(PublicKeyPath);
                var license = License.Load(File.ReadAllText(LicensePath));

                var validationFailures = license.Validate()
                    .ExpirationDate()
                        .When(lic => lic.Type == LicenseType.Trial)
                    .And()
                    .Signature(publicKey)
                    .AssertValidLicense();

                if (validationFailures.Any())
                {
                    MessageBox.Show("❌ License validation failed!", "License Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                return true; // ✅ License is valid
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ License validation error:\n{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }
    }
}
