﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.OpenSsl;
using Portable.Licensing;
using Portable.Licensing.Security.Cryptography;
using System.Text;

namespace YourWpfApp
{
    public partial class GenLincences : Window
    {
       
        public GenLincences()
        {
            InitializeComponent();

              //  GenerateKeys();

            // Create a license
            CreateLicense("Abhishek", "abhi@gmail.com");
        }

        /// <summary>
        /// Generates and saves RSA key pair (private and public keys) WITHOUT encryption.
        /// </summary>
        private static readonly string PrivateKeyPath = "privateKey.txt";
        private static readonly string PublicKeyPath = "publicKey.txt";

        public static void GenerateKeys()
        {
            var keyGenerator = KeyGenerator.Create();
            var keyPair = keyGenerator.GenerateKeyPair();

            string privateKey = keyPair.ToEncryptedPrivateKeyString("YourPassPhrase");
            string publicKey = keyPair.ToPublicKeyString();

            File.WriteAllText(PrivateKeyPath, privateKey);
            File.WriteAllText(PublicKeyPath, publicKey);

            Console.WriteLine("✅ Keys generated successfully!");
        }


        private static readonly string LicensePath = "License.lic";

        public static void CreateLicense(string customerName, string email)
        {
            if (!File.Exists(PrivateKeyPath))
            {
                Console.WriteLine("❌ Private key not found! Run GenerateKeys() first.");
                return;
            }

            string privateKey = File.ReadAllText(PrivateKeyPath);

            var license = License.New()
                .WithUniqueIdentifier(Guid.NewGuid())
                .As(LicenseType.Standard)
                .ExpiresAt(DateTime.UtcNow.AddYears(1)) // License valid for 1 year
                .WithProductFeatures(new Dictionary<string, string>
                {
                { "Feature1", "Enabled" },
                { "Feature2", "Enabled" },
                { "MaxUsers", "10" }
                })
                .LicensedTo(customerName, email)
                .CreateAndSignWithPrivateKey(privateKey, "YourPassPhrase");

            File.WriteAllText(LicensePath, license.ToString(), Encoding.UTF8);

            Console.WriteLine("✅ License created successfully!");
        }


    }
}
