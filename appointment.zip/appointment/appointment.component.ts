import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { MatButtonModule } from '@angular/material/button';

interface Patient { 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
}

@Component({
  selector: 'app-appointment',
  standalone: true, // Ensures compatibility with Angular 19+ standalone components
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    FormsModule,
    MatSelectModule,
    MatButtonModule
  ],
  templateUrl: './appointment.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [provideNativeDateAdapter()],
})
export class AppointmentComponent {
  meetingDate: Date;
  meetingTime: string;
  patients: Patient[] = [];
  selectedvalue: string;
  app_type: string;

  availableTimes: string[] = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', 
    '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM',
    '01:00 PM', '01:30 PM', '02:00 PM', '02:30 PM',
    '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM',
    '05:00 PM', '05:30 PM', '06:00 PM', '06:30 PM'
  ];


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService
  ) {
    this.fetchPatients();
  }

  async fetchPatients() {
    try {
      const resp = await this.apiController.fetchPatients();
      console.log("Patients data:", resp);
      this.patients = resp.data as Patient[];
    } catch (error) {
      console.error("Error fetching patients:", error);
    }
  }

  async appointment() {
    const data = {
      "pat_row_id": this.selectedvalue,
      "time_of_apt": this.meetingTime,
      "date_of_apt": this.meetingDate.toISOString().split('T')[0], // Format date properly
      "appt_type": this.app_type,
    };

    console.log("Adding appointment...", data);
    try {
      const resp = await this.apiController.appointment(data);
      console.log("Appointment response:", resp);
    } catch (error) {
      console.error("Error booking appointment:", error);
    }
  }
}
