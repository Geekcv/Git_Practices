import { Routes } from '@angular/router';
import { AddpatientsComponent } from 'app/modules/admin/adminSide/addpatients/addpatients.component'

export default [
    {
        path: '',
        component: AddpatientsComponent,
    },
] as Routes;
