import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms'; // Import FormsModule
import { CommonModule } from '@angular/common'; // Import CommonModule
import { NoopAnimationsModule } from '@angular/platform-browser/animations'; // Import if needed for Material

import { RadioButtonComponent } from './radio-button.component';
import { MatIconModule } from '@angular/material/icon'; // Import MatIconModule

describe('RadioButtonComponent', () => {
  let component: RadioButtonComponent;
  let fixture: ComponentFixture<RadioButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RadioButtonComponent, // If standalone
        // CommonModule,      // If not standalone
        // FormsModule,       // If not standalone
        // MatIconModule,     // If not standalone
        NoopAnimationsModule
       ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RadioButtonComponent);
    component = fixture.componentInstance;

    // --- Provide mock data for inputs ---
    component.formItems = [
      { type: 'radio', label: 'Test Radio', options: [{label: 'Opt 1', value: '1'}], layout: 'vertical' }
    ];
    component.selectedElementIndex = 0;
    // --- End mock data ---

    fixture.detectChanges(); // Initial change detection
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load initial properties on init', () => {
     component.ngOnInit(); // Explicitly call ngOnInit if needed for testing setup
     expect(component.layout).toBe('vertical');
     expect(component.formItems[0].options?.length).toBe(1);
   });

   it('should add an option', () => {
     const initialOptionCount = component.formItems[component.selectedElementIndex!].options?.length || 0;
     component.addOption();
     const finalOptionCount = component.formItems[component.selectedElementIndex!].options?.length || 0;
     expect(finalOptionCount).toBe(initialOptionCount + 1);
   });

   it('should remove an option', () => {
     component.addOption(); // Ensure there are at least two options
     const initialOptionCount = component.formItems[component.selectedElementIndex!].options?.length || 0;
     component.removeOption(0); // Remove the first option
     const finalOptionCount = component.formItems[component.selectedElementIndex!].options?.length || 0;
     expect(finalOptionCount).toBe(initialOptionCount - 1);
   });

   it('should update layout style', () => {
      component.layout = 'horizontal';
      component.updateStyles();
      expect(component.formItems[component.selectedElementIndex!].layout).toBe('horizontal');
    });

});