import { Component, inject, ViewChild } from '@angular/core';
import { NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
  selector: 'app-adddoctordialog',
  imports: [
    MatDialogModule, MatButtonModule, ReactiveFormsModule, MatFormFieldModule,
    MatInputModule, MatButtonModule, MatIconModule, MatCheckboxModule,
    MatProgressSpinnerModule, MatSelectModule
  ],
  templateUrl: './adddoctordialog.component.html',
  styleUrl: './adddoctordialog.component.scss'
})
export class AdddoctordialogComponent {

  @ViewChild('signUpNgForm') signUpNgForm: NgForm;
  
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };

  signUpForm: UntypedFormGroup;
  showAlert: boolean = false;
  role: any = '';

  genders: string[] = ['Male', 'Female', 'Other']; // List of genders
  doctorType: string[] = ['Dermatologist', 'Neurologist', 'Cardiologist', 'Psychiatrist', 'Gastroenterologist', 'Family medicine'];

  private _snackBar = inject(MatSnackBar);

  constructor(
    private _formBuilder: UntypedFormBuilder,
    private _router: Router,
    private Apicontroller: ApicontrollerService,
    private dialogRef: MatDialogRef<AdddoctordialogComponent> // Inject MatDialogRef
  ) {
    this.role = localStorage.getItem('role');
  }

  ngOnInit(): void {
    this.signUpForm = this._formBuilder.group({
      doctor_name: ['', Validators.required],
      doctor_email: ['', [Validators.required, Validators.email]],
      doctor_phone: ['', Validators.required],
      doctor_password: ['', Validators.required],
      doctor_type: ['', Validators.required],
      doctor_gender: ['', Validators.required],
    });
  }

  async addresearchers() {
    const resp = await this.Apicontroller.createdoctor(this.signUpForm.value);

    if (resp.status === 0) {
      this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
      
      // Close the dialog after successful doctor creation
      this.dialogRef.close();

      // Redirect to View Researchers
      this._router.navigate(['/Viewresearchers']);
    } else {
      console.log("Error: ", resp.msg);
    }
  }
}
