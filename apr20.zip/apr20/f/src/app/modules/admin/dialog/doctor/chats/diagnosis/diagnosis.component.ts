import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-diagnosis',
  imports: [ MatDialogModule,MatButtonModule],
  templateUrl: './diagnosis.component.html',
  styleUrl: './diagnosis.component.scss'
})
export class DiagnosisComponent {
 constructor(
      @Inject(MAT_DIALOG_DATA) public data: {patient: string},
          private dialogRef: MatDialogRef<DiagnosisComponent> // Inject MatDialogRef
      
  ){

  }

  exitbtn(){

    this.dialogRef.close();

  }
}
