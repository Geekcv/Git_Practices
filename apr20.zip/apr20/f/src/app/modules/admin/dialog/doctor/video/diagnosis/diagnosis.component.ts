import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../../config';

@Component({
  selector: 'app-diagnosis',
  imports: [ MatDialogModule,MatButtonModule],
  templateUrl: './diagnosis.component.html',
  styleUrl: './diagnosis.component.scss'
})
export class DiagnosisComponent {

      config: string = config.apiBaseURL;
  
 constructor(
      @Inject(MAT_DIALOG_DATA) public data: {media_link: string},
          private dialogRef: MatDialogRef<DiagnosisComponent> // Inject MatDialogRef
      
  ){

  }

  exitbtn(){

    this.dialogRef.close();

  }
}
