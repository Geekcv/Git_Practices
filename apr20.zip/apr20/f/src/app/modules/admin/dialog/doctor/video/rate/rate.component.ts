import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../../config';

@Component({
  selector: 'app-rate',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './rate.component.html',
  styleUrl: './rate.component.scss'
})
export class RateComponent {

      config: string = config.apiBaseURL;
  
  constructor(
        @Inject(MAT_DIALOG_DATA) public data: {media_link: string},
            private dialogRef: MatDialogRef<RateComponent> // Inject MatDialogRef
        
    ){
  
    }
  
    exitbtn(){
  
      this.dialogRef.close();
  
    }

}
