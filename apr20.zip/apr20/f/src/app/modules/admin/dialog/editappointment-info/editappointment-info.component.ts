import { Component, inject, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
  selector: 'app-editappointment-info',
  imports: [MatDialogModule,
    MatButtonModule, MatFormFieldModule, FormsModule,
        ReactiveFormsModule, MatInputModule, MatSelectModule,
        MatIconModule
  ],
  templateUrl: './editappointment-info.component.html',
  styleUrl: './editappointment-info.component.scss',
})
export class EditappointmentInfoComponent {
patientsId: string = '';
  appo_row_id:string ='';

  selectedvalue: string;
  app_status: string = '';

  // slot: string = '';
  // availableslot: string[] = ['pending', 'accept', 'reject'];

  // availablestatus: number[] = [0, 1, 2];

  availablestatus: any[] = [
    {id: 0,value :'Pending'},
    {id:1,value:'Accept'},
    {id:2,value:'Reject'},
    {id:3,value:'Complete'},
    {id:4,value:'Cancel'},
    {id:5,value:'Reschedule'}



  ];

   private _snackBar = inject(MatSnackBar);

  role: any = '';
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    @Inject(MAT_DIALOG_DATA) public data: {appointment: string},
    private dialogRef: MatDialogRef<EditappointmentInfoComponent> // Inject MatDialogRef
  ) {
    this.patientsId = this.route.snapshot.paramMap.get('id');
    this.appo_row_id = this.route.snapshot.paramMap.get('appid');
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number

  }


  goback() {
    // console.log("click this button")
    this.router.navigate(['/patientpanel', this.patientsId])
  }

  goback1(){
    // console.log("click this button")
    this.router.navigate(['/myappointment'])
  }


  async editappointment(){


    const data = {
      row_id: this.data.appointment,
      appointment_request_status: this.app_status,
      
    };

    console.log("data",data)

    const resp = await this.apiController.updateAppointment(data);

    console.log("resp",resp)

    
    
    if (resp.status === 0) {
      this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
      
      // Close the dialog after successful doctor creation
      this.dialogRef.close();
    }


  }


  

}
