import { Routes } from '@angular/router';
import { ViewVideodetailsComponent } from 'app/modules/admin/doctorSide/view-videodetails/view-videodetails.component';

export default [
    {
        path: '',
        component: ViewVideodetailsComponent,
    },
] as Routes;
