import { CommonModule, NgClass, NgFor, NgIf, NgStyle, NgSwitch, NgSwitchCase } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface FormElement {
  address: any;
  key: any;
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?: string;
  margin?: string;
  width?: string;
  height?: string;
  bordercolor?: string;
  radius?: string;
  opacity?: string;
  rows?: any;
  cols?: any
  checked?: any
  min?: any
  max?: any
  options?: { label: string; value: string; }[]; // Array for radio options
  searchText?:any;
  filteredOptions?:any;
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  emailTouched?:any;


}

@Component({
  selector: 'app-form-preview',
  imports: [NgFor, NgSwitchCase, NgSwitch, NgStyle,NgClass,CommonModule,FormsModule,
 MatFormFieldModule,MatSelectModule,MatInputModule,MatCheckboxModule,NgIf,NgClass
  ],

  templateUrl: './form-preview.component.html',
  styleUrl: './form-preview.component.scss'
})
export class FormPreviewComponent {

  @Input() formItems: FormElement[];
  @Input() forms_row_id:string;
  @Input() currentUrlPath:string;

  formData: any = {};


  searchText:any;


  constructor(
        private Apicontroller: ApicontrollerService
    
  ){

  }

  // Search logic for multi select dropdown 
filterNativeCheckboxOptions(item: any) {
  const search = item.searchText?.toLowerCase() || '';
  item.filteredOptions = item.options.filter((opt: any) =>
    opt.label.toLowerCase().includes(search)
  );
}

// Handle checkbox change for multi select dropdown 
onCheckboxChange(item: any, value: string, event: any) {
  if (!this.formData[item.label]) {
    this.formData[item.label] = [];
  }

  if (event.target.checked) {
    this.formData[item.label].push(value);
  } else {
    this.formData[item.label] = this.formData[item.label].filter(
      (v: string) => v !== value
    );
  }
}

  // Search logic for single select dropdown 

  filterNativeDropdown(item: any) {
    console.log("serching inside dropdown ",item)
    const search = item.searchText?.toLowerCase() || '';
    console.log("search",search)
    item.filteredOptions = item.options.filter((opt: any) =>
      opt.label.toLowerCase().includes(search)
    );
  }


  // checkboxGrop 

onCheckboxGroupChange(event: any, key: string) {
    if (!this.formData[key]) {
        this.formData[key] = [];
    }

    const value = event.target.value;
    if (event.target.checked) {
        this.formData[key].push(value);
    } else {
        this.formData[key] = this.formData[key].filter((v: any) => v !== value);
    }
}


// file uplaod 

onFileChange(event: any, key: string) {
    const file = event.target.files[0];
    this.formData[key] = file;
}



// submit 
async submitForm() {
    console.log('Submitted Form:', this.formData);
    console.log("current form row_id ",this.forms_row_id)
    var formsubdata;
    var tablename;

    var data =[
      formsubdata = this.formData,
      tablename = this.forms_row_id
    ]

    console.log("data",data)

    const resp = await this.Apicontroller.SaveForms(data);
    console.log("resp:-",resp)



      // Clear all form inputs
  this.formItems.forEach(item => {
    if (item.type === 'checkbox-group' || item.type === 'multiSelect-dropdown') {
      this.formData[item.key] = [];
    } else if (item.type === 'address' && item.address) {
      item.address.forEach(addr => {
        this.formData[addr.key] = '';
      });
    } else {
      this.formData[item.key] = '';
    }
  });

}


// async submitForm() {
//   let isValid = true;

//   // Validate all required fields
//   this.formItems.forEach(item => {
//       if (this.isRequired(item)) {
//           const value = this.formData[item.key];

//           if (item.type === 'checkbox-group' || item.type === 'multiSelect-dropdown') {
//               if (!value || value.length === 0) {
//                   isValid = false;
//               }
//           } else if (item.type === 'address' && item.address) {
//               item.address.forEach(addr => {
//                   if (!this.formData[addr.key]) {
//                       isValid = false;
//                   }
//               });
//           } else if (item.type === 'email') {
//               if (!value || !this.isValidEmail(value)) {
//                   isValid = false;
//               }
//           } else {
//               if (!value) {
//                   isValid = false;
//               }
//           }

//           // Mark as touched for showing errors
//           this.markTouched(item.key);
//       }
//   });

//   if (!isValid) {
//       console.warn("Form is invalid. Required fields are missing.");
//       return; // ❌ Stop form submission
//   }

//   console.log('✅ Submitted Form:', this.formData);
//   console.log("📋 Current form row_id:", this.forms_row_id);

//   const data = {
//       formsubdata: this.formData,
//       tablename: this.forms_row_id
//   };

//   const resp = await this.Apicontroller.SaveForms(data);
//   console.log("📤 API Response:", resp);

//   // ✅ Clear form after successful submission
//   this.formItems.forEach(item => {
//       if (item.type === 'checkbox-group' || item.type === 'multiSelect-dropdown') {
//           this.formData[item.key] = [];
//       } else if (item.type === 'address' && item.address) {
//           item.address.forEach(addr => {
//               this.formData[addr.key] = '';
//           });
//       } else {
//           this.formData[item.key] = '';
//       }
//   });
// }


isValidEmail(email: string): boolean {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}



// general style 
yourStyle(item: any) {
  return {
      'font-size': item.fontSize,
      color: item.fontColor,
      'font-family': item.fontFamily,
      'font-weight': item.fontWeight,
      'border-style': item.borderStyle,
      padding: item.padding,
      'background-color': item.bgColor,
      'border-width': item.borderWidth,
      margin: item.margin,
      height: item.height,
      width: item.width,
      'border-color': item.bordercolor,
      'border-radius': item.radius,
      required:item.required
  };
}




// blockSpace(event: KeyboardEvent) {
//   if (event.key === ' ') {
//     event.preventDefault(); // Block spacebar
//   }
// }



isInvalidEmail(item: any): boolean {
  const value = this.formData[item.key];
  console.log("email value",value)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // console.log("!this.formTouched[item.key]",!this.formTouched[item.key])

  if (!this.formTouched[item.key]) return false;

  // console.log("item.required && (!value || !emailRegex.test(value))",item.required && (!value || !emailRegex.test(value)))
  return item.required && (!value || !emailRegex.test(value));

}

// isRequired(item:any):boolean{
//   const value = this.formData[item.key];
//   if(item.required && !value){
//     return true
//   }
// }


touchedFields: { [key: string]: boolean } = {};

markTouched(key: string): void {
  this.touchedFields[key] = true;
}

isRequired(item: any): boolean {
  const value = this.formData[item.key];
  const touched = this.touchedFields[item.key];
  return item.required && touched && !value;
}


formTouched: { [key: string]: boolean } = {};

}