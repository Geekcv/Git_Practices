﻿using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EvenbooksUI.Pages;
using EvenbooksUI.Pages.Pricelist.Product;

namespace EvenbooksUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public enum UserRole
    {
        SuperAdmin,
        Admin,
        User
    }

    public static class UserSession
    {
        public static UserRole CurrentUserRole { get; set; }
    }


    public partial class MainWindow : Window
    {
        private Button _selectedMenuButton; // Store the currently selected Menu bar button
        private Button _selectedQuickMenuButton; // Store the currently selected Quick Menu button

        public static UserRole CurrentUserRole { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            CurrentUserRole = UserRole.User; // Example: Assume logged-in user is an Admin
            UserSession.CurrentUserRole = UserRole.User;


           // SetMenuVisibility();

        }



        private void SetMenuVisibility()
        {
            if (UserSession.CurrentUserRole == UserRole.SuperAdmin)
            {
                QuickmainMenuPanel.Visibility = Visibility.Visible;
                InvoicemainMenuPanel.Visibility = Visibility.Visible;
                PriceListmainMenuPanel.Visibility = Visibility.Visible;
                SaleOrdermainMenuPanel.Visibility = Visibility.Visible;
                InventorymainMenuPanel.Visibility = Visibility.Visible;
                CheckermainMenuPanel.Visibility = Visibility.Visible;
                LicensingmainMenuPanel.Visibility = Visibility.Visible;
                ReportsmianMenuPanel.Visibility = Visibility.Visible;
                BarcodeGeneratormainMenuPanel.Visibility = Visibility.Visible;
            }
            else if (UserSession.CurrentUserRole == UserRole.Admin)
            {
                QuickmainMenuPanel.Visibility = Visibility.Visible;
                InvoicemainMenuPanel.Visibility = Visibility.Visible;
                PriceListmainMenuPanel.Visibility = Visibility.Visible;
                SaleOrdermainMenuPanel.Visibility = Visibility.Visible;
                InventorymainMenuPanel.Visibility = Visibility.Collapsed;
                CheckermainMenuPanel.Visibility = Visibility.Collapsed;  // Admin cannot see this
                LicensingmainMenuPanel.Visibility = Visibility.Collapsed; // Admin cannot see this
                ReportsmianMenuPanel.Visibility = Visibility.Collapsed;
                BarcodeGeneratormainMenuPanel.Visibility = Visibility.Collapsed;
            }
            else // If User
            {
                QuickmainMenuPanel.Visibility = Visibility.Visible;
                InvoicemainMenuPanel.Visibility = Visibility.Collapsed;  // User cannot see this
                PriceListmainMenuPanel.Visibility = Visibility.Collapsed;
                SaleOrdermainMenuPanel.Visibility = Visibility.Collapsed;
                InventorymainMenuPanel.Visibility = Visibility.Collapsed;
                CheckermainMenuPanel.Visibility = Visibility.Collapsed;
                LicensingmainMenuPanel.Visibility = Visibility.Collapsed;
                ReportsmianMenuPanel.Visibility = Visibility.Collapsed;
                BarcodeGeneratormainMenuPanel.Visibility = Visibility.Visible;
            }
        }




        private void selectedMenuColorChange(object sender)
        {
            // when not select button
            if (_selectedMenuButton != null)
            {
                _selectedMenuButton.Background = Brushes.Transparent;
                _selectedMenuButton.Foreground = Brushes.White;
            }

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //clickedButton.Background = Brushes.Blue;
                clickedButton.Foreground = Brushes.Yellow;
                _selectedMenuButton = clickedButton;
            }
        }

        private void selectedQuickMenuColorChange(object sender)
        {
            // when not select button

            if (_selectedQuickMenuButton != null)
            {
                _selectedQuickMenuButton.Background = Brushes.Transparent;
                _selectedQuickMenuButton.Foreground = Brushes.Black;
            }

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //clickedButton.Background = Brushes.Yellow;
                clickedButton.Foreground = Brushes.Blue;
                _selectedQuickMenuButton = clickedButton;
            }
        }



        private void ToggleQuickMenu(object sender, RoutedEventArgs e)
        {
            // button configration when click 
           selectedMenuColorChange(sender);

            //QuickMenuPanel.Visibility = QuickMenuPanel.Visibility == Visibility.Visible
            //    ? Visibility.Collapsed
            //    : Visibility.Visible;


            QuickMenuPanel.Visibility = Visibility.Visible;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleInvoice(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //InvoiceMenuPanel.Visibility = InvoiceMenuPanel.Visibility == Visibility.Visible
            //   ? Visibility.Collapsed
            //   : Visibility.Visible;



            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Visible;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void TogglePriceList(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //PriceListMenuPanel.Visibility = PriceListMenuPanel.Visibility == Visibility.Visible
            // ? Visibility.Collapsed
            // : Visibility.Visible;


            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Visible;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleSaleOrder(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //SaleOrderMenuPanel.Visibility = SaleOrderMenuPanel.Visibility == Visibility.Visible
            //? Visibility.Collapsed
            //: Visibility.Visible;



            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Visible;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleInventory(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            // InventoryMenuPanel.Visibility = InventoryMenuPanel.Visibility == Visibility.Visible
            //? Visibility.Collapsed
            //: Visibility.Visible;


            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Visible;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleChecker(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //  CheckerMenuPanel.Visibility = CheckerMenuPanel.Visibility == Visibility.Visible
            //? Visibility.Collapsed
            //: Visibility.Visible;



            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Visible;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleLicensing(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //   LicensingMenuPanel.Visibility = LicensingMenuPanel.Visibility == Visibility.Visible
            //? Visibility.Collapsed
            //: Visibility.Visible;



            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Visible;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleReports(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //    ReportsMenuPanel.Visibility = ReportsMenuPanel.Visibility == Visibility.Visible
            //? Visibility.Collapsed
            //: Visibility.Visible;


            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Visible;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Collapsed;
        }

        private void ToggleBarcodeGenerator(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedMenuColorChange(sender);

            //    BarcodeGeneratorMenuPanel.Visibility = BarcodeGeneratorMenuPanel.Visibility == Visibility.Visible
            //? Visibility.Collapsed
            //: Visibility.Visible;


            QuickMenuPanel.Visibility = Visibility.Collapsed;
            InvoiceMenuPanel.Visibility = Visibility.Collapsed;
            PriceListMenuPanel.Visibility = Visibility.Collapsed;
            SaleOrderMenuPanel.Visibility = Visibility.Collapsed;
            InventoryMenuPanel.Visibility = Visibility.Collapsed;
            CheckerMenuPanel.Visibility = Visibility.Collapsed;
            LicensingMenuPanel.Visibility = Visibility.Collapsed;
            ReportsMenuPanel.Visibility = Visibility.Collapsed;
            BarcodeGeneratorMenuPanel.Visibility = Visibility.Visible;
        }

        private void POSBilling_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new POSBilling(); 
        }

        private void PreviousBill_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);


            ContentFrame.Content = new PreviousBill();
        }

        private void PaymentHistory_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new PaymentHistory();
        }

        private void ItemSummery_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new ItemSummery();
        }

        private void Order_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new Order();
        }

        private void InvoiceBilling_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new InvoiceBilling();
        }

        private void PriceList_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new addProduct();
        }

        private void SaleOrder_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content= new SaleOrder();
        }

        private void Inventory_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new InventoryReport();
        }

        private void Checker_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new Checker();
        }

        private void Licensing_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new Licensing();
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content  = new Reports();
        }

        private void BarcodeGenerator_Click(object sender, RoutedEventArgs e)
        {
            // button configration when click 
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new BarcodeGenerator();
        }

        private void checkout_Click(object sender, RoutedEventArgs e)
        {
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new Purchasing();
        }

        private void monitoring_Click(object sender, RoutedEventArgs e)
        {
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new StockManagement();
        }

        private void procurement_Click(object sender, RoutedEventArgs e)
        {
            selectedQuickMenuColorChange(sender);

            ContentFrame.Content = new Order_Management();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {

        }


        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control) // Check if Ctrl is pressed
            {
                switch (e.Key)
                {
                    case Key.Q: ToggleQuickMenu(null, null); break;       // Ctrl + Q -> Quick Menu
                    case Key.I: ToggleInvoice(null, null); break;        // Ctrl + I -> Invoice
                    case Key.P: TogglePriceList(null, null); break;      // Ctrl + P -> Price List
                    case Key.S: ToggleSaleOrder(null, null); break;      // Ctrl + S -> Sale Order
                    case Key.V: ToggleInventory(null, null); break;      // Ctrl + V -> Inventory
                    case Key.C: ToggleChecker(null, null); break;        // Ctrl + C -> Checker
                    case Key.L: ToggleLicensing(null, null); break;      // Ctrl + L -> Licensing
                    case Key.R: ToggleReports(null, null); break;        // Ctrl + R -> Reports
                    case Key.B: ToggleBarcodeGenerator(null, null); break; // Ctrl + B -> Barcode Generator
                }
            }
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            // Prevents repeating actions when keys are held down
            e.Handled = true;
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Prevents focus issues when pressing keys
            e.Handled = true;
        }



    }
}