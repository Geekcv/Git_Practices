﻿using EvenbooksUI.connect_db;
using EvenbooksUI.function;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EvenbooksUI.Pages.Pricelist.Product
{
    /// <summary>
    /// Interaction logic for EditProductPage.xaml
    /// </summary>
    public partial class EditProductPage : Window
    {
        private string productId;
        private string products = "eb" + ".products2";


        public EditProductPage(DataRow productRow)
        {
            InitializeComponent();

            productId = productRow["row_id"].ToString();
            ProductNameTextBox.Text = productRow["product_name"].ToString();
            productcodeBox.Text = productRow["product_code"].ToString();

            // Set status dropdown value
            bool isDraft = Convert.ToBoolean(productRow["is_draft"]);
            productStatusComboBox.SelectedIndex = isDraft ? 0 : 1; // Draft (0), Published (1)
        }


        private async void OnSaveChangesClick(object sender, RoutedEventArgs e)
        {
            bool isDraft = ((ComboBoxItem)productStatusComboBox.SelectedItem).Tag.ToString() == "true";

            var columns = new Dictionary<string, object>
    {
        { "product_name", ProductNameTextBox.Text },
        { "product_code", productcodeBox.Text },
        { "is_draft", isDraft }
    };

            var comm = new Dictionary<string, object>
    {
        { "row_id", productId }
    };

            // Update database
            var result = await queries.UpdateData(products, columns, comm);

            if (result != null)
            {
                MessageBox.Show($"Product updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show($"Product not updated", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
