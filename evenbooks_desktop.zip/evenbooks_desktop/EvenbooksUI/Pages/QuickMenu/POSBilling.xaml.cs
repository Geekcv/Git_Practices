﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace EvenbooksUI.Pages
{
    /// <summary>
    /// Interaction logic for POSBilling.xaml
    /// </summary>
    public partial class POSBilling : Page
    {
        private int serialNo = 1; // Initial Serial Number

        public POSBilling()
        {
            InitializeComponent();
            StartClock();
            SerialNoTextBlock.Text = serialNo.ToString(); // Set initial Serial No.


        }

        private void StartClock()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (sender, e) =>
            {
                TimeTextBlock.Text = DateTime.Now.ToString("hh:mm:ss tt");
                DateTextBlock.Text = DateTime.Now.ToString("dd/MM/yyyy");
            };
            timer.Start();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            serialNo++; // Increment Serial Number
            SerialNoTextBlock.Text = serialNo.ToString(); // Update UI

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            serialNo++; // Increment Serial Number
            SerialNoTextBlock.Text = serialNo.ToString(); // Update UI

        }
    }
}
