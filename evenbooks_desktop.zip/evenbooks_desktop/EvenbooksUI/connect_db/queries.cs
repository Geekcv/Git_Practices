﻿using System.Text;
using System.Text.Json;
using Npgsql;

namespace EvenbooksUI.connect_db
{
    public class queries
    {  
        private static readonly string ConnectionString = config.DatabaseConfig();


        // insert data 
        public static async Task<object> InsertData(string tablename, Dictionary<string, object> columns)
        {
            using (var connectDb = new NpgsqlConnection(ConnectionString))
            {
                await connectDb.OpenAsync();

                var colString = "(";
                var lastKey = GetLastKey(columns);
                // all keys making for colstring
                foreach (var k in columns.Keys)
                {
                    if (columns[k] != null)
                    {
                        if (k != lastKey)
                        {
                            colString += k + ",";
                        }
                        else
                        {
                            colString += k + ")";
                        }
                    }
                }

                var valString = "('";
                foreach (var k in columns.Keys)
                {
                    if (columns[k] != null)
                    {
                        if (k != lastKey)
                        {
                            if (columns[k] is Array)
                            {
                                valString += JsonSerializer.Serialize(columns[k]).Replace("'", "`") + "' ,'";
                            }
                            else
                            {
                                valString += columns[k].ToString().Replace("'", "`") + "' ,'";
                            }
                        }
                        else
                        {
                            if (columns[k] is Array)
                            {
                                valString += JsonSerializer.Serialize(columns[k]).Replace("'", "`") + "')";
                            }
                            else
                            {
                                valString += columns[k].ToString().Replace("'", "`") + "')";
                            }
                        }
                    }

                }

                var sqlString = "INSERT INTO " + tablename + colString + " VALUES" + valString + " ON CONFLICT(row_id) DO NOTHING RETURNING row_id;";
                Console.WriteLine(sqlString);

                try
                {
                    using (var cmd = new NpgsqlCommand(sqlString, connectDb))
                    {
                        var response = await cmd.ExecuteScalarAsync();

                        return response; // Return the row_id or null if insert failed

                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine($"Error running query: {ex.Message}");
                    throw;
                }
            }

        }
        private static string GetLastKey(Dictionary<string, object> columns)
        {
            var lastKey = string.Empty;
            foreach (var key in columns.Keys)
            {
                lastKey = key;
            }
            return lastKey;
        }




        // fetch data

        public static async Task<List<Dictionary<string, object>>> FetchData(string tableName, Dictionary<string, object> cond)
        {
            return await Task.Run(() =>
            {
                try
                {
                    var colString = " WHERE ";
                    Console.WriteLine("cond");
                    Console.WriteLine(cond);

                    var sqlString = "SELECT * FROM " + tableName;

                    if (cond == null)
                    {
                        sqlString += " ;";
                        Console.WriteLine(sqlString);
                    }
                    else
                    {
                        if (cond.Count > 1)
                        {
                            foreach (var k in cond.Keys)
                            {
                                if (k == "OR")
                                {
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' OR ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                        }
                                    }
                                }
                                if (k == "AND")
                                {
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' AND ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            foreach (var k in cond.Keys)
                            {
                                if (k == "OR")
                                {
                                    Console.WriteLine("k");
                                    Console.WriteLine(k);
                                    Console.WriteLine(cond[k]);
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' OR ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                            sqlString += colString + " ;";
                                        }
                                    }
                                }
                                else if (k == "AND")
                                {
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' AND ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                            sqlString += colString + " ;";
                                        }
                                    }
                                }
                                else if (k == "LIMIT")
                                {
                                    sqlString += " LIMIT " + cond[k] + " ;";
                                }
                                else if (k == "ORDER")
                                {
                                    var orderString = " ORDER BY ";
                                    foreach (var key in (Dictionary<string, string>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, string>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            orderString += key.Key + " " + key.Value.ToUpper() + " , ";
                                        }
                                        else
                                        {
                                            orderString += key.Key + " " + key.Value.ToUpper();
                                            sqlString += orderString + " ;";
                                        }
                                    }
                                }
                                else
                                {
                                    colString += " " + k + " = '" + cond[k] + "'";
                                    sqlString += colString + " ;";
                                }
                            }
                        }
                    }

                    using (var connection = new NpgsqlConnection(ConnectionString))
                    {
                        connection.Open();
                        using (var command = new NpgsqlCommand(sqlString, connection))
                        {
                            using (var reader = command.ExecuteReader())
                            {
                                var rows = new List<Dictionary<string, object>>();
                                while (reader.Read())
                                {
                                    var row = new Dictionary<string, object>();
                                    for (int i = 0; i < reader.FieldCount; i++)
                                    {
                                        row.Add(reader.GetName(i), reader.GetValue(i));
                                    }
                                    rows.Add(row);
                                }
                                return rows;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine("Error running query: " + ex.Message);
                    return new List<Dictionary<string, object>>();
                }
            });
        }

        private static string GetLastKey<T>(Dictionary<string, T> dict)
        {
            string lastKey = null;
            foreach (var key in dict.Keys)
            {
                lastKey = key;
            }
            return lastKey;
        }



        // update data 

        public static async Task<int> UpdateData(string tablename, Dictionary<string, object> columns, Dictionary<string, object> cond)
        {
            using (var connectDb = new NpgsqlConnection(ConnectionString))
            {
                await connectDb.OpenAsync();

                Console.WriteLine("columns");
                Console.WriteLine(JsonSerializer.Serialize(columns));
                Console.WriteLine("cond");
                Console.WriteLine(JsonSerializer.Serialize(cond));
                Console.WriteLine("tablename");
                Console.WriteLine(tablename);

                string colString = "";
                var lastKey = GetLastKey(columns);
                foreach (var k in columns.Keys)
                {
                    if (columns[k] != null)
                    {
                        if (k != lastKey)
                        {
                            Console.WriteLine("kast jet===");

                            if (columns[k] is Array)
                            {
                                colString += $"{k} = '{JsonSerializer.Serialize(columns[k]).Replace("'", "`")}',";
                            }
                            else
                            {
                                colString += $"{k} = '{columns[k].ToString().Replace("'", "`")}',";
                            }
                        }
                        else
                        {
                            Console.WriteLine("lst key");
                            if (columns[k] is Array)
                            {
                                colString += $"{k} = '{JsonSerializer.Serialize(columns[k]).Replace("'", "`")}',";
                            }
                            else
                            {
                                colString += $"{k} = '{columns[k].ToString().Replace("'", "`")}',";
                            }
                        }
                    }
                }

                if (colString.EndsWith(","))
                {
                    colString = colString.Substring(0, colString.Length - 1);
                }

                var sqlString = $"UPDATE {tablename} SET {colString} WHERE {GetFirstKey(cond)} = '{GetFirstValue(cond)}';";
                Console.WriteLine(sqlString);

                try
                {
                    using (var cmd = new NpgsqlCommand(sqlString, connectDb))
                    {
                        var response = await cmd.ExecuteNonQueryAsync();

                        return response; // Return the row_id or null if insert failed

                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine($"Error running query: {ex.Message}");
                    throw;
                }
            }

        }

        private static string GetFirstKey(Dictionary<string, object> dict)
        {
            foreach (var key in dict.Keys)
            {
                return key;
            }
            return null;
        }

        private static object GetFirstValue(Dictionary<string, object> dict)
        {
            foreach (var value in dict.Values)
            {
                return value;
            }
            return null;
        }


        // delete data 


        public static async Task<int> DeleteData(string tableName, Dictionary<string, object> cond)
        {
           
            using (var connection = new NpgsqlConnection(ConnectionString))
            {
                await connection.OpenAsync();
                string op = "";
                string condValue;
                if (cond.Values.First() is Array)
                {
                    op = " IN  ";
                    List<string> tcondValue = new List<string>();
                    foreach (var item in (Array)cond.Values.First())
                    {
                        tcondValue.Add($"'{item}'");
                    }
                    condValue = "(" + string.Join(",", tcondValue) + ")";
                }
                else
                {
                    op = " = '";
                    condValue = $"{cond.Values.First()}'";
                }
                string sqlString = $"DELETE FROM {tableName} WHERE {cond.Keys.First()}{op}{condValue};";
                Console.WriteLine(sqlString);


                using (var command = new NpgsqlCommand(sqlString, connection))
                {
                    var response = await command.ExecuteNonQueryAsync();
                    return response;
                }
            }
        }



        // create table

        public static Task CreateTable(string schema, string table, List<Dictionary<string, object>> data)
        {
            return Task.Run(async () =>
            {
                string colString = "row_id text NOT NULL PRIMARY KEY, cr_on timestamp without time zone NOT NULL DEFAULT now(), up_on timestamp without time zone NOT NULL DEFAULT now(), ";
                var lastKey = data.Last();

                for (int k = 0; k < data.Count; k++)
                {
                    var colname = data[k]["id"].ToString().Replace(" ", string.Empty);
                    var coltype = data[k]["fdtype"].ToString();
                    var colNull = (bool)data[k]["required"] ? " NOT NULL" : " NULL ";

                    if (data[k]["id"].ToString() != lastKey["id"].ToString())
                    {
                        colString += colname + " " + coltype + colNull + " , ";
                    }
                    else
                    {
                        colString += colname + " " + coltype + colNull + " ";
                    }
                }

                string sqlString = "CREATE TABLE IF NOT EXISTS " + schema + "." + table + " ( " + colString + ")";
                Console.WriteLine(sqlString);                


                using (var connection = new NpgsqlConnection(ConnectionString))
                {
                    connection.Open();
                    try
                    {
                        using (var cmd = new NpgsqlCommand(sqlString, connection))
                        {
                            var response = await cmd.ExecuteScalarAsync();

                            return response; // Return the row_id or null if insert failed

                        }
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"Error running query: {ex.Message}");
                        throw;
                    }

                }


            });
        }


        // countRecords 

        public static async Task<int?> CountRecordsAsync(string tableName, Dictionary<string, object> conditions)
        {
            string sqlQuery = $"SELECT COUNT(*) as total FROM {tableName}";

            string whereClause;
            if (conditions != null)
            {
                whereClause = PrepareWhereClause(conditions);
            }
            else
            {
                whereClause = ";";
            }

            sqlQuery += whereClause;

            // Assuming ConnectDb is a method that returns a database connection
            using (var connection = new NpgsqlConnection(ConnectionString))
            {
                connection.Open();
                using (var cmd = new NpgsqlCommand(sqlQuery, connection))
                {
                    

                    try
                    {
                        var reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            return reader.GetInt32(0);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine("Error running query: " + ex.Message);
                        return null;
                    }
                }
            }
        }

        private static string PrepareWhereClause(Dictionary<string, object> conditions)
        {
            string whereClause = " WHERE ";

            if (conditions.Count > 1)
            {
                foreach (var condition in conditions)
                {
                    if (condition.Key == "OR")
                    {
                        foreach (var orCondition in (Dictionary<string, object>)condition.Value)
                        {
                            whereClause += CreateConditionString(orCondition.Key, orCondition.Value, "OR");
                        }
                    }
                    else if (condition.Key == "AND")
                    {
                        foreach (var andCondition in (Dictionary<string, object>)condition.Value)
                        {
                            whereClause += CreateConditionString(andCondition.Key, andCondition.Value, "AND");
                        }
                    }
                    else
                    {
                        whereClause += $"{condition.Key} = '{condition.Value}' ";
                    }
                }
            }
            else
            {
                foreach (var condition in conditions)
                {
                    if (condition.Key == "OR" || condition.Key == "AND")
                    {
                        foreach (var subCondition in (Dictionary<string, object>)condition.Value)
                        {
                            whereClause += CreateConditionString(subCondition.Key, subCondition.Value, condition.Key);
                        }
                    }
                    else
                    {
                        whereClause += $"{condition.Key} = '{condition.Value}' ";
                    }
                }
            }

            return whereClause.TrimEnd(' ', 'A', 'N', 'D', 'O', 'R', ';') + " ";
        }

        private static string CreateConditionString(string key, object value, string conjunction)
        {
            if (key.Contains("%"))
            {
                return $"{key.Replace("%", "")}::text ILIKE '%{value}%' {conjunction} ";
            }
            else if (key.Contains("ics"))
            {
                return $"LOWER({key.Replace("ics", "")}) = LOWER('{value}') {conjunction} ";
            }
            else
            {
                return $"{key} = '{value}' {conjunction} ";
            }
        }


        // joins data         

        public static List<Dictionary<string, object>> PrepareJoin(List<Dictionary<string, object>> joins, List<string> selectFields, string orderBy)
        {
            var joinString = new StringBuilder();
            var sqlQuery = new StringBuilder();

            // Start building the SELECT statement
            sqlQuery.Append("SELECT ");

            // Append selected fields
            sqlQuery.Append(string.Join(", ", selectFields));
            sqlQuery.Append(" FROM ");

            // Assume the first table is always the main table (for simplicity)
            if (joins.Count > 0)
            {
                var firstTable = ((List<Dictionary<string, string>>)joins[0]["tables"])[0]["tb"];
                sqlQuery.Append(firstTable);
            }

            foreach (var join in joins)
            {
                // Ensure required keys exist
                if (!join.ContainsKey("jointype") || !join.ContainsKey("tables"))
                {
                    continue; // Skip if required keys are missing
                }

                // Get the join type and convert to uppercase for consistency
                string jointype = join["jointype"].ToString().ToUpper();
                switch (jointype)
                {
                    case "INNER":
                        joinString.Append(" INNER JOIN ");
                        break;
                    case "LEFT":
                        joinString.Append(" LEFT JOIN ");
                        break;
                    case "RIGHT":
                        joinString.Append(" RIGHT JOIN ");
                        break;
                    case "OUTER":
                        joinString.Append(" FULL OUTER JOIN ");
                        break;
                    default:
                        continue; // Skip unrecognized join types
                }

                // Get the list of tables
                var tables = (List<Dictionary<string, string>>)join["tables"];
                if (tables != null && tables.Count >= 2)
                {
                    // Assuming the last table is the one being joined to
                    string targetTable = tables.Last()["tb"];
                    string sourceTable = tables[0]["tb"];

                    // Construct the ON condition using the specified columns
                    string onCondition = $"{sourceTable}.{tables[0]["on"]} = {targetTable}.{tables[1]["on"]}";

                    // Append the target table and ON condition to the join string
                    joinString.Append($"{targetTable} ON {onCondition}");
                }
            }

            // Append joins to SQL query
            sqlQuery.Append(joinString.ToString());

            // Add ORDER BY clause if specified
            if (!string.IsNullOrEmpty(orderBy))
            {
                sqlQuery.Append($" ORDER BY {orderBy};");
            }

            //return sqlQuery.ToString().Trim(); // Return final SQL query

            using (var connection = new NpgsqlConnection(ConnectionString))
            {
                connection.Open();
                using (var command = new NpgsqlCommand(sqlQuery.ToString(), connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        var rows = new List<Dictionary<string, object>>();
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i));
                            }
                            rows.Add(row);
                        }
                        return rows; // Return result as a list of dictionaries
                    }
                }
            }
        }


        // select query


        public static string PrepareOrderBy(Dictionary<string, string> conditions)
        {
            string orderString = " ORDER BY ";
            var lastKey = conditions.Keys.Last();
            foreach (var key in conditions.Keys)
            {
                if (key != lastKey)
                {
                    orderString += key + " " + conditions[key].ToUpper() + " , ";
                }
                else
                {
                    orderString += key + " " + conditions[key].ToUpper();
                }
            }

            return orderString;
        }

        public static string PrepareLimit(Dictionary<string, int> conditions)
        {
            string limitString = " LIMIT ";
            limitString += conditions.Values.First();
            return limitString;
        }

        public static string PrepareOffset(Dictionary<string, int> conditions)
        {
            string offsetString = " OFFSET ";
            offsetString += conditions.Values.First();
            return offsetString;
        }

        public static string PrepareJoin(List<Dictionary<string, object>> joins)
        {
            string joinString = " ";
            foreach (var join in joins)
            {
                if (join["jointype"].ToString() == "inner")
                {
                    joinString += " INNER JOIN ";
                }
                else if (join["jointype"].ToString() == "left")
                {
                    joinString += " LEFT JOIN ";
                }
                else if (join["jointype"].ToString() == "right")
                {
                    joinString += " RIGHT JOIN ";
                }
                else if (join["jointype"].ToString() == "outer")
                {
                    joinString += "FULL OUTER JOIN ";
                }
                if (join["tables"] != null)
                {
                    var tables = join["tables"] as List<Dictionary<string, string>>;
                    joinString += tables.Last()["tb"] + " ON ";
                    joinString += tables[0]["tb"] + "." + tables[0]["on"] + " = " + tables[1]["tb"] + "." + tables[1]["on"];
                }
            }
            return joinString;
        }

        public static async Task<List<Dictionary<string, object>>> SelectQuery(dynamic parameters)
        {
            string joinString = " ";
            string whereString = " ";
            string orderString = " ";
            string limitString = " ";
            string offsetString = " ";
            string sqlString = " ";
            string dataString = "";

            var data = parameters.data as List<string>;
            if (data != null)
            {
                for (int i = 0; i < data.Count; i++)
                {
                    if (i == data.Count - 1)
                    {
                        if (data[i].Contains("-as-"))
                        {
                            dataString += data[i].Split(new[] { "-as-" }, StringSplitOptions.None)[0] + " AS " + data[i].Split(new[] { "-as-" }, StringSplitOptions.None)[1];
                        }
                        else
                        {
                            dataString += data[i];
                        }
                    }
                    else
                    {
                        if (data[i].Contains("-as-"))
                        {
                            dataString += data[i].Split(new[] { "-as-" }, StringSplitOptions.None)[0] + " AS " + data[i].Split(new[] { "-as-" }, StringSplitOptions.None)[1] + ",";
                        }
                        else
                        {
                            dataString += data[i] + ",";
                        }
                    }
                }
            }
            else
            {
                dataString = "*";
            }

            sqlString = "SELECT " + dataString + " FROM " + parameters.tablename;

            Dictionary<string, object> conditions = parameters.cond as Dictionary<string, object>;
            if (conditions != null)
            {
                whereString = PrepareWhereClause(conditions);
            }

            if (parameters.orderby != null)
            {
                orderString = PrepareOrderBy(parameters.orderby);
            }

            if (parameters.limit != null)
            {
                limitString = PrepareLimit(parameters.limit);
            }

            if (parameters.offset != null)
            {
                offsetString = PrepareOffset(parameters.offset);
            }

            if (parameters.joins != null)
            {
                joinString = PrepareJoin(parameters.joins);
            }

            sqlString += " " + joinString + " " + whereString + " " + orderString + " " + limitString + " " + offsetString + ";";

            //database query execution
            //return null;

            using (var connection = new NpgsqlConnection(ConnectionString))
            {
                connection.Open();
                using (var command = new NpgsqlCommand(sqlString.ToString(), connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        var rows = new List<Dictionary<string, object>>();
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i));
                            }
                            rows.Add(row);
                        }
                        return rows; // Return result as a list of dictionaries
                    }
                }
            }
        }



        //custome query 

        public static async Task<List<Dictionary<string, object>>> CustomQuery(string query)
        {
            string sqlString = query;

            Console.WriteLine("sqlString------------");
            Console.WriteLine(sqlString);

            List<Dictionary<string, object>> result = new List<Dictionary<string, object>>();

            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(ConnectionString))
                {
                    await conn.OpenAsync();

                    using (NpgsqlCommand cmd = new NpgsqlCommand(sqlString, conn))
                    {
                        using (NpgsqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                Dictionary<string, object> row = new Dictionary<string, object>();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    row[reader.GetName(i)] = reader.GetValue(i);
                                }
                                result.Add(row);
                            }
                        }
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("error running query: " + ex.Message);
                throw;
            }
        }




    }

}
