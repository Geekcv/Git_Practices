﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EvenbooksUI.Pages
{
    /// <summary>
    /// Interaction logic for Order_Management.xaml
    /// </summary>
    public partial class Order_Management : Page
    {
        private ObservableCollection<OrderManagement> orderManagement;

        public Order_Management()
        {
            InitializeComponent();

            orderManagement = new ObservableCollection<OrderManagement>
            {
                new OrderManagement { Date = "10/3/2024", Time = "3246", OrderNo = "Sugar", MobileNo = "25.00 kg", Amount = "50.00 kg", PaymentType = "45.00",Status = "ui" },
                new OrderManagement { Date = "10/3/2024", Time = "3949", OrderNo = "Jaggery(Gud)", MobileNo = "15.00 kg", Amount = "35.00 kg", PaymentType = "45.00",Status = "ui"  },
                new OrderManagement { Date = "10/3/2024", Time = "3966", OrderNo = "Red Chilli Powder", MobileNo = "10.00 kg", Amount = "25.00 kg", PaymentType = "45.00" , Status = "ui"},
                new OrderManagement { Date = "10/3/2024", Time = "9442", OrderNo = "Almond", MobileNo = "10.00 kg", Amount = "15.00 kg", PaymentType = "45.00", Status = "ui" },
                new OrderManagement { Date = "10/3/2024", Time = "8556", OrderNo = "Hand Wash", MobileNo = "40", Amount = "50.00", PaymentType = "45.00" , Status = "ui"},
                new OrderManagement { Date = "10/3/2024", Time = "9442", OrderNo = "Almond", MobileNo = "11.00 kg", Amount = "15.00 kg", PaymentType = "45.00",Status = "ui" }
            };

            BillsDataGrid.ItemsSource = orderManagement;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void print_Click_(object sender, RoutedEventArgs e)
        {

        }
    }
}

public class OrderManagement
{
    public string Date { get; set; }
    public string Time { get; set; }
    public string OrderNo { get; set; }
    public string MobileNo { get; set; }
    public string Amount { get; set; }
    public string PaymentType { get; set; }
    public string Status { get; set; }

}
