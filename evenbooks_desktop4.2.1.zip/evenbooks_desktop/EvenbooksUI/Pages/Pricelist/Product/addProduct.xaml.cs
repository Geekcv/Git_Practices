﻿using EvenbooksUI.connect_db;
using EvenbooksUI.function;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace EvenbooksUI.Pages.Pricelist.Product
{
    /// <summary>
    /// Interaction logic for addProduct.xaml
    /// </summary>
    public partial class addProduct : Page
    {
        private string products = "eb" + ".products2";

        public addProduct()
        {
            InitializeComponent();
        }



        private void DataGridResult_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            Dictionary<string, string> columnDisplayNames = new Dictionary<string, string>
    {
        { "S.No", "S.No" },
        { "product_name", "Product Name" },
        { "product_code", "Product Code" },
        { "weight_kg", "Weight (Kg)" },
        { "weight_gm", "Weight (Gm)" },
        { "volume_liter", "Volume (L)" },
        { "volume_ml", "Volume (ML)" }

    };

            // Change column headers for better readability
            if (columnDisplayNames.ContainsKey(e.PropertyName))
            {
                e.Column.Header = columnDisplayNames[e.PropertyName];
            }

            // Ensure "S.No" appears first
            if (e.PropertyName == "S.No")
            {
                e.Column.DisplayIndex = 0; // Move to first position
            }

            // Hide "row_id" as it's internal
            if (e.PropertyName == "row_id")
            {
                e.Column.Visibility = Visibility.Collapsed;
            }
        }


        private void CmbUnitType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedUnit = (cmbUnitType.SelectedItem as ComboBoxItem)?.Content.ToString();

            // Hide all unit panels first
            kgPanel.Visibility = Visibility.Collapsed;
            gPanel.Visibility = Visibility.Collapsed;
            literPanel.Visibility = Visibility.Collapsed;
            mlPanel.Visibility = Visibility.Collapsed;

            if (selectedUnit == "kg" || selectedUnit == "g")
            {
                kgPanel.Visibility = Visibility.Visible;
                gPanel.Visibility = Visibility.Visible;
            }
            else if (selectedUnit == "L")
            {
                literPanel.Visibility = Visibility.Visible;
            }
            else if (selectedUnit == "mL")
            {
                mlPanel.Visibility = Visibility.Visible;
            }

        }




        private async void BtnShow_Click(object sender, RoutedEventArgs e)
        {
            string selectedFilter = ((ComboBoxItem)cmbFilter.SelectedItem).Content.ToString();
            Dictionary<string, object> conditions = new Dictionary<string, object>();

            if (selectedFilter == "Finalized")
                conditions.Add("is_draft", false);
            else if (selectedFilter == "Draft")
                conditions.Add("is_draft", true);

            List<Dictionary<string, object>> xmlResult = await queries.FetchData(products, conditions);
            DataTable dt = functions.ConvertToDataTable(xmlResult, new List<string> { "row_id", "product_name", "product_code", "weight_kg", "weight_gm", "volume_liter","volume_ml", "is_draft" });

            if (!dt.Columns.Contains("S.No"))
                dt.Columns.Add("S.No", typeof(int)).SetOrdinal(0);

            int serialNumber = 1;
            foreach (DataRow row in dt.Rows)
                row["S.No"] = serialNumber++;

            dataGridResult.ItemsSource = dt.DefaultView;
        }





        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            await SaveProduct(false);  // Save as finalized
        }

        private async void BtnSaveDraft_Click(object sender, RoutedEventArgs e)
        {
            await SaveProduct(true);  // Save as draft
        }

        private async Task SaveProduct(bool isDraft)
        {
            var row_id = functions.RandomId();
            string productName = txtProductName.Text;
            int productCode = Convert.ToInt32(txtProductCode.Text);
            double priceWithoutGst = Convert.ToDouble(txtPriceWithoutGst.Text);
            double priceWithGst = Convert.ToDouble(txtPriceWithGst.Text);
            string selectedUnit = (cmbUnitType.SelectedItem as ComboBoxItem)?.Content.ToString();

            double? weightKg = null, weightGm = null, volumeL = null, volumeMl = null;

            // Assign values based on unit type
            if (selectedUnit == "kg" || selectedUnit == "g")
            {
                weightKg = Convert.ToDouble(txtWeightKg.Text);
                weightGm = Convert.ToDouble(txtWeightGm.Text);
            }
            else if (selectedUnit == "g")
                weightGm = Convert.ToDouble(txtWeightGm.Text);
            else if (selectedUnit == "L")
                volumeL = Convert.ToDouble(txtVolumeL.Text);
            else if (selectedUnit == "mL")
                volumeMl = Convert.ToDouble(txtVolumeMl.Text);



            double gst_percentage = Convert.ToDouble(txtgst_percentage.Text);

            var columns = new Dictionary<string, object>
            {
                { "row_id", row_id },
                { "product_name", productName },
                { "product_code", productCode },
        { "unit_type", selectedUnit },
        { "weight_kg", weightKg },
        { "weight_gm", weightGm },
        { "volume_liter", volumeL },
        { "volume_ml", volumeMl },

                { "price_withoutgst", priceWithoutGst },
                { "price_withgst", priceWithGst },
                { "gst", gst_percentage },
                { "is_draft", isDraft }
            };

            var result = await queries.InsertData(products, columns);
            MessageBox.Show(result != null ? $"Product {productName} saved successfully!" : $"Failed to save {productName}.", "Status", MessageBoxButton.OK);
        }

        private void CmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            BtnShow_Click(null, null);
        }


        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (DataRowView)dataGridResult.SelectedItem;
            if (selectedProduct != null)
            {
                EditProductPage editProductPage = new EditProductPage(selectedProduct.Row);
                editProductPage.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a product to edit.");
            }
        }

        private async void Btndel_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (DataRowView)dataGridResult.SelectedItem;
            if (selectedProduct != null)
            {
                var data = selectedProduct.Row;
                var productId = data["row_id"].ToString();


                var comm = new Dictionary<string, object>
                 {
                    { "row_id", productId },
                };

                // Create instance of DatabaseHelper
                var result = await queries.DeleteData(products, comm);

                if (result != null)
                {
                    MessageBox.Show("Data delete successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Failed to delete data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
            else
            {
                MessageBox.Show("Please select a product to edit.");
            }
        }

        // Clear form fields for new entry
        private void BtnAddNew_Click(object sender, RoutedEventArgs e)
        {
            txtProductName.Clear();
            txtProductCode.Clear();
            txtWeightKg.Clear();
            txtWeightGm.Clear();
            txtPriceWithoutGst.Clear();
            txtPriceWithGst.Clear();
            txtgst_percentage.Clear();
        }


    }
}
