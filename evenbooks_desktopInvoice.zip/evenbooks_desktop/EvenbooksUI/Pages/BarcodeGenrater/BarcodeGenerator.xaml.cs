﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using ZXing;
using ZXing.Common;
using ZXing.Rendering;

namespace EvenbooksUI.Pages
{
    public partial class BarcodeGenerator : Page
    {
        public BarcodeGenerator()
        {
            InitializeComponent();
            btnGenerateBarcode.Click += BtnGenerateBarcode_Click;
        }

        private void BtnGenerateBarcode_Click(object sender, RoutedEventArgs e)
        {
            string productCode = txtProductCode.Text;
            string productName = txtProductName.Text;
            string weightKg = txtWeightKg.Text;
            string weightGm = txtWeightGm.Text;
            string price = txtPrice.Text;

            // Get selected dates (format as "dd/MM/yyyy")
            string packingDate = dpPackingDate.SelectedDate?.ToString("dd/MM/yyyy") ?? "N/A";
            string expDate = dpExpDate.SelectedDate?.ToString("dd/MM/yyyy") ?? "N/A";

            if (string.IsNullOrWhiteSpace(productCode))
            {
                MessageBox.Show("Enter Product Code to generate barcode.");
                return;
            }

            try
            {
                string barcodeData = $"{productCode}|{productName}|{weightKg}Kg";

                var barcodeWriter = new BarcodeWriterPixelData
                {
                    Format = BarcodeFormat.CODE_128,
                    Options = new EncodingOptions
                    {
                        Width = 600, // Increased width for better clarity
                        Height = 200, // Increased height for better readability
                        Margin = 5,  // Reduce margin for a compact look
                        PureBarcode = true // Removes unnecessary space
                    }
                };

                var pixelData = barcodeWriter.Write(barcodeData);
                barcodeImage.Source = ConvertToBitmapSource(pixelData);

                // 🔹 Set all product details below barcode
                txtBarcodeDetails.Text = $"Product: {productName}\n" +
                                         $"Code: {productCode}\n" +
                                         $"Weight: {weightKg} Kg / {weightGm} gm\n" +
                                         $"Price: Rs. {price}\n" +
                                         $"Packing Date: {packingDate}  |  Expiry Date: {expDate}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating barcode: {ex.Message}");
            }
        }

        private BitmapSource ConvertToBitmapSource(PixelData pixelData)
        {
            return BitmapSource.Create(
                pixelData.Width, pixelData.Height,
                600, 600, // 🔹 Higher DPI for sharper display
                System.Windows.Media.PixelFormats.Bgra32, // 🔹 Better quality over Gray8
                null, pixelData.Pixels, pixelData.Width * 4);
        }
    }
}
