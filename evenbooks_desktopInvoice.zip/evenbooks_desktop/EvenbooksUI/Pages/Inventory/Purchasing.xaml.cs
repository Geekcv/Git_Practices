﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EvenbooksUI.Pages
{
    /// <summary>
    /// Interaction logic for Purchasing.xaml
    /// </summary>
    public partial class Purchasing : Page
    {
        private ObservableCollection<Order1> itemList;
        private const double ThermalPrinterWidthInches = 2.28; // 58mm
        private const double Dpi = 96; // Standard DPI
        public Purchasing()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        // print design of invoice for thermal printer 


        private void Print_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();

            // Create invoice content dynamically
            UIElement invoiceContent = CreateInvoiceContent();

            // Customize area of documents
            FixedDocument fixedDoc = CreateFixedDocument(invoiceContent);

            // Show the Print Preview Window
            PrintPreviewWindow previewWindow = new PrintPreviewWindow(fixedDoc);
            previewWindow.ShowDialog();

            // If the user confirms, proceed with printing
            if (printDialog.ShowDialog() == true)
            {
                // Set the document paginator to print
                printDialog.PrintDocument(fixedDoc.DocumentPaginator, "Printing Page Content");
            }
        }


        private UIElement CreateInvoiceContent()
        {
            StackPanel mainPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Width = WidthInchesToDPI(3.15) // Approx 80mm for thermal printer
            };


            // Add Logo Image at the Top
            Image logoImage = new Image
            {
                Source = new BitmapImage(new Uri("E:\\Dot-net\\evenbooks_desktop\\evenbooks_desktop\\EvenbooksUI\\assets\\icons\\Invoice.png")), // Change the path as needed
                Width = 80, // Adjust as needed
                Height = 40, // Adjust as needed
                Margin = new Thickness(5, 5, 5, 5),
                HorizontalAlignment = HorizontalAlignment.Center
            };

            mainPanel.Children.Add(logoImage); // Add Image to the Invoice


            // Header
            mainPanel.Children.Add(new TextBlock
            {
                Text = "KANKARIA MASALA UDYOG",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center
            });

            mainPanel.Children.Add(new TextBlock
            {
                Text = "O/S SIWANCHI GATE, PRATAP NAGAR ROAD, JODHPUR",
                FontSize = 8,
                TextAlignment = TextAlignment.Center
            });

            mainPanel.Children.Add(new TextBlock
            {
                Text = "GSTIN: 08ADVPJ00559R1ZK",
                FontSize = 8,
                TextAlignment = TextAlignment.Center
            });

            mainPanel.Children.Add(new TextBlock
            {
                Text = "FSSAI No: 12219032000763",
                FontSize = 8,
                TextAlignment = TextAlignment.Center
            });

            mainPanel.Children.Add(new TextBlock
            {
                Text = "Mobile Number: 12219032000763",
                FontSize = 8,
                TextAlignment = TextAlignment.Center
            });

            mainPanel.Children.Add(new TextBlock
            {
                Text = "Email Address: abhi@gmail.com",
                FontSize = 8,
                TextAlignment = TextAlignment.Center
            });

            mainPanel.Children.Add(new TextBlock
            {
                Text = "--------------------------------------------------------------------------------------",
                FontSize = 8,
                TextAlignment = TextAlignment.Left
            });

            // Order Details
            StackPanel orderInfoPanel = new StackPanel { Margin = new Thickness(5, 2, 0, 5) };
            orderInfoPanel.Children.Add(new TextBlock { Text = $"No.: MB/24-25/37015    Date: 05/06/2025   Time: 11:30 AM", FontSize = 8 });
            orderInfoPanel.Children.Add(new TextBlock { Text = $"Name: Abhishek", FontSize = 8 });
            orderInfoPanel.Children.Add(new TextBlock { Text = $"Phone: 9789454542   Mode: CASH", FontSize = 8 });
            orderInfoPanel.Children.Add(new TextBlock { Text = $"Comp: DESKTOPP-ROLDES9", FontSize = 8 });

            mainPanel.Children.Add(orderInfoPanel);

            mainPanel.Children.Add(new TextBlock
            {
                Text = "--------------------------------------------------------------------------------------",
                FontSize = 8,
                TextAlignment = TextAlignment.Left
            });

            // Items Header
            StackPanel itemsHeader = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5, 2, 0, 2) };
            itemsHeader.Children.Add(new TextBlock { Text = "Item", Width = 70, FontWeight = FontWeights.Bold, FontSize = 8 });
            itemsHeader.Children.Add(new TextBlock { Text = "GST%", Width = 40, FontWeight = FontWeights.Bold, FontSize = 8 });
            itemsHeader.Children.Add(new TextBlock { Text = "Qty", Width = 40, FontWeight = FontWeights.Bold, FontSize = 8 });
            itemsHeader.Children.Add(new TextBlock { Text = "Rate", Width = 40, FontWeight = FontWeights.Bold, FontSize = 8 });
            itemsHeader.Children.Add(new TextBlock { Text = "Amt", Width = 50, FontWeight = FontWeights.Bold, FontSize = 8 });

            mainPanel.Children.Add(itemsHeader);

            // Sample Items
            ObservableCollection<Order1> itemList = new ObservableCollection<Order1>
    {
        new Order1 { ItemName = "Dhania Powder", GST = 5, Qty = "250 GMS", Price = 160, Total = 40 },
        new Order1 { ItemName = "Haldi Powder", GST = 5, Qty = "250 GMS", Price = 200, Total = 50 },
        new Order1 { ItemName = "Jeera Premium", GST = 5, Qty = "150 GMS", Price = 330, Total = 49.50 },
        new Order1 { ItemName = "Mirchi Powder", GST = 5, Qty = "500 GMS", Price = 240, Total = 120 },
        new Order1 { ItemName = "Sabat Kali Mirchi", GST = 5, Qty = "50 GMS", Price = 1000, Total = 50 },
        new Order1 { ItemName = "Sabat Methi", GST = 5, Qty = "250 GMS", Price = 84, Total = 21 }
    };

            foreach (var item in itemList)
            {
                StackPanel itemRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5, 0, 0, 0) };
                itemRow.Children.Add(new TextBlock { Text = item.ItemName, Width = 70, FontSize = 8 });
                itemRow.Children.Add(new TextBlock { Text = item.GST.ToString(), Width = 40, FontSize = 8 });
                itemRow.Children.Add(new TextBlock { Text = item.Qty, Width = 40, FontSize = 8 });
                itemRow.Children.Add(new TextBlock { Text = item.Price.ToString("F2"), Width = 40, FontSize = 8 });
                itemRow.Children.Add(new TextBlock { Text = item.Total.ToString("F2"), Width = 50, FontSize = 8 });

                mainPanel.Children.Add(itemRow);
            }

            mainPanel.Children.Add(new TextBlock
            {
                Text = "--------------------------------------------------------------------------------------",
                FontSize = 8,
                TextAlignment = TextAlignment.Left
            });

            // Total Calculation
            StackPanel totalPanel = new StackPanel { Margin = new Thickness(5, 5, 0, 5) };
            totalPanel.Children.Add(new TextBlock { Text = "Total Items: 6              Weight: 1.450 Kg               330.50", FontSize = 8 });

            totalPanel.Children.Add(new TextBlock
            {
                Text = "--------------------------------------------------------------------------------------",
                FontSize = 8,
                TextAlignment = TextAlignment.Left
            });
            totalPanel.Children.Add(new TextBlock { Text = "Net Total:                                        ₹330.00", FontWeight = FontWeights.Bold, FontSize = 11 });

            mainPanel.Children.Add(totalPanel);

            mainPanel.Children.Add(new TextBlock
            {
                Text = "--------------------------------------------------------------------------------------",
                FontSize = 8,
                TextAlignment = TextAlignment.Left
            });

            // Tax Details
            //StackPanel taxPanel = new StackPanel { Margin = new Thickness(5, 5, 0, 5) };
            //taxPanel.Children.Add(new TextBlock { Text = "Tax Details", FontWeight = FontWeights.Bold, FontSize = 8, TextAlignment =TextAlignment.Center });
            //taxPanel.Children.Add(new TextBlock { Text = "GST%   Sales   CGST   SGST   Amount", FontSize = 8 });
            //taxPanel.Children.Add(new TextBlock { Text = "5.00    314.76    7.87    7.87    330.50", FontSize = 8 });


            // Tax Details Section
            // Tax Details Section
            StackPanel taxPanel = new StackPanel { Margin = new Thickness(5, 5, 0, 5) };

            // Title
            taxPanel.Children.Add(new TextBlock
            {
                Text = "Tax Details",
                FontWeight = FontWeights.Bold,
                FontSize = 8,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            });

            // Creating a Grid for Table Formatting
            Grid taxGrid = new Grid
            {
                Margin = new Thickness(5, 2, 0, 2)
            };

            // Define Columns
            taxGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) }); // GST%
            taxGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) }); // Sales
            taxGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) }); // CGST
            taxGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) }); // SGST
            taxGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) }); // Amount

            // Define Rows
            taxGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header Row
            taxGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Data Row

            // Add Header Row
            AddTableCell(taxGrid, "GST%", 0, 0, true);
            AddTableCell(taxGrid, "Sales", 0, 1, true);
            AddTableCell(taxGrid, "CGST", 0, 2, true);
            AddTableCell(taxGrid, "SGST", 0, 3, true);
            AddTableCell(taxGrid, "Amount", 0, 4, true);

            // Add Data Row
            AddTableCell(taxGrid, "5.00", 1, 0);
            AddTableCell(taxGrid, "314.76", 1, 1);
            AddTableCell(taxGrid, "7.87", 1, 2);
            AddTableCell(taxGrid, "7.87", 1, 3);
            AddTableCell(taxGrid, "330.50", 1, 4);

            // Add Grid to StackPanel
            taxPanel.Children.Add(taxGrid);

            // Function to Create Table Cells with Proper Borders
            void AddTableCell(Grid grid, string text, int row, int column, bool isBold = false)
            {
                Border border = new Border
                {
                    BorderThickness = new Thickness(1), // Set black border
                    BorderBrush = Brushes.Gray, // Black border color
                    Background = Brushes.White, // Ensure white background
                    Child = new TextBlock
                    {
                        Text = text,
                        FontSize = 8,
                        FontWeight = isBold ? FontWeights.Bold : FontWeights.Normal,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center,
                        Padding = new Thickness(2),
                        Foreground = Brushes.Black // Ensure black text
                    }
                };

                Grid.SetRow(border, row);
                Grid.SetColumn(border, column);
                grid.Children.Add(border);
            }



            mainPanel.Children.Add(taxPanel);

            mainPanel.Children.Add(new TextBlock
            {
                Text = "--------------------------------------------------------------------------------------",
                FontSize = 8,
                TextAlignment = TextAlignment.Left
            });

            // Footer Message
            mainPanel.Children.Add(new TextBlock
            {
                Text = "Thank You Visit Again!",
                Margin = new Thickness(5, 5, 0, 0),
                TextAlignment = TextAlignment.Center,
                FontWeight = FontWeights.Bold,
                FontSize = 9
            });

            return mainPanel;
        }


        private double WidthInchesToDPI(double inches) => inches * Dpi;


        private FixedDocument CreateFixedDocument(UIElement element)
        {
            FixedDocument fixedDoc = new FixedDocument();
            PageContent pageContent = new PageContent();
            FixedPage fixedPage = new FixedPage();

            // Set Page Size for Thermal Printer (e.g., 80mm width)
            double thermalPrinterWidth = 80 * 3.7795275591; // Convert mm to pixels 1 mm = 3.7795275591 pixel (X)
            double thermalPrinterHeight = 1000; // Set a height that fits your content

            fixedPage.Width = thermalPrinterWidth;
            fixedPage.Height = thermalPrinterHeight;

            // Render element inside a Visual Brush
            VisualBrush visualBrush = new VisualBrush(element)
            {
                Stretch = Stretch.Uniform,
                AlignmentY = AlignmentY.Top,
                //TileMode = TileMode.Tile,
            };

            Rectangle rect = new Rectangle
            {
                Width = fixedPage.Width,
                Height = fixedPage.Height,
                Fill = visualBrush
            };

            fixedPage.Children.Add(rect);

            ((IAddChild)pageContent).AddChild(fixedPage);
            fixedDoc.Pages.Add(pageContent);

            return fixedDoc;
        }






    }
}
public class Order1
{
    public int SerialNo { get; set; }
    public string ItemName { get; set; }
    public int GST { get; set; }
    public string Qty { get; set; }
    public double QtyPerUnit { get; set; }
    public int Price { get; set; }
    public double Total { get; set; }


}

