﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EvenbooksUI.Pages
{
    /// <summary>
    /// Interaction logic for InvoiceBilling.xaml
    /// </summary>
    public partial class InvoiceBilling : Page
    {
        public InvoiceBilling()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        //private void print_Click_(object sender, RoutedEventArgs e)
        //{
        //    // Clear RightSideStackPanel before adding new content
        //    RightSideStackPanel.Children.Clear();

        //    // Clone LeftSideGrid content and add to RightSideStackPanel
        //    foreach (object child in LeftSideGrid.Children)
        //    {
        //        if (child is UIElement uiElement)
        //        {
        //            UIElement clonedElement = CloneElement(uiElement);
        //            if (clonedElement != null)
        //            {
        //                RightSideStackPanel.Children.Add(clonedElement);
        //            }
        //        }
        //    }

        //    // Print only the RightSideStackPanel
        //    PrintDialog printDialog = new PrintDialog();
        //    if (printDialog.ShowDialog() == true)
        //    {
        //        printDialog.PrintVisual(RightSideStackPanel, "Printing Invoice on Right Side");
        //    }
        //}

        //// Helper method to clone UI elements
        //private UIElement CloneElement(UIElement element)
        //{
        //    if (element is TextBlock textBlock)
        //    {
        //        return new TextBlock
        //        {
        //            Text = textBlock.Text,
        //            FontSize = textBlock.FontSize,
        //            FontWeight = textBlock.FontWeight,
        //            Foreground = textBlock.Foreground,
        //            TextAlignment = textBlock.TextAlignment
        //        };
        //    }
        //    else if (element is Label label)
        //    {
        //        return new Label
        //        {
        //            Content = label.Content,
        //            FontSize = label.FontSize,
        //            FontWeight = label.FontWeight,
        //            Foreground = label.Foreground
        //        };
        //    }
        //    else if (element is TextBox textBox)
        //    {
        //        return new TextBox
        //        {
        //            Text = textBox.Text,
        //            Width = textBox.Width,
        //            MinWidth = textBox.MinWidth,
        //            Margin = textBox.Margin
        //        };
        //    }
        //    else if (element is DatePicker datePicker)
        //    {
        //        return new DatePicker
        //        {
        //            SelectedDate = datePicker.SelectedDate,
        //            MinWidth = datePicker.MinWidth,
        //            Margin = datePicker.Margin
        //        };
        //    }
        //    else if (element is Button button)
        //    {
        //        return new Button
        //        {
        //            Content = button.Content,
        //            MinWidth = button.MinWidth,
        //            Height = button.Height,
        //            Background = button.Background,
        //            Foreground = button.Foreground,
        //            FontWeight = button.FontWeight
        //        };
        //    }

        //    return null; // Skip unsupported elements
        //}

        //// Helper method to clone UI elements
      


        private void go_Click(object sender, RoutedEventArgs e)
        {
            //StackPanel.Visibility = Visibility.Collapsed;
            //MainFrame.Navigate(new newBilling());


            NavigationService.Navigate(new Checker());

        }


        private void Print_Click(object sender, RoutedEventArgs e)
        {
            // Clear RightSideStackPanel before adding new content
            RightSideStackPanel.Children.Clear();

            // Clone LeftSideGrid content and add to RightSideStackPanel
            foreach (UIElement child in LeftSideGrid.Children)
            {
                UIElement clonedElement = CloneElement(child);
                if (clonedElement != null)
                {
                    RightSideStackPanel.Children.Add(clonedElement);
                }
            }

            // Print only the RightSideStackPanel
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                printDialog.PrintVisual(RightSideStackPanel, "Printing Invoice on Right Side");
            }
        }

        // Helper method to clone UI elements
        private UIElement CloneElement(UIElement element)
        {
            if (element is TextBlock textBlock)
            {
                return new TextBlock
                {
                    Text = textBlock.Text,
                    FontSize = textBlock.FontSize,
                    FontWeight = textBlock.FontWeight,
                    Foreground = textBlock.Foreground,
                    TextAlignment = textBlock.TextAlignment
                };
            }
            else if (element is Label label)
            {
                return new Label
                {
                    Content = label.Content,
                    FontSize = label.FontSize,
                    FontWeight = label.FontWeight,
                    Foreground = label.Foreground
                };
            }
            else if (element is TextBox textBox)
            {
                return new TextBox
                {
                    Text = textBox.Text,
                    Width = textBox.Width,
                    MinWidth = textBox.MinWidth,
                    Margin = textBox.Margin,
                    IsReadOnly = true // Make it non-editable
                };
            }
            else if (element is DatePicker datePicker)
            {
                return new DatePicker
                {
                    SelectedDate = datePicker.SelectedDate,
                    MinWidth = datePicker.MinWidth,
                    Margin = datePicker.Margin,
                    IsEnabled = false // Disable for print view
                };
            }
            else if (element is Button button)
            {
                return new Button
                {
                    Content = button.Content,
                    MinWidth = button.MinWidth,
                    Height = button.Height,
                    Background = button.Background,
                    Foreground = button.Foreground,
                    FontWeight = button.FontWeight,
                    IsEnabled = false // Disable button in print view
                };
            }

            return null; // Skip unsupported elements
        }

        
    }
}
