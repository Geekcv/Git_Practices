﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EvenbooksUI
{
    public class ModernPrintDialogHelper
    {
        [DllImport("printui.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int PrintDlgEx(ref PRINTDLGEX lppd);

        [StructLayout(LayoutKind.Sequential)]
        public struct PRINTDLGEX
        {
            public int lStructSize;
            public IntPtr hwndOwner;
            public IntPtr hDevMode;
            public IntPtr hDevNames;
            public IntPtr hDC;
            public int Flags;
            public int Flags2;
            public int ExclusionFlags;
            public int nPageRanges;
            public int nMaxPageRanges;
            public IntPtr lpPageRanges;
            public int nMinPage;
            public int nMaxPage;
            public int nCopies;
            public IntPtr hInstance;
            public IntPtr lpPrintTemplateName;
            public IntPtr lpCallback;
            public int nPropertyPages;
            public IntPtr lphPropertyPages;
            public int nStartPage;
            public int dwResultAction;
        }

        public static bool ShowModernPrintDialog(Window owner)
        {
            PRINTDLGEX pdx = new PRINTDLGEX();
            pdx.lStructSize = Marshal.SizeOf(typeof(PRINTDLGEX));
            pdx.hwndOwner = new System.Windows.Interop.WindowInteropHelper(owner).Handle;
            pdx.Flags = 0x00000002 | 0x00000004 | 0x00000008; // Enable modern print dialog

            int result = PrintDlgEx(ref pdx);

            return (result == 0);
        }

    }
}
