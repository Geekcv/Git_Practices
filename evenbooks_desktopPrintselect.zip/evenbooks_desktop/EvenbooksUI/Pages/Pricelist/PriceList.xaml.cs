﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EvenbooksUI.Pages
{
    /// <summary>
    /// Interaction logic for PriceList.xaml
    /// </summary>
    public partial class PriceList : Page
    {
        private ObservableCollection<Item> itemList;

        public PriceList()
        {
            InitializeComponent();

            itemList = new ObservableCollection<Item>
            {
                new Item { SerialNo = 1, Code = 3246, ItemName = "Sugar", SaleQty = "25.00 kg", PurchaseQty = "50.00 kg", Price = 45.00 },
                new Item { SerialNo = 2, Code = 3949, ItemName = "Jaggery(Gud)", SaleQty = "15.00 kg", PurchaseQty = "35.00 kg", Price = 40.00 },
                new Item { SerialNo = 3, Code = 3966, ItemName = "Red Chilli Powder", SaleQty = "10.00 kg", PurchaseQty = "25.00 kg", Price = 180.00 },
                new Item { SerialNo = 4, Code = 9442, ItemName = "Almond", SaleQty = "10.00 kg", PurchaseQty = "15.00 kg", Price = 550.00 },
                new Item { SerialNo = 5, Code = 8556, ItemName = "Hand Wash", SaleQty = "40", PurchaseQty = "50.00", Price = 100.00 },
                new Item { SerialNo = 6, Code = 9442, ItemName = "Almond", SaleQty = "11.00 kg", PurchaseQty = "15.00 kg", Price = 350.00 }
            };

            dgPriceList.ItemsSource = itemList;
        }

        private void AddEntry_Click(object sender, RoutedEventArgs e)
        {
            itemList.Add(new Item { SerialNo = itemList.Count + 1, Code = 1234, ItemName = "New Item", SaleQty = "5 kg", PurchaseQty = "10 kg", Price = 100.00 });

        }

        private void RemoveEntry_Click(object sender, RoutedEventArgs e)
        {
            if (dgPriceList.SelectedItem is Item selectedItem)
            {
                itemList.Remove(selectedItem);
            }
        }

        private void EditEntry_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DeleteEntry_Click(object sender, RoutedEventArgs e)
        {
            if (dgPriceList.SelectedItem is Item selectedItem)
            {
                itemList.Remove(selectedItem);
            }
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Printing Price List...", "Print", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}


public class Item
{
    public int SerialNo { get; set; }
    public int Code { get; set; }
    public string ItemName { get; set; }
    public string SaleQty { get; set; }
    public string PurchaseQty { get; set; }
    public double Price { get; set; }
}
