﻿using System.Windows;
using System.Windows.Documents;
using System.Printing;
using System.Windows.Controls;

namespace EvenbooksUI
{
    public partial class PrintPreviewWindow : Window
    {
        private FixedDocument _document;

        public PrintPreviewWindow(FixedDocument document)
        {
            InitializeComponent();
            _document = document;
            docViewer.Document = _document;
        }

        // Print Button Click
        private void Print_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                printDialog.PrintDocument(_document.DocumentPaginator, "Printing Document");
                MessageBox.Show("Printing completed successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close(); // Close preview after printing
            }
        }

        // Cancel Button Click
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // Close the preview window
        }
    }
}
