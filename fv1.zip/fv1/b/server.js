const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { Pool } = require("pg");
const { v4: uuidv4 } = require("uuid"); // Import UUID

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// PostgreSQL Client setup
const pool = new Pool({
  user: "postgres", // Replace with your PostgreSQL username
  host: "localhost", // Replace with your host if different
  database: "form_builder", // The database name
  password: "Admin", // Replace with your password
  port: 5432,
});

// Save the form data to the database
app.post("/save-form", async (req, res) => {
  const formData = req.body.formItems;

  if (formData && Array.isArray(formData)) {
    const formLink = uuidv4(); // Generate a unique link for the form

    try {
      // Insert the form data into the database along with the generated link
      const result = await pool.query(
        "INSERT INTO forms(form_data, form_link) VALUES($1, $2) RETURNING id, form_link",
        [JSON.stringify(formData), formLink]
      );

      return res.status(200).json({
        message: "Form saved successfully",
        formId: result.rows[0].id,
        formLink: result.rows[0].form_link, // Return the form's unique link
      });
    } catch (err) {
      console.error("Error saving form:", err);
      return res.status(500).json({ message: "Error saving form" });
    }
  }

  return res.status(400).json({ message: "Invalid form data" });
});

// Load saved form data by link
app.get("/load-form/:link", async (req, res) => {
  const { link } = req.params;

  try {
    // Fetch the form data using the unique link
    const result = await pool.query(
      "SELECT form_data FROM forms WHERE form_link = $1",
      [link]
    );

    if (result.rows.length > 0) {
      return res.status(200).json({ formItems: result.rows[0].form_data });
    }

    return res.status(404).json({ message: "Form not found" });
  } catch (err) {
    console.error("Error loading form:", err);
    return res.status(500).json({ message: "Error loading form" });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
