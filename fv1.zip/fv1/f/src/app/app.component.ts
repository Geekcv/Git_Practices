import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormBuilderComponent } from './components/form-builder/form-builder.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,FormBuilderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'form-builder-frontend';
}
