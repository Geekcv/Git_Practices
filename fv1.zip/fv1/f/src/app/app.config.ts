import { provideRouter, Routes } from '@angular/router';
import { FormBuilderComponent } from './components/form-builder/form-builder.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'form-builder', component: FormBuilderComponent },
];

export const appConfig = {
  providers: [provideRouter(routes)],
};
