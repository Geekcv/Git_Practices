import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgIf, NgFor } from '@angular/common';
import axios from 'axios';

@Component({
  selector: 'app-form-builder',
  standalone: true,
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css'],
  imports: [FormsModule, NgFor, NgIf],
})
export class FormBuilderComponent {
  availableElements = [
    { type: 'text', label: 'Text Input', placeholder: 'Enter text' },
    { type: 'checkbox', label: 'Checkbox', checked: false },
    { type: 'radio', label: 'Radio Button', options: ['Option 1', 'Option 2'] },
    { type: 'textarea', label: 'Textarea', placeholder: 'Enter description' },
    { type: 'select', label: 'Dropdown', options: ['Option 1', 'Option 2', 'Option 3'] },
    { type: 'number', label: 'Number Input', min: 0, max: 100 },
    { type: 'date', label: 'Date Picker' },
    { type: 'button', label: 'Button', text: 'Click Me' },
  ];

  formItems: any[] = [];
  formLink: string | null = null;
  formLinkInput: string = '';

  onDragStart(event: DragEvent, element: any) {
    event.dataTransfer?.setData('element', JSON.stringify(element));
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const elementData = event.dataTransfer?.getData('element');
    if (elementData) {
      const element = JSON.parse(elementData);
      this.formItems.push({ ...element, id: new Date().getTime(), isEditing: false });
    }
  }

  saveForm() {
    axios
      .post('http://localhost:3000/save-form', { formItems: this.formItems })
      .then((response) => {
        console.log('Form saved:', response.data);
        this.formLink = response.data.formLink;
      })
      .catch((error) => console.error('Error saving form:', error));
  }

  loadForm() {
    if (this.formLinkInput) {
      axios
        .get(`http://localhost:3000/load-form/${this.formLinkInput}`)
        .then((response) => {
          this.formItems = response.data.formItems;
        })
        .catch((error) => console.error('Error loading form:', error));
    }
  }

  toggleEditLabel(index: number) {
    this.formItems[index].isEditing = !this.formItems[index].isEditing;
  }

  updateLabel(index: number, newLabel: string) {
    this.formItems[index].label = newLabel;
    this.formItems[index].isEditing = false;
  }

  removeElement(index: number) {
    this.formItems.splice(index, 1); // Remove the element at the given index
  }

  addOption(index: number) {
    this.formItems[index].options.push('New Option');
  }

  removeOption(index: number, optionIndex: number) {
    this.formItems[index].options.splice(optionIndex, 1);
  }
}
