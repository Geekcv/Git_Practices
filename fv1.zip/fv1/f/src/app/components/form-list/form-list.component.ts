import { Component } from '@angular/core';

@Component({
  selector: 'app-form-list',
  imports: [],
  templateUrl: './form-list.component.html',
  styleUrl: './form-list.component.css'
})
export class FormListComponent {

}
