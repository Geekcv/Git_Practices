﻿using EvenbooksUI.connect_db;
using EvenbooksUI.function;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace EvenbooksUI.Pages.Pricelist.Product
{
    /// <summary>
    /// Interaction logic for addProduct.xaml
    /// </summary>
    public partial class addProduct : Page
    {
        private string products = "eb" + ".products2";
        public int randomNumber;
        public addProduct()
        {
            InitializeComponent();

           
        }



        private void DataGridResult_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            Dictionary<string, string> columnDisplayNames = new Dictionary<string, string>
    {
        { "S.No", "S.No" },
        { "product_name", "Product Name" },
        { "product_code", "Product Code" },
        { "weight_kg", "Weight (Kg)" },
        { "weight_gm", "Weight (Gm)" },
        { "volume_liter", "Volume (L)" },
        { "volume_ml", "Volume (ML)" }

    };

            // Change column headers for better readability
            if (columnDisplayNames.ContainsKey(e.PropertyName))
            {
                e.Column.Header = columnDisplayNames[e.PropertyName];
            }

            // Ensure "S.No" appears first
            if (e.PropertyName == "S.No")
            {
                e.Column.DisplayIndex = 0; // Move to first position
            }

            // Hide "row_id" as it's internal
            if (e.PropertyName == "row_id")
            {
                e.Column.Visibility = Visibility.Collapsed;
            }
        }


        private void CmbUnitType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedUnit = (cmbUnitType.SelectedItem as ComboBoxItem)?.Content.ToString();

            // Hide all unit panels first
            kgPanel.Visibility = Visibility.Collapsed;
            gPanel.Visibility = Visibility.Collapsed;
            literPanel.Visibility = Visibility.Collapsed;
            mlPanel.Visibility = Visibility.Collapsed;

            if (selectedUnit == "kg" || selectedUnit == "g")
            {
                kgPanel.Visibility = Visibility.Visible;
                gPanel.Visibility = Visibility.Visible;
            }
            else if (selectedUnit == "L")
            {
                literPanel.Visibility = Visibility.Visible;
            }
            else if (selectedUnit == "mL")
            {
                mlPanel.Visibility = Visibility.Visible;
            }

        }




        private async void BtnShow_Click(object sender, RoutedEventArgs e)
        {
            string selectedFilter = ((ComboBoxItem)cmbFilter.SelectedItem).Content.ToString();
            Dictionary<string, object> conditions = new Dictionary<string, object>();

            if (selectedFilter == "Finalized")
                conditions.Add("is_draft", false);
            else if (selectedFilter == "Draft")
                conditions.Add("is_draft", true);

            List<Dictionary<string, object>> xmlResult = await queries.FetchData(products, conditions);
            DataTable dt = functions.ConvertToDataTable(xmlResult, new List<string> { "row_id", "product_name", "product_code", "weight_kg", "weight_gm", "volume_liter","volume_ml", "is_draft" });

            if (!dt.Columns.Contains("S.No"))
                dt.Columns.Add("S.No", typeof(int)).SetOrdinal(0);

            int serialNumber = 1;
            foreach (DataRow row in dt.Rows)
                row["S.No"] = serialNumber++;

            dataGridResult.ItemsSource = dt.DefaultView;
        }





        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            await SaveProduct(false);  // Save as finalized
        }

        private async void BtnSaveDraft_Click(object sender, RoutedEventArgs e)
        {
            await SaveProduct(true);  // Save as draft
        }

        private async Task SaveProduct(bool isDraft)
        {
            var row_id = functions.RandomId();
            string productName = txtProductName.Text;
            int productCode = Convert.ToInt32(txtProductCode.Text);
            double priceWithoutGst = Convert.ToDouble(txtPriceWithoutGst.Text);
            double priceWithGst = Convert.ToDouble(txtPriceWithGst.Text);
            string selectedUnit = (cmbUnitType.SelectedItem as ComboBoxItem)?.Content.ToString();

            double? weightKg = null, weightGm = null, volumeL = null, volumeMl = null;

            // Assign values based on unit type
            if (selectedUnit == "kg" || selectedUnit == "g")
            {
                weightKg = Convert.ToDouble(txtWeightKg.Text);
                weightGm = Convert.ToDouble(txtWeightGm.Text);
            }
            else if (selectedUnit == "g")
                weightGm = Convert.ToDouble(txtWeightGm.Text);
            else if (selectedUnit == "L")
                volumeL = Convert.ToDouble(txtVolumeL.Text);
            else if (selectedUnit == "mL")
                volumeMl = Convert.ToDouble(txtVolumeMl.Text);



            double gst_percentage = Convert.ToDouble(txtgst_percentage.Text);

            var columns = new Dictionary<string, object>
            {
                { "row_id", row_id },
                { "product_name", productName },
                { "product_code", productCode },
        { "unit_type", selectedUnit },
        { "weight_kg", weightKg },
        { "weight_gm", weightGm },
        { "volume_liter", volumeL },
        { "volume_ml", volumeMl },

                { "price_withoutgst", priceWithoutGst },
                { "price_withgst", priceWithGst },
                { "gst", gst_percentage },
                { "is_draft", isDraft }
            };

            var result = await queries.InsertData(products, columns);
            MessageBox.Show(result != null ? $"Product {productName} saved successfully!" : $"Failed to save {productName}.", "Status", MessageBoxButton.OK);
        }

        private void CmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            BtnShow_Click(null, null);
        }


        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (DataRowView)dataGridResult.SelectedItem;
            if (selectedProduct != null)
            {
                EditProductPage editProductPage = new EditProductPage(selectedProduct.Row);
                editProductPage.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a product to edit.");
            }
        }

        private async void Btndel_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = (DataRowView)dataGridResult.SelectedItem;
            if (selectedProduct != null)
            {
                var data = selectedProduct.Row;
                var productId = data["row_id"].ToString();


                var comm = new Dictionary<string, object>
                 {
                    { "row_id", productId },
                };

                // Create instance of DatabaseHelper
                var result = await queries.DeleteData(products, comm);

                if (result != null)
                {
                    MessageBox.Show("Data delete successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Failed to delete data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
            else
            {
                MessageBox.Show("Please select a product to edit.");
            }
        }

        // Clear form fields for new entry
        private void BtnAddNew_Click(object sender, RoutedEventArgs e)
        {
            txtProductName.Clear();
            txtProductCode.Clear();
            txtWeightKg.Clear();
            txtWeightGm.Clear();
            txtPriceWithoutGst.Clear();
            txtPriceWithGst.Clear();
            txtgst_percentage.Clear();
        }



        // current screen   show only grid table print

        //private void BtnPrint_Click(object sender, RoutedEventArgs e)
        //{
        //    PrintDialog printDialog = new PrintDialog();

        //    if (printDialog.ShowDialog() == true)
        //    {
        //        // Create a visual element snapshot of the current page
        //        printDialog.PrintVisual(this, "Print Page Content");
        //    }

        //}




























        //private void BtnPrint_Click(object sender, RoutedEventArgs e)
        //{
        //    PrintDialog printDialog = new PrintDialog();

        //    // Capture the current Grid or any UI Element
        //    FixedDocument fixedDoc = CreateFixedDocument(this);

        //    // Show the Print Preview Window
        //    PrintPreviewWindow previewWindow = new PrintPreviewWindow(fixedDoc);
        //    previewWindow.ShowDialog();

        //    // If the user confirms, proceed with printing
        //    if (printDialog.ShowDialog() == true)
        //    {
        //        printDialog.PrintDocument(fixedDoc.DocumentPaginator, "Printing Page Content");
        //    }
        //}

        //private FixedDocument CreateFixedDocument(UIElement element)
        //{
        //    FixedDocument fixedDoc = new FixedDocument();
        //    PageContent pageContent = new PageContent();
        //    FixedPage fixedPage = new FixedPage();

        //    // Set Page Size (A4 - 96 DPI conversion)
        //    fixedPage.Width = 816; // 8.5 inches * 96 dpi
        //    fixedPage.Height = 1056; // 11 inches * 96 dpi

        //    // Render element inside a Visual Brush
        //    VisualBrush visualBrush = new VisualBrush(element);
        //    Rectangle rect = new Rectangle
        //    {
        //        Width = fixedPage.Width,
        //        Height = fixedPage.Height,
        //        Fill = visualBrush
        //    };

        //    fixedPage.Children.Add(rect);
        //    ((IAddChild)pageContent).AddChild(fixedPage);
        //    fixedDoc.Pages.Add(pageContent);

        //    return fixedDoc;
        //}



        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            //PrintDialog printDialog = new PrintDialog();

            //// Show the Print Preview Window
            //PrintPreviewWindow previewWindow = new PrintPreviewWindow(this);
            //previewWindow.ShowDialog();

            //// If the user confirms, proceed with printing
            //if (printDialog.ShowDialog() == true)
            //{
            //    FixedDocument doc = previewWindow.GetFixedDocument();
            //    if (doc != null)
            //    {
            //        printDialog.PrintDocument(doc.DocumentPaginator, "Printing Page Content");
            //    }
            //}

            PrintPreviewWindow previewWindow = new PrintPreviewWindow(this);
            previewWindow.ShowDialog();

        }







        //private void BtnPrint_Click(object sender, RoutedEventArgs e)
        //{
        //    PrintDialog printDialog = new PrintDialog();

        //    // Create the document for preview
        //    FixedDocument fixedDoc = CreateFixedDocument(this);

        //    // Show the Print Preview Window
        //    PrintPreviewWindow previewWindow = new PrintPreviewWindow(fixedDoc);
        //    previewWindow.ShowDialog();

        //    // Proceed with printing if the user confirms
        //    if (printDialog.ShowDialog() == true)
        //    {
        //        printDialog.PrintDocument(fixedDoc.DocumentPaginator, "Printing Receipt");
        //    }
        //}


        //private FixedDocument CreateFixedDocument(UIElement element)
        //{
        //    FixedDocument fixedDoc = new FixedDocument();
        //    PageContent pageContent = new PageContent();
        //    FixedPage fixedPage = new FixedPage();

        //    // Set thermal printer width (e.g., 58mm paper roll)
        //    fixedPage.Width = WidthInInchesToDPI(2.28); // 58mm
        //    fixedPage.Height = Math.Max(HeightInInchesToDPI(10), element.RenderSize.Height);

        //    // Use a canvas to avoid unwanted scaling
        //    Canvas canvas = new Canvas
        //    {
        //        Width = fixedPage.Width,
        //        Height = fixedPage.Height
        //    };

        //    // Capture UI element inside VisualBrush
        //    VisualBrush visualBrush = new VisualBrush(element)
        //    {
        //        Stretch = Stretch.Uniform // Prevent distortion
        //    };

        //    Rectangle rect = new Rectangle
        //    {
        //        Width = fixedPage.Width,
        //        Height = fixedPage.Height,
        //        Fill = visualBrush
        //    };

        //    // Apply text rendering improvements
        //    TextOptions.SetTextRenderingMode(rect, TextRenderingMode.ClearType);
        //    TextOptions.SetTextFormattingMode(rect, TextFormattingMode.Display);

        //    // Add content to canvas and page
        //    canvas.Children.Add(rect);
        //    fixedPage.Children.Add(canvas);

        //    ((IAddChild)pageContent).AddChild(fixedPage);
        //    fixedDoc.Pages.Add(pageContent);

        //    return fixedDoc;
        //}

        //// Convert inches to DPI (for printer compatibility)
        //private double WidthInInchesToDPI(double inches) => inches * 96;
        //private double HeightInInchesToDPI(double inches) => inches * 96;


























        //  show only grid table print


        //private void BtnPrint_Click(object sender, RoutedEventArgs e)
        //{
        //    PrintDialog printDialog = new PrintDialog();

        //    // Generate FixedDocument for DataGrid
        //    FixedDocument fixedDoc = CreateFixedDocument(dataGridResult);

        //    // Show Print Preview Window
        //    PrintPreviewWindow previewWindow = new PrintPreviewWindow(fixedDoc);
        //    previewWindow.ShowDialog();

        //    // If user confirms, print the DataGrid
        //    if (printDialog.ShowDialog() == true)
        //    {
        //        printDialog.PrintDocument(fixedDoc.DocumentPaginator, "Printing Grid Data");
        //    }
        //}

        //private FixedDocument CreateFixedDocument(DataGrid dataGrid)
        //{
        //    FixedDocument fixedDoc = new FixedDocument();
        //    PageContent pageContent = new PageContent();
        //    FixedPage fixedPage = new FixedPage();

        //    // Set Page Size (A4 - 96 DPI conversion)
        //    fixedPage.Width = 816; // 8.5 inches * 96 dpi
        //    fixedPage.Height = 1056; // 11 inches * 96 dpi

        //    // Create a new DataGrid for printing (avoiding UI interference)
        //    DataGrid printGrid = new DataGrid
        //    {
        //        ItemsSource = dataGrid.ItemsSource, // Copy Data Source
        //        Width = fixedPage.Width - 40,
        //        Height = fixedPage.Height - 40,
        //        CanUserAddRows = false,
        //        CanUserDeleteRows = false,
        //        IsReadOnly = true
        //    };

        //    // Render the DataGrid in a VisualBrush
        //    VisualBrush visualBrush = new VisualBrush(printGrid);
        //    Rectangle rect = new Rectangle
        //    {
        //        Width = fixedPage.Width,
        //        Height = fixedPage.Height,
        //        Fill = visualBrush
        //    };

        //    fixedPage.Children.Add(rect);
        //    ((IAddChild)pageContent).AddChild(fixedPage);
        //    fixedDoc.Pages.Add(pageContent);

        //    return fixedDoc;
        //}





        // customzation print show only grid table

        //private void BtnPrint_Click(object sender, RoutedEventArgs e)
        //{
        //    PrintDialog printDialog = new PrintDialog();

        //    // Generate FixedDocument for DataGrid
        //    FixedDocument fixedDoc = CreateFixedDocument(dataGridResult);

        //    // Show Print Preview Window
        //    PrintPreviewWindow previewWindow = new PrintPreviewWindow(fixedDoc);
        //    previewWindow.ShowDialog();

        //    // If user confirms, print the DataGrid
        //    if (printDialog.ShowDialog() == true)
        //    {
        //        printDialog.PrintDocument(fixedDoc.DocumentPaginator, "Printing Grid Data");
        //    }
        //}



        //private FixedDocument CreateFixedDocument(DataGrid dataGrid)
        //{
        //    FixedDocument fixedDoc = new FixedDocument();
        //    PageContent pageContent = new PageContent();
        //    FixedPage fixedPage = new FixedPage();

        //    // Set Page Size (A4 - 96 DPI conversion)
        //    fixedPage.Width = 816; // 8.5 inches * 96 dpi
        //    fixedPage.Height = 1056; // 11 inches * 96 dpi

        //    // Add Company Logo (Ensure logo is in the project folder and set to "Resource")
        //    Image logo = new Image
        //    {
        //        Source = new BitmapImage(new Uri("E:\\Dot-net\\evenbooks_desktop\\evenbooks_desktop\\EvenbooksUI\\assets\\icons\\BarcodeGenrater.png")),
        //        Width = 150,
        //        Height = 50,
        //        Margin = new Thickness(20, 10, 0, 10)
        //    };
        //    fixedPage.Children.Add(logo);

        //    // Add Company Name
        //    TextBlock companyName = new TextBlock
        //    {
        //        Text = "EvenBooks Solutions Pvt. Ltd.",
        //        FontSize = 18,
        //        FontWeight = FontWeights.Bold,
        //        Margin = new Thickness(200, 20, 0, 10)
        //    };
        //    fixedPage.Children.Add(companyName);

        //    // Add Date
        //    TextBlock dateText = new TextBlock
        //    {
        //        Text = $"Date: {DateTime.Now:dd-MMM-yyyy}",
        //        FontSize = 14,
        //        FontWeight = FontWeights.Normal,
        //        Margin = new Thickness(650, 20, 0, 10)
        //    };
        //    fixedPage.Children.Add(dateText);

        //    // Create a new DataGrid for printing
        //    DataGrid printGrid = new DataGrid
        //    {
        //        ItemsSource = dataGrid.ItemsSource,
        //        Width = fixedPage.Width - 40,
        //        Height = fixedPage.Height - 200, // Adjust height to fit header & footer
        //        CanUserAddRows = false,
        //        CanUserDeleteRows = false,
        //        IsReadOnly = true,
        //        Margin = new Thickness(20, 100, 20, 10)
        //    };

        //    // Render DataGrid in a VisualBrush
        //    VisualBrush visualBrush = new VisualBrush(printGrid);
        //    Rectangle rect = new Rectangle
        //    {
        //        Width = fixedPage.Width - 40,
        //        Height = fixedPage.Height - 200,
        //        Fill = visualBrush,
        //        Margin = new Thickness(20, 100, 0, 0)
        //    };

        //    fixedPage.Children.Add(rect);

        //    // Add Footer Text
        //    TextBlock footerText = new TextBlock
        //    {
        //        Text = "This is a system-generated document. No signature required.",
        //        FontSize = 12,
        //        FontStyle = FontStyles.Italic,
        //        HorizontalAlignment = HorizontalAlignment.Center,
        //        Margin = new Thickness(20, fixedPage.Height - 50, 0, 0)
        //    };
        //    fixedPage.Children.Add(footerText);

        //    ((IAddChild)pageContent).AddChild(fixedPage);
        //    fixedDoc.Pages.Add(pageContent);

        //    return fixedDoc;
        //}





        //private void dataGridResult_Sorting(object sender, DataGridSortingEventArgs e)
        //{
        //    try
        //    {
        //        // Prevent error when clicking column header without data
        //        if (dataGridResult.Items.Count == 0)
        //        {
        //            MessageBox.Show("No data available to sort.", "Sorting Error", MessageBoxButton.OK, MessageBoxImage.Warning);
        //            e.Handled = true; // Stop default sorting
        //            return;
        //        }

        //        // Custom sorting logic (optional)
        //        // e.Column.SortDirection = (e.Column.SortDirection != ListSortDirection.Ascending)
        //        //     ? ListSortDirection.Ascending : ListSortDirection.Descending;

        //        // Let WPF handle sorting
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show($"An error occurred while sorting:\n{ex.Message}", "Sorting Error", MessageBoxButton.OK, MessageBoxImage.Error);
        //        e.Handled = true; // Prevent WPF from proceeding with sorting if error occurs
        //    }
        //}





    }
}
