﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EvenbooksUI
{
    /// <summary>
    /// Interaction logic for PrintPreviewWindow.xaml
    /// </summary>
    public partial class PrintPreviewWindow : Window
    {
        private UIElement _elementToPrint;
        private FixedDocument _fixedDocument;

        public PrintPreviewWindow(UIElement element)
        {
            InitializeComponent(); // Ensure UI elements are initialized before calling LoadPreview()
            _elementToPrint = element;

            // Defer the LoadPreview call until the Window is loaded
            this.Loaded += (s, e) => LoadPreview("A4");
        }

        private void LoadPreview(string pageSize)
        {
            if (DocumentViewerControl == null)
            {
                MessageBox.Show("Error: Document Viewer is not initialized.");
                return;
            }

            Size selectedSize = GetPageSize(pageSize);
            _fixedDocument = CreateFixedDocument(_elementToPrint, selectedSize);
            DocumentViewerControl.Document = _fixedDocument; // Prevent null reference error
        }

        private void PageSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PageSizeComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                LoadPreview(selectedItem.Content.ToString());
            }
        }

        private void RefreshPreview_Click(object sender, RoutedEventArgs e)
        {
            if (PageSizeComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                LoadPreview(selectedItem.Content.ToString());
            }
        }

        private FixedDocument CreateFixedDocument(UIElement element, Size pageSize)
        {
            FixedDocument fixedDoc = new FixedDocument();
            PageContent pageContent = new PageContent();
            FixedPage fixedPage = new FixedPage
            {
                Width = pageSize.Width,
                Height = pageSize.Height
            };

            // Capture UIElement as an Image
            RenderTargetBitmap renderBitmap = new RenderTargetBitmap((int)pageSize.Width, (int)pageSize.Height, 96, 96, PixelFormats.Pbgra32);
            element.Measure(new Size(pageSize.Width, pageSize.Height));
            element.Arrange(new Rect(new Size(pageSize.Width, pageSize.Height)));
            renderBitmap.Render(element);

            // Create Image control to hold the captured content
            Image image = new Image
            {
                Source = renderBitmap,
                Width = pageSize.Width,
                Height = pageSize.Height
            };

            fixedPage.Children.Add(image);
            ((IAddChild)pageContent).AddChild(fixedPage);
            fixedDoc.Pages.Add(pageContent);

            return fixedDoc;
        }


        private Size GetPageSize(string pageSize)
        {
            return pageSize.ToUpper() switch
            {
                "A4" => new Size(816, 1056), // 8.27 x 11.69 inches at 96 DPI
                "A5" => new Size(583, 827),  // 5.83 x 8.27 inches at 96 DPI
                "A6" => new Size(413, 583),  // 4.13 x 5.83 inches at 96 DPI
                _ => new Size(816, 1056)     // Default to A4
            };
        }

        public FixedDocument GetFixedDocument()
        {
            return _fixedDocument;
        }
    }

}
