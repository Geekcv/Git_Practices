﻿using System.Data;

namespace EvenbooksUI.function
{
    public class functions
    {
        public static string RandomId()
        {
            string randomTxt = "";
            string possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            Random random = new Random();
            for (int i = 0; i < 4; i++)
            {
                randomTxt += possible[random.Next(possible.Length)];
            }
            return GetTimeStamp() + "_" + randomTxt;
        }

        private static string GetTimeStamp()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmss");
        }




        public static DataTable ConvertToDataTable(List<Dictionary<string, object>> data, List<string> specificColumns = null)
        {
            DataTable table = new DataTable();

            // Return an empty table if there is no data
            if (data == null || data.Count == 0)
                return table;

            // Determine which columns to add
            var columnsToAdd = specificColumns ?? data[0].Keys.ToList(); // Use specificColumns if provided, otherwise use all keys

            // Add columns to the DataTable
            foreach (var key in columnsToAdd)
            {
                // Add a column with type inferred from the first row's value if possible
                Type columnType = typeof(string); // Default type

                // Check the first row to determine the correct type
                if (data[0].ContainsKey(key) && data[0][key] != null)
                {
                    columnType = data[0][key].GetType();
                }

                table.Columns.Add(key, columnType);
            }

            // Add rows to the DataTable
            foreach (var dict in data)
            {
                DataRow row = table.NewRow();
                foreach (var key in columnsToAdd)
                {
                    if (dict.ContainsKey(key))
                    {
                        // Assign the value or DBNull if the value is null
                        row[key] = dict[key] ?? DBNull.Value;
                    }
                    else
                    {
                        row[key] = DBNull.Value; // Handle missing keys
                    }
                }
                table.Rows.Add(row);
            }

            return table;
        }

    }
}
