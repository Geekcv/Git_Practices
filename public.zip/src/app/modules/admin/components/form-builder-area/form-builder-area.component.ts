import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TextBoxComponent } from '../properties/text-box/text-box.component';
import { ButtonComponent } from '../properties/button/button.component';
import { LabelComponent } from '../properties/label/label.component';
import { TextAreaComponent } from '../properties/text-area/text-area.component';
import { NumberInputComponent } from '../properties/number-input/number-input.component';
import { DropdownComponent } from '../properties/dropdown/dropdown.component';
import { RadioButtonComponent } from '../properties/radio-button/radio-button.component';
import { fakeAsync } from '@angular/core/testing';
import { CheckboxComponent } from '../properties/checkbox/checkbox.component';
import { escape } from 'lodash';
import { DateComponent } from '../properties/date/date.component';
import { SingleCheckboxComponent } from '../properties/single-checkbox/single-checkbox.component';
import { EmailFieldComponent } from '../properties/email-field/email-field.component';
import { PasswordInputComponent } from '../properties/password-input/password-input.component';
import { TimePickerComponent } from '../properties/time-picker/time-picker.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FileUploadComponent } from '../properties/file-upload/file-upload.component';
import { MobileNumberComponent } from '../properties/mobile-number/mobile-number.component';
import { AddressComponent } from '../properties/address/address.component';
import { SearchableDropdownComponent } from '../properties/searchable-dropdown/searchable-dropdown.component';
import { MultiSelectDropdownComponent } from '../properties/multi-select-dropdown/multi-select-dropdown.component';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  accept?:any
}

@Component({
  selector: 'app-form-builder-area',
  imports: [
    DragDropModule, NgFor, CommonModule, FormsModule,NgIf,
    MatFormFieldModule,MatSelectModule,MatInputModule,MatCheckboxModule,FormsModule,
    TextBoxComponent,
    ButtonComponent,
    LabelComponent,
    NumberInputComponent,
    TextAreaComponent,
    DropdownComponent,
    RadioButtonComponent,
    CheckboxComponent,
    DateComponent,
    SingleCheckboxComponent,
    EmailFieldComponent, // Add EmailFieldComponent
    PasswordInputComponent, // Add PasswordInputComponent  
    TimePickerComponent,  // Add TimePickerComponent
    FileUploadComponent,
    MobileNumberComponent,
    AddressComponent,
    SearchableDropdownComponent,
    MultiSelectDropdownComponent
  ],
  templateUrl: './form-builder-area.component.html',
  styleUrl: './form-builder-area.component.scss'
})
export class FormBuilderAreaComponent {
  @Input() formItems: FormElement[];

 




  istextclicked = false;
  isbtn = false;
  islabel = false;
  isTextarea = false
  isNumberInput = false
  isDropdown = false
  isRadio = false;
  ischeckbox = false;
  isSingleCheckbox = false

  isEmail = false;
  isPasswordInput = false; // Add flag for password input
  isDatePicker = false; // Add flag for date picker
  isTimePicker = false; // Add flag for time picker
  isFile = false
  isTelphone = false
  isAddress= false
  issearchableDropdown = false
  isMultiSelectDropdown = false



  selectedElementIndex: number | null = null;


  /**
   * Select an element for editing.
   */
  // selectElement(index: number) {
  //   this.selectedElementIndex = index;
  //   const selectedElement = this.formItems[index];

  //   console.log("elements ",selectedElement)

  //   const selectedElementtype = this.formItems[index].type;
  //   console.log("type-", this.formItems[index].type)

  //   if (selectedElementtype === 'text') {
  //     this.istextclicked = true
  //     this.isbtn = false
  //     this.isTextarea = false
  //     this.islabel = false
  //     this.isNumberInput = false
  //     this.isDropdown = false
  //     this.isRadio = false;
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false


      



  //   } else if (selectedElementtype === 'button') {
  //     this.isbtn = true
  //     this.istextclicked = false
  //     this.islabel = false
  //     this.isTextarea = false
  //     this.isNumberInput = false
  //     this.isDropdown = false
  //     this.isRadio = false;
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false






  //   } else if (selectedElementtype === 'label') {
  //     this.islabel = true
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.isTextarea = false
  //     this.isNumberInput = false
  //     this.isDropdown = false
  //     this.isRadio = false;
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false






  //   } else if (selectedElementtype === 'textarea') {
  //     this.isTextarea = true
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //     this.isNumberInput = false
  //     this.isDropdown = false
  //     this.isRadio = false;
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false





  //   } else if (selectedElementtype === 'number') {
  //     this.isNumberInput = true
  //     this.isTextarea = false
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //     this.isDropdown = false
  //     this.isRadio = false;
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false





  //   } else if (selectedElementtype === 'dropdown') {
  //     this.isDropdown = true
  //     this.isNumberInput = false
  //     this.isTextarea = false
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //     this.isRadio = false;
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false





  //   } else if (selectedElementtype === 'radio') {
  //     this.isRadio = true;
  //     this.isDropdown = false
  //     this.isNumberInput = false
  //     this.isTextarea = false
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //     this.ischeckbox = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false



  //   } else if (selectedElementtype === 'checkbox-group') {
  //     this.ischeckbox = true
  //     this.isRadio = false;
  //     this.isDropdown = false
  //     this.isNumberInput = false
  //     this.isTextarea = false
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //     this.isDate = false
  //     this.isSingleCheckbox = false



  //   } else if (selectedElementtype === 'date'){
  //     this.isDate = true
  //     this.ischeckbox = false
  //     this.isRadio = false;
  //     this.isDropdown = false
  //     this.isNumberInput = false
  //     this.isTextarea = false
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //     this.isSingleCheckbox = false
  //   } else if(selectedElementtype === 'checkbox'){
  //     this.isSingleCheckbox = true
  //     this.isDate = false
  //     this.ischeckbox = false
  //     this.isRadio = false;
  //     this.isDropdown = false
  //     this.isNumberInput = false
  //     this.isTextarea = false
  //     this.istextclicked = false
  //     this.isbtn = false
  //     this.islabel = false
  //   }


  // }


  selectElement(index: number) {
    this.selectedElementIndex = index;
    const selectedElement = this.formItems[index];
    const selectedElementtype = selectedElement.type;

    console.log("elements ", selectedElement);
    console.log("type-", selectedElementtype);

    // Reset all flags first
    this.istextclicked = false;
    this.isbtn = false;
    this.islabel = false;
    this.isTextarea = false;
    this.isNumberInput = false;
    this.isDropdown = false;
    this.isRadio = false;
    this.ischeckbox = false;
    this.isEmail = false;
    this.isPasswordInput = false;
    this.isDatePicker = false;
    this.isTimePicker = false;
    this.isSingleCheckbox = false
    this.isFile = false
    this.isTelphone = false
    this.isAddress = false
    this.issearchableDropdown = false
    this.isMultiSelectDropdown = false

    // Set the correct flag based on the type
    if (selectedElementtype === 'text') {
      this.istextclicked = true;
    } else if (selectedElementtype === 'submit') {
      this.isbtn = true;
    } else if (selectedElementtype === 'label') {
      this.islabel = true;
    } else if (selectedElementtype === 'textarea') {
      this.isTextarea = true;
    } else if (selectedElementtype === 'number') {
      this.isNumberInput = true;
    } else if (selectedElementtype === 'dropdown') {
      this.isDropdown = true;
    } else if (selectedElementtype === 'radio') {
      this.isRadio = true;
    } else if (selectedElementtype === 'checkbox-group') {
      this.ischeckbox = true;
    } else if (selectedElementtype === 'checkbox'){
      this.isSingleCheckbox = true;
    } else if (selectedElementtype === 'email') {
      this.isEmail = true;
    } else if (selectedElementtype === 'password') { // Correctly set password flag
      this.isPasswordInput = true;
    } else if (selectedElementtype === 'date') { // Correctly set date flag
      this.isDatePicker = true;
    } else if (selectedElementtype === 'time') { // Correctly set time flag
      this.isTimePicker = true;
    } else if (selectedElementtype === 'file'){
      this.isFile = true
    }else if (selectedElementtype === 'tel'){
      this.isTelphone = true
    } else if (selectedElementtype === 'address'){
       this.isAddress = true
    } else if (selectedElementtype === 'searchable-dropdown'){
      this.issearchableDropdown = true
    }else if (selectedElementtype === 'multiSelect-dropdown'){
      this.isMultiSelectDropdown = true
    } else {
      // Optional: Handle unknown types or deselect
      console.warn(`Unknown element type selected: ${selectedElementtype}`);
      this.selectedElementIndex = null;
    }
  }

  formData: any = {};

  searchText :string;


   // Search logic
   filterNativeDropdown(item: any) {
    console.log("serching inside dropdown ",item)
    const search = item.searchText?.toLowerCase() || '';
    console.log("search",search)
    item.filteredOptions = item.options.filter((opt: any) =>
      opt.label.toLowerCase().includes(search)
    );
  }


   // Search logic for multi select dropdown 
filterNativeCheckboxOptions(item: any) {
  const search = item.searchText?.toLowerCase() || '';
  item.filteredOptions = item.options.filter((opt: any) =>
    opt.label.toLowerCase().includes(search)
  );
}

// Handle checkbox change for multi select dropdown 
onCheckboxChange(item: any, value: string, event: any) {
  if (!this.formData[item.label]) {
    this.formData[item.label] = [];
  }

  if (event.target.checked) {
    this.formData[item.label].push(value);
  } else {
    this.formData[item.label] = this.formData[item.label].filter(
      (v: string) => v !== value
    );
  }
}

  /**
   * Remove an element from the form.
   */
  removeElement(index: number) {
    this.formItems.splice(index, 1);
    if (this.selectedElementIndex === index) {
      this.selectedElementIndex = null;
       // Reset all flags when element is removed
       this.istextclicked = false;
       this.isbtn = false;
       this.islabel = false;
       this.isTextarea = false;
       this.isNumberInput = false;
       this.isDropdown = false;
       this.isRadio = false;
       this.ischeckbox = false;
       this.isEmail = false;
       this.isPasswordInput = false;
       this.isDatePicker = false;
       this.isTimePicker = false;
       this.issearchableDropdown = false;
    } else if (this.selectedElementIndex !== null && this.selectedElementIndex > index) {
        // Adjust selected index if an element before it was removed
        this.selectedElementIndex--;
    }
  }

}
