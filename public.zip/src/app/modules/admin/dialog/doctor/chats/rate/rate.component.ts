import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-rate',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './rate.component.html',
  styleUrl: './rate.component.scss'
})
export class RateComponent {

  constructor(
        @Inject(MAT_DIALOG_DATA) public data: {patient: string},
            private dialogRef: MatDialogRef<RateComponent> // Inject MatDialogRef
        
    ){
  
    }
  
    exitbtn(){
  
      this.dialogRef.close();
  
    }

}
