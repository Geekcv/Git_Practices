import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../../config';

@Component({
  selector: 'app-formulation',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './formulation.component.html',
  styleUrl: './formulation.component.scss'
})
export class FormulationComponent {
  
      config: string = config.apiBaseURL;
  
 constructor(
      @Inject(MAT_DIALOG_DATA) public data: {media_link: string},
          private dialogRef: MatDialogRef<FormulationComponent> // Inject MatDialogRef
      
  ){

  }

  exitbtn(){

    this.dialogRef.close();

  }
}
