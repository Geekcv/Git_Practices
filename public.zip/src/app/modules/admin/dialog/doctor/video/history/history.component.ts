import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../../config';

@Component({
  selector: 'app-history',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './history.component.html',
  styleUrl: './history.component.scss'
})
export class HistoryComponent {

    config: string = config.apiBaseURL;
  
  
  constructor(
        @Inject(MAT_DIALOG_DATA) public data: {media_link: string},
            private dialogRef: MatDialogRef<HistoryComponent> // Inject MatDialogRef           
        
    ){
  
    }
  
    exitbtn(){
  
      this.dialogRef.close();
  
    }
}
