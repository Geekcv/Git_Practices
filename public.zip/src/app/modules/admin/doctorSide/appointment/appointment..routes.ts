import { Routes } from '@angular/router';
import { AppointmentComponent } from 'app/modules/admin/doctorSide/appointment/appointment.component';

export default [
    {
        path: '',
        component: AppointmentComponent,
    },
] as Routes;
