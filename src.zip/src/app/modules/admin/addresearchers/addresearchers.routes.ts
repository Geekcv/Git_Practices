import { Routes } from '@angular/router';
import { AddresearchersComponent } from 'app/modules/admin/addresearchers/addresearchers.component';

export default [
    {
        path: '',
        component: AddresearchersComponent,
    },
] as Routes;
