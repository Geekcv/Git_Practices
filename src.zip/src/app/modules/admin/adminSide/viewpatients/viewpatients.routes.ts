import { Routes } from '@angular/router';
import { ViewpatientsComponent } from 'app/modules/admin/adminSide/viewpatients/viewpatients.component';

export default [
    {
        path     : '',
        component: ViewpatientsComponent,
    },
] as Routes;
