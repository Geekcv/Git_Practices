import { Routes } from '@angular/router';
import { ViewresearchersComponent } from 'app/modules/admin/adminSide/viewresearchers/viewresearchers.component';


export default [
    {
        path: '',
        component: ViewresearchersComponent,
    },
] as Routes;
