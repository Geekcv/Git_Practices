import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-formulation',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './formulation.component.html',
  styleUrl: './formulation.component.scss'
})
export class FormulationComponent {
 constructor(
      @Inject(MAT_DIALOG_DATA) public data: {patient: string},
          private dialogRef: MatDialogRef<FormulationComponent> // Inject MatDialogRef
      
  ){

  }

  exitbtn(){

    this.dialogRef.close();

  }
}
