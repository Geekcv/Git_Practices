import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAudionotesComponent } from './view-audionotes.component';

describe('ViewAudionotesComponent', () => {
  let component: ViewAudionotesComponent;
  let fixture: ComponentFixture<ViewAudionotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewAudionotesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewAudionotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
