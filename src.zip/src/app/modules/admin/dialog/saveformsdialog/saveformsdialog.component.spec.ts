import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveformsdialogComponent } from './saveformsdialog.component';

describe('SaveformsdialogComponent', () => {
  let component: SaveformsdialogComponent;
  let fixture: ComponentFixture<SaveformsdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SaveformsdialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaveformsdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
