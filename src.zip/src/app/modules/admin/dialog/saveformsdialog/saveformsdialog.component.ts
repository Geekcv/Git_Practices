import { Component, inject, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
  selector: 'app-saveformsdialog',
  imports: [MatDialogModule,
    MatButtonModule, MatFormFieldModule, FormsModule,
        ReactiveFormsModule, MatInputModule, MatSelectModule,
        MatIconModule
  ],  templateUrl: './saveformsdialog.component.html',
  styleUrl: './saveformsdialog.component.scss'
})
export class SaveformsdialogComponent {
  formsname_value:any;

  saveforms(){

  }

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: {patient: string},
        private dialogRef: MatDialogRef<SaveformsdialogComponent> // Inject MatDialogRef
    
){

}
}
