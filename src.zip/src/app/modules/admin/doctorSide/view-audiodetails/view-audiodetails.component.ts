import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-audiodetails',
  imports: [
     MatButtonModule,
        MatIconModule,
       CommonModule,
  ],
  templateUrl: './view-audiodetails.component.html'
})
export class ViewAudiodetailsComponent {


    constructor(
      private router: Router,
    ) {
      
    }

  goback(){
    // console.log("click this button")
    this.router.navigate(['/audionotestable'])
  }

  

}
