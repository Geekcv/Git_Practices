import { Routes } from '@angular/router';
import { ViewAudiodetailsComponent } from 'app/modules/admin/doctorSide/view-audiodetails/view-audiodetails.component';

export default [
    {
        path: '',
        component: ViewAudiodetailsComponent,
    },
] as Routes;
