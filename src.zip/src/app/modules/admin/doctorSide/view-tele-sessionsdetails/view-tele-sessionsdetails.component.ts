import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-tele-sessionsdetails',
  imports: [
    MatButtonModule,
    MatIconModule,
   CommonModule,
  ],
  templateUrl: './view-tele-sessionsdetails.component.html'
})
export class ViewTeleSessionsdetailsComponent {


  constructor(
         private router: Router,
       ) {
         
       }
 
   goback(){
     // console.log("click this button")
     this.router.navigate(['/telesessionstable'])
   }
}
