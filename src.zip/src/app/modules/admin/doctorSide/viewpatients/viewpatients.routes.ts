import { Routes } from '@angular/router';
import { ViewpatientsComponent } from 'app/modules/admin/doctorSide/viewpatients/viewpatients.component';

export default [
    {
        path     : '',
        component: ViewpatientsComponent,
    },
] as Routes;
