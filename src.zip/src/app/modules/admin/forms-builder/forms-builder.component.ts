import { Component, inject } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FormsModule } from '@angular/forms';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormPreviewComponent } from '../components/form-preview/form-preview.component';
import { FormBuilderAreaComponent } from '../components/form-builder-area/form-builder-area.component';
import { MatDialog } from '@angular/material/dialog';
import { RateComponent } from '../dialog/doctor/chats/rate/rate.component';
import { SaveformsdialogComponent } from '../dialog/saveformsdialog/saveformsdialog.component';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}

interface FormsSchemaData {
  form_link: any;
}

@Component({
  selector: 'app-forms-builder',
  imports: [NgFor,
    DragDropModule,
    CommonModule,
    FormsModule,
    MatInputModule,
    MatIconModule,
    // FormPreviewComponent,
    FormBuilderAreaComponent

  ],
  templateUrl: './forms-builder.component.html',
  styleUrl: './forms-builder.component.scss'
})
export class FormsBuilderComponent {

  private _snackBar = inject(MatSnackBar);

  availableElements: FormElement[] = [
    { type: 'text', key: 'textField', label: 'Text Field', placeholder: 'Enter text' },
    { type: 'submit', key: 'submitButton', label: 'Button' },
    { type: 'label', key: 'staticLabel', label: 'label' },
    { type: 'textarea', key: 'description', label: 'Textarea', placeholder: 'Enter description', rows: '5', cols: '10' },
    { type: 'number', key: 'numberInput', label: 'Number Input', min: 0, max: 11 },
  
    {
      type: 'dropdown',
      key: 'dropdownField',
      label: 'Dropdown',
      optionsdropdown: [
        { label: 'Option 1', value: 'option1' },
        { label: 'Option 2', value: 'option2' }
      ],
      searchText: '',
      filteredOptions: []
    },
  
    {
      type: 'radio',
      key: 'radioGroup',
      label: 'Radio Button Group',
      optionsradio: [
        { label: 'Option 1', value: 'option1' },
        { label: 'Option 2', value: 'option2' }
      ],
      layout: 'vertical'
    },
  
    {
      type: 'checkbox-group',
      key: 'checkboxGroup',
      label: 'checkbox-group',
      optionscheckbox: [
        { label: 'Option 1', value: 'option1' },
        { label: 'Option 2', value: 'option2' }
      ]
    },
  
    {
      type: 'checkbox',
      key: 'agreeTerms',
      label: 'I agree to the terms'
    },
  
    {
      type: 'password',
      key: 'password',
      label: 'Password Field',
      placeholder: 'Enter password',
      required: false
    },
  
    {
      type: 'time',
      key: 'timePicker',
      label: 'Time Picker',
      required: false
    },
  
    {
      type: 'email',
      key: 'emailField',
      label: 'Email Field',
      placeholder: 'Enter your email address',
      required: false
    },
  
    {
      type: 'date',
      key: 'pickDate',
      label: 'Pick date',
      min: '',
      max: ''
    },
  
    {
      type: 'file',
      key: 'uploadFile',
      label: 'Upload File',
      accept: 'image/jpeg'
    },
  
    {
      type: 'tel',
      key: 'phoneNumber',
      label: 'Phone number',
      placeholder: 'enter phone number'
    },
  
    {
      type: 'address',
      key: 'address',
      label: 'Address',
      address: [
        { type: 'text', key: 'addressLine1', label: 'Address Line 1', placeholder: 'Enter address 1' },
        { type: 'text', key: 'addressLine2', label: 'Address Line 2', placeholder: 'Enter address 2' },
        { type: 'text', key: 'city', label: 'City', placeholder: 'City' },
        { type: 'text', key: 'state', label: 'State', placeholder: 'State' },
        { type: 'text', key: 'zipCode', label: 'Zip Code', placeholder: 'Zip Code' },
        { type: 'text', key: 'country', label: 'Country', placeholder: 'Country' }
      ]
    }
  ];

  

  ratedialogboxbtn(){

  }
  
   



  // Dropped elements in the form builder
  formItems: FormElement[] = [];

  // Index of selected element for editing
  selectedElementIndex: number | null = null;

  selectedElementtype: any;

  formslinks: FormsSchemaData[];

  formLinkInput: string;

  // Dynamic styles for selected element
  cols: any = 30
  rows: any = 30
  min: any = 0
  max: any = 10

  constructor(
          private _matDialog: MatDialog,
          private Apicontroller: ApicontrollerService,
  ) {

  }




  /**
  * Handles the drag & drop event.
  */
  onDrop(event: CdkDragDrop<FormElement[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(this.formItems, event.previousIndex, event.currentIndex);
    } else {
      // Clone the dragged item so the original remains in the available list
      const clonedItem = { ...event.previousContainer.data[event.previousIndex] };
      this.formItems.splice(event.currentIndex, 0, clonedItem);
    }
  }




row_id:any ="hello "

  /**
   * Save the form (send data to backend).
   */
  async saveForm() {

    // const dialogRef = this._matDialog.open(SaveformsdialogComponent,{data: {patient:  this.row_id}});

    console.log('Saved Form:', this.formItems);
    // alert('Form saved successfully!');

    const resp = await this.Apicontroller.createForms(this.formItems);
    this.formLinkInput = resp.formLink
    console.log("resp", resp)

    this._snackBar.open(resp.msg, '', {
      duration: 3000, // Duration in milliseconds (3 seconds)
      verticalPosition: 'top', // Position: 'top' | 'bottom'
      horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
    });


  }

  /**
     * load forms (backend side).
     */

  async loadForm() {

    const resp = await this.Apicontroller.loadallForms();




    this.formslinks = resp as FormsSchemaData[]; // Type assert to Doctor[]
    console.log("resp---", resp)
    console.log("formslinks ---", this.formslinks)

  }


  /**
   * new design window
   */

  newForm() {
    this.formItems = [];
  }



  async showforms(link: any) {
    console.log("link", link)

    const resp = await this.Apicontroller.loadForms(link);
    console.log("resp", resp[0].form_data)
    this.formItems = resp[0].form_data;
  }


}
