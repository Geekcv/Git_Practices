import { Component, inject, Pipe, PipeTransform } from '@angular/core'; // Added Pipe, PipeTransform
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FormsModule } from '@angular/forms';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { ApicontrollerService } from 'app/controller/apicontroller.service'; // Assuming this service path is correct
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser'; // Added DomSanitizer, SafeHtml

// Define the SafeHtmlPipe directly here for simplicity or create a separate file
@Pipe({ name: 'safeHtml', standalone: true })
export class SafeHtmlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}
  transform(value: string | null | undefined): SafeHtml {
    // Ensure value is a string before sanitizing
    return this.sanitizer.bypassSecurityTrustHtml(value || '');
  }
}

// Enhanced FormElement interface
interface FormElement {
  buttonAction?: any;
  buttonType?: any;
  type: string; // e.g., 'text', 'email', 'textarea', 'select', etc.
  label: string; // Display label for the field
  placeholder?: string; // Placeholder text for input fields
  defaultValue?: any; // Default value for the input
  options?: { value: string; label: string; checked?: boolean }[]; // Options for select, radio, checkboxes (added checked)
  multiple?: boolean; // Allow multiple selections (for select)
  rows?: number; // Number of rows for textarea
  cols?: number; // Number of columns for textarea (less common now with CSS width)
  min?: number | string; // Minimum value (numeric, date) or length (text)
  max?: number | string; // Maximum value (numeric, date) or length (text)
  step?: number | string; // Step increment (numeric, date/time ranges)
  required?: boolean; // Is the field mandatory?
  htmlContent?: string; // For Custom HTML element
  termsLink?: string; // URL for Terms & Conditions link
  checked?: boolean; // Default checked state for single radio/checkbox
  maskPattern?: string; // Input mask pattern (Note: Actual masking requires extra logic/library)
  // Configuration for which parts of the address block to show
  addressFieldsConfig?: {
    street: boolean;
    line2: boolean;
    city: boolean;
    state: boolean;
    zip: boolean;
    country: boolean; // Can be simple text or trigger country select logic
  };

  // Style properties from original file
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?: string;
  margin?: string;
  width?: string;
  height?: string;
  bordercolor?: string;
}

@Component({
  selector: 'app-test',
  standalone: true,
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
  imports: [
    NgFor,
    NgIf,
    DragDropModule,
    CommonModule,
    FormsModule,
    MatIconModule, // Keep MatIconModule if using mat-icon elsewhere
    MatInputModule,
    SafeHtmlPipe // Import the pipe 
   ],
})
export class TestComponent {
  availableElements: FormElement[] = [
    // --- Original Elements ---
    { type: 'text', label: 'Text Field', placeholder: 'Enter text'},
    { type: 'button', label: 'Button', bgColor: '#007bff', fontColor: '#ffffff', fontSize: '16px', fontWeight: 'bold', width: '100px', height: '40px' },

    // --- Added General Fields ---
    { type: 'email', label: 'Email', placeholder: 'Enter email address', required: true },
    { type: 'mask', label: 'Masked Input', placeholder: 'Formatted input (e.g., phone)', maskPattern: '' },
    { type: 'textarea', label: 'Text Area', placeholder: 'Enter multi-line text', rows: 4 },
    {
      type: 'address',
      label: 'Address Block',
      addressFieldsConfig: { street: true, line2: true, city: true, state: true, zip: true, country: true },
      required: false
    },
    {
      type: 'country',
      label: 'Country Select',
      required: false,
      options: [ /* Populate dynamically */
        { value: '', label: '-- Select Country --' },
        { value: 'US', label: 'United States' },
        { value: 'CA', label: 'Canada' },
        { value: 'GB', label: 'United Kingdom'} /* ...etc */
      ]
    },
    { type: 'number', label: 'Number', placeholder: 'Enter a number', min: 0, step: 1, required: false },
    {
      type: 'select',
      label: 'Dropdown Select',
      required: false,
      options: [
        { value: 'opt1', label: 'Option 1' }, { value: 'opt2', label: 'Option 2' }, { value: 'opt3', label: 'Option 3' }
      ]
    },
    {
      type: 'radio',
      label: 'Radio Buttons',
      required: true, // Radio usually requires a selection
      options: [
        { value: 'choice1', label: 'Choice 1' }, { value: 'choice2', label: 'Choice 2' }
      ],
      defaultValue: 'choice1'
    },
    // Example Single Checkbox
    { type: 'checkbox', label: 'Single Checkbox Label', required: false, checked: false },
     // Example Checkbox Group
    {
        type: 'checkbox-group',
        label: 'Checkbox Group',
        required: false, // Requirement might apply to group (e.g., at least one) - complex validation
        options: [
            { value: 'check1', label: 'Check A', checked: false },
            { value: 'check2', label: 'Check B', checked: true }
        ]
    },
    { type: 'url', label: 'Website URL', placeholder: 'https://example.com', required: false },
    { type: 'date', label: 'Date Select', required: false },
    { type: 'time', label: 'Time Select', required: false },
    { type: 'datetime-local', label: 'Date and Time', required: false },
    { type: 'hidden', label: 'Hidden Field (Admin only)', defaultValue: '' },
    { type: 'section-break', label: 'Section Break (Visual)' },
    { type: 'custom-html', label: 'Custom HTML Block', htmlContent: '<p><em>Your</em> default HTML content <strong>here</strong>.</p>' },
    { type: 'terms', label: 'I agree to the Terms and Conditions', required: true, termsLink: '/your-terms-page' },
    { type: 'gdpr', label: 'I consent to the GDPR policy', required: true },
  ];

  // Dropped elements in the form builder
  formItems: FormElement[] = [];

  // Index of selected element for editing
  selectedElementIndex: number | null = null;

  // --- State for binding to the *generic* editing panel ---
  // These will need to be replaced/augmented significantly when building
  // the specific editing UI for each element type.
  currentLabel: string = '';
  currentPlaceholder: string = '';
  fontSize: string = '16px';
  fontColor: string = '#000000';
  fontFamily: string = 'Arial';
  fontWeight: string = 'normal';
  borderStyle: string = 'solid';
  padding: string = '1px';
  bgColor: string = '#ffffff';
  borderWidth: string = '1px';
  margin: string = '1px';
  height: string = 'auto';
  width: string = '100%';
  bordercolor: string = '#cccccc';
  currentRequired: boolean = false;
  currentOptions: { value: string; label: string; checked?: boolean }[] = [];
  isMultiple: boolean = false;
  addressConfig: any = {};
  currentHtmlContent: string = '';

  // ... add other generic properties you might edit commonly

  // Flags to control which editing panel section is shown (example)
  isTextEditable = false;
  isButtonEditable = false;
  isSelectEditable = false;
  isRadioEditable = false;
  isCheckboxEditable = false;
  isAddressEditable = false;
  isHtmlEditable = false;

  // ... add flags for other types as you build the editor panel

  formLinkInput: string = ''; // From original file

  private _snackBar = inject(MatSnackBar);
  private Apicontroller = inject(ApicontrollerService); // Use inject if standalone
  currentMin: string | number;
  currentStep: string | number;
  currentButtonType: any;
  currentButtonAction: any;

  /**
   * Handles the drag & drop event.
   */
  onDrop(event: CdkDragDrop<FormElement[]>) {
    if (event.previousContainer === event.container) {
      // Reordering within the form builder
      moveItemInArray(this.formItems, event.previousIndex, event.currentIndex);
    } else {
      // Dropping a new element from the sidebar
      const newItem = { ...event.previousContainer.data[event.previousIndex] };
      // Deep clone options if they exist to prevent shared references
      if (newItem.options) {
        newItem.options = newItem.options.map(opt => ({ ...opt }));
      }
      this.formItems.splice(event.currentIndex, 0, newItem);
      this.selectElement(event.currentIndex); // Auto-select the newly added element
    }
  }

 /**
 * Select an element for editing. Loads its properties into panel variables.
 * NOTE: This function needs significant expansion to handle all element types.
 */
 selectElement(index: number) {
  this.selectedElementIndex = index;
  const selectedElement = this.formItems[index];

  // Reset edit panel flags
  this.isTextEditable = false;
  this.isButtonEditable = false;
  this.isSelectEditable = false;
  this.isRadioEditable = false;
  this.isCheckboxEditable = false;
  this.isAddressEditable = false;
  this.isHtmlEditable = false;

  // --- Load generic properties ---
  this.currentLabel = selectedElement.label || '';
  this.currentPlaceholder = selectedElement.placeholder || '';
  this.currentRequired = selectedElement.required || false;
  this.fontSize = selectedElement.fontSize || '16px';
  this.fontColor = selectedElement.fontColor || '#000000';
  this.fontFamily = selectedElement.fontFamily || 'Arial';
  this.fontWeight = selectedElement.fontWeight || 'normal';
  this.borderStyle = selectedElement.borderStyle || 'solid';
  this.padding = selectedElement.padding || '1px';
  this.bgColor = selectedElement.bgColor || '#ffffff';
  this.borderWidth = selectedElement.borderWidth || '1px';
  this.margin = selectedElement.margin || '1px';
  this.width = selectedElement.width || '100%';
  this.height = selectedElement.height || 'auto';
  this.bordercolor = selectedElement.bordercolor || '#cccccc';

  // --- Set flags based on type ---
  if (['text', 'email', 'textarea', 'number', 'url', 'mask', 'date', 'time', 'datetime-local'].includes(selectedElement.type)) {
      this.isTextEditable = true; // Generic panel for text-like inputs
  } else if (selectedElement.type === 'button') {
      this.isButtonEditable = true;
  } else if (selectedElement.type === 'select') {
      this.isSelectEditable = true;
      this.currentOptions = selectedElement.options || [];
      this.isMultiple = selectedElement.multiple || false;
  } else if (selectedElement.type === 'radio') {
      this.isRadioEditable = true;
      this.currentOptions = selectedElement.options || [];
  } else if (selectedElement.type === 'checkbox') {
      this.isCheckboxEditable = true;
      this.currentOptions = selectedElement.options || [];
  } else if (selectedElement.type === 'address') {
      this.isAddressEditable = true;
      this.addressConfig = selectedElement.addressFieldsConfig || {
          street: true,
          line2: false,
          city: true,
          state: true,
          zip: true,
          country: true,
      };
  } else if (selectedElement.type === 'html') {
      this.isHtmlEditable = true;
      this.currentHtmlContent = selectedElement.htmlContent || '';
  }

  console.log("Selected element type:", selectedElement.type); // Debugging
}


 /**
 * Remove an element from the form.
 */
removeElement(index: number, event: MouseEvent) {
  event.stopPropagation(); // Prevent selecting the element when clicking remove
  this.formItems.splice(index, 1);

  if (this.selectedElementIndex === index) {
    this.selectedElementIndex = null; // Deselect if the selected element is removed

    // Reset all edit panel flags
    this.isTextEditable = false;
    this.isButtonEditable = false;
    this.isSelectEditable = false;
    this.isRadioEditable = false;
    this.isCheckboxEditable = false;
    this.isAddressEditable = false;
    this.isHtmlEditable = false;

    // Reset all current properties
    this.currentLabel = '';
    this.currentPlaceholder = '';
    this.currentRequired = false;
    this.fontSize = '16px';
    this.fontColor = '#000000';
    this.fontFamily = 'Arial';
    this.fontWeight = 'normal';
    this.borderStyle = 'solid';
    this.padding = '1px';
    this.bgColor = '#ffffff';
    this.borderWidth = '1px';
    this.margin = '1px';
    this.width = '100%';
    this.height = 'auto';
    this.bordercolor = '#cccccc';
    this.currentOptions = [];
    this.isMultiple = false;
    this.addressConfig = {};
    this.currentHtmlContent = '';
  } else if (this.selectedElementIndex !== null && this.selectedElementIndex > index) {
    // Adjust index if an element before the selected one is removed
    this.selectedElementIndex--;
  }

  this._snackBar.open('Element removed.', 'Close', { duration: 2000 });
}


  /**
   * Save the form (send data to backend).
   */
  async saveForm() {
    console.log('Saved Form:', this.formItems);

    // // --- Backend Interaction (Original code commented out) ---
    // try {
    //   const resp = await this.Apicontroller.createForms(this.formItems);
    //   this.formLinkInput = resp.formLink;
    //   console.log("resp", resp);
    //   this._snackBar.open(resp.msg, 'Close', {
    //     duration: 3000, verticalPosition: 'top', horizontalPosition: 'center',
    //   });
    // } catch (error) {
    //   console.error("Error saving form:", error);
    //   this._snackBar.open('Error saving form. Please try again.', 'Close', {
    //     duration: 3000, verticalPosition: 'top', horizontalPosition: 'center', panelClass: ['error-snackbar']
    //   });
    // }
     alert('Form save logic executed (see console). Backend call commented out.'); // Placeholder feedback
  }

  /**
   * Load a form from the backend.
   */
  async loadForm() {
     if (!this.formLinkInput || !this.formLinkInput.trim()) {
        this._snackBar.open('Please enter a form link to load.', 'Close', { duration: 3000 });
        return;
     }
     console.log('Loading form:', this.formLinkInput);
    // // --- Backend Interaction (Original code commented out) ---
    // try {
    //   const resp = await this.Apicontroller.loadForms(this.formLinkInput.trim());
    //   if (resp && resp.length > 0 && resp[0].form_data) {
    //       this.formItems = resp[0].form_data;
    //       this.selectedElementIndex = null; // Deselect any element
    //       console.log("Loaded form data:", this.formItems);
    //        this._snackBar.open('Form loaded successfully!', 'Close', { duration: 3000 });
    //   } else {
    //       this._snackBar.open('Could not load form data or form not found.', 'Close', { duration: 3000 });
    //   }
    // } catch (error) {
    //     console.error("Error loading form:", error);
    //     this._snackBar.open('Error loading form. Please check the link and try again.', 'Close', {
    //         duration: 3000, panelClass: ['error-snackbar']
    //     });
    // }
     alert('Form load logic executed (see console). Backend call commented out.'); // Placeholder feedback
  }

  /**
   * Start a new, empty form.
   */
  newForm() {
    this.formItems = [];
    this.selectedElementIndex = null;
    this.formLinkInput = ''; // Clear load link input
     this._snackBar.open('New form started.', 'Close', { duration: 2000 });
  }


  // --- Validation Methods (Example for generic panel) ---
// These need refinement based on the final editing panel structure.

isCurrentLabelInvalid(): boolean {
  return this.selectedElementIndex !== null && !this.currentLabel?.trim();
}

isCurrentPlaceholderInvalid(): boolean {
  // Placeholder might not be required for all types
  const elem = this.selectedElementIndex !== null ? this.formItems[this.selectedElementIndex] : null;
  // Only invalidate if it's a type that uses placeholder AND it's empty
  if (elem && ['text', 'email', 'textarea', 'number', 'url', 'mask'].includes(elem.type)) {
    return !this.currentPlaceholder?.trim();
  }
  return false; // Not invalid if not applicable or filled
}

isCurrentMinMaxInvalid(): boolean {
  if (this.selectedElementIndex === null) return false;
  const elem = this.formItems[this.selectedElementIndex];
  
  if (elem && ['number', 'date', 'time', 'datetime-local'].includes(elem.type)) {
    const min = parseFloat(this.currentMin as string);
    const max = parseFloat(this.currentMin as string);
    return !isNaN(min) && !isNaN(max) && min > max;
  }
  return false;
}

isCurrentStepInvalid(): boolean {
  if (this.selectedElementIndex === null) return false;
  const elem = this.formItems[this.selectedElementIndex];

  if (elem && ['number', 'date', 'time', 'datetime-local'].includes(elem.type)) {
    const step = parseFloat(this.currentStep as string);
    return !isNaN(step) && step <= 0;
  }
  return false;
}

isOptionsInvalid(): boolean {
  if (this.selectedElementIndex === null) return false;
  const elem = this.formItems[this.selectedElementIndex];

  if (elem && ['select', 'radio', 'checkbox'].includes(elem.type)) {
    return !this.currentOptions || this.currentOptions.length === 0;
  }
  return false;
}

isHtmlContentInvalid(): boolean {
  if (this.selectedElementIndex === null) return false;
  const elem = this.formItems[this.selectedElementIndex];

  return elem.type === 'html' && (!this.currentHtmlContent?.trim());
}

isAddressConfigInvalid(): boolean {
  if (this.selectedElementIndex === null) return false;
  const elem = this.formItems[this.selectedElementIndex];

  return elem.type === 'address' && !this.addressConfig;
}


  // --- Update Styles/Properties (Example for generic panel) ---
  // This needs significant expansion to update the *correct* properties
  // based on the currently selected element and the active editing panel section.
  updateSelectedElement() {
    if (this.selectedElementIndex === null) return;
  
    const selectedElement = this.formItems[this.selectedElementIndex];
  
    // Update common properties handled by the basic panel
    selectedElement.label = this.currentLabel;
    selectedElement.placeholder = this.currentPlaceholder; // Only for relevant types
    selectedElement.required = this.currentRequired;
    selectedElement.fontSize = this.fontSize;
    selectedElement.fontColor = this.fontColor;
    selectedElement.fontFamily = this.fontFamily;
    selectedElement.fontWeight = this.fontWeight;
    selectedElement.borderStyle = this.borderStyle;
    selectedElement.padding = this.padding;
    selectedElement.bgColor = this.bgColor;
    selectedElement.borderWidth = this.borderWidth;
    selectedElement.margin = this.margin;
    selectedElement.width = this.width;
    selectedElement.height = this.height;
    selectedElement.bordercolor = this.bordercolor;
  
    // Update properties based on element type
    switch (selectedElement.type) {
      case 'text':
      case 'email':
      case 'textarea':
      case 'number':
      case 'url':
      case 'mask':
      case 'date':
      case 'time':
      case 'datetime-local':
        selectedElement.min = this.currentMin;
        selectedElement.max = this.currentMin;
        selectedElement.step = this.currentStep;
        break;
  
      case 'select':
        selectedElement.options = this.currentOptions?.map(opt => ({
          value: opt.value,
          label: opt.label,
          checked: opt.checked || false
        })) || [];
        selectedElement.multiple = this.isMultiple;
        break;
  
      case 'radio':
      case 'checkbox':
        selectedElement.options = this.currentOptions?.map(opt => ({
          value: opt.value,
          label: opt.label,
          checked: opt.checked || false
        })) || [];
        break;
  
      case 'address':
        selectedElement.addressFieldsConfig = { ...this.addressConfig };
        break;
  
      case 'button':
        selectedElement.buttonType = this.currentButtonType;
        selectedElement.buttonAction = this.currentButtonAction;
        break;
  
      case 'html':
        selectedElement.htmlContent = this.currentHtmlContent;
        break;
  
      default:
        console.warn("Unhandled element type:", selectedElement.type);
    }
  
    console.log("Updated element:", selectedElement);
    this._snackBar.open('Element updated.', 'Close', { duration: 2000 });
  }
    
  
}
