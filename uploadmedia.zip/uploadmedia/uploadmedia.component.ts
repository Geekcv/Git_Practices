import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../config';
import { MatGridListModule } from '@angular/material/grid-list';


interface Patient {
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

@Component({
  selector: 'app-uploadmedia',
  imports: [MatFormFieldModule, MatSelectModule, FormsModule, MatButtonModule, MatCardModule,MatGridListModule],
  templateUrl: './uploadmedia.component.html'
})
export class UploadmediaComponent {
  role: number;
  errorMessage: string = '';
  successMessage: string = '';
  config: string = config.apiBaseURL;

  userDetails: Doctor | null = null;
  patientDetails: Patient | null = null;

  uploadedFiles: { filePath: string; mediaType: string }[] = [];
  Formate: string = '';
  availableFormate: string[] = ['video/mp4', 'audio/mpeg', 'image/png'];

  filename: string = '';
  filepath: string = '';
  mediatype: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService,
    private http: HttpClient
  ) {
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
    this.loadUserDetails();
  }

  /** Load User Details from localStorage */
  private loadUserDetails(): void {
    const userData = localStorage.getItem('userDeatials');
    if (userData) {
      if (this.role === 1) {
        this.userDetails = JSON.parse(userData);
      } else {
        this.patientDetails = JSON.parse(userData);
      }
    }
  }

  /** Handle File Selection & Upload */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);

      this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: async (response: any) => {
          if (response) {
            this.filename = response.data.name;
            this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
            this.mediatype = response.data.mimetype;

            console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

            const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
            if (!rowId) {
              this.errorMessage = 'User ID not found.';
              return;
            }

            const data = {
              doc_row_id: rowId,
              file_name: this.filename,
              file_path: this.filepath,
              media_type: this.mediatype,
            };

            try {
              const resp = await this.apiController.uploadmedia(data);
              console.log("Upload Response:", resp);
              this.successMessage = 'File uploaded successfully!';
            } catch (error) {
              console.error("Upload failed:", error);
              this.errorMessage = 'File upload failed. Please try again.';
            }
          } else {
            this.errorMessage = 'Invalid server response.';
          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
          this.errorMessage = 'File upload failed. Please try again.';
        },
      });
    }
  }

  /** Fetch Media from Server */
  async fetchFiles() {
    const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
    if (!rowId) {
      this.errorMessage = 'User ID not found.';
      return;
    }

    const data = {
      row_id: rowId,
      media_type: this.Formate,
    };

    try {
      const resp = await this.apiController.fetchmedia(data);
      this.uploadedFiles = resp.data.map((file: any) => ({
        filePath: file.media_link,
        mediaType: file.media_type,
      }));

      console.log("Fetched media:", this.uploadedFiles);
    } catch (error) {
      console.error("Fetch error:", error);
      this.errorMessage = "Failed to fetch media.";
    }
  }
}
