// /* eslint-disable */
// import { FuseNavigationItem } from '@fuse/components/navigation';

// export const defaultNavigation: FuseNavigationItem[] = [
//     // {
//     //     id   : 'example',
//     //     title: 'Example15',
//     //     type : 'basic',
//     //     icon : 'heroicons_outline:chart-pie',
//     //     link : '/example'
//     // },
//     // {
//     //     id   : 'test',
//     //     title: 'test',
//     //     type : 'basic',
//     //     icon : 'feather:alert-octagon',
//     //     link : '/test'
//     // },
//     {
//         id   : 'dashboard',
//         title: 'Dashboard',
//         type : 'basic',
//         icon : 'mat_solid:dashboard',
//         link : '/dashboard',
//     },
//     {
//         id   : 'Viewresearchers',
//         title: 'View Researchers',
//         type : 'basic',
//         icon : 'heroicons_outline:viewfinder-circle',
//         link : '/Viewresearchers'
//     },
//     {
//         id   : 'Addresearchers',
//         title: 'Add Researchers',
//         type : 'basic',
//         icon : 'heroicons_outline:adjustments-vertical',
//         link : '/Addresearchers'
//     },
//     {
//         id   : 'Viewpatients',
//         title: 'View Patients',
//         type : 'basic',
//         icon : 'feather:command',
//         link : '/Viewpatients'
//     },
//     {
//         id   : 'Addpatients',
//         title: 'Add Patients',
//         type : 'basic',
//         icon : 'heroicons_solid:arrow-up-on-square-stack',
//         link : '/Addpatients'
//     },
//     {
//         id   : 'Account',
//         title: 'Account',
//         type : 'basic',
//         icon : 'feather:settings',
//         link : '/account'
//     },
// ];
// export const compactNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example'
//     }
// ];
// export const futuristicNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example'
//     }
// ];
// export const horizontalNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example1'
//     }
// ];


/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const getNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    if (role === 0) { // Super Admin - Full Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Viewresearchers',
                title: 'View Researchers',
                type: 'basic',
                icon: 'heroicons_outline:viewfinder-circle',
                link: '/Viewresearchers'
            },
            {
                id: 'Addresearchers',
                title: 'Add Researchers',
                type: 'basic',
                icon: 'heroicons_outline:adjustments-vertical',
                link: '/Addresearchers'
            },
            
            {
                id: 'Account',
                title: 'Account',
                type: 'basic',
                icon: 'feather:settings',
                link: '/account'
            }
        );
    } else if (role === 1) { // Admin - Limited Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Viewpatients',
                title: 'View Patients',
                type: 'basic',
                icon: 'feather:command',
                link: '/Viewpatients'
            },
            {
                id: 'Addpatients',
                title: 'Add Patients',
                type: 'basic',
                icon: 'heroicons_solid:arrow-up-on-square-stack',
                link: '/Addpatients'
            },
            {
                id: 'Account',
                title: 'Account',
                type: 'basic',
                icon: 'feather:settings',
                link: '/account'
            }
        );
    } else if (role === 2) { // User - Minimum Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Account',
                title: 'Account',
                type: 'basic',
                icon: 'feather:settings',
                link: '/account'
            }
        );
    }

    return navigation;
};
