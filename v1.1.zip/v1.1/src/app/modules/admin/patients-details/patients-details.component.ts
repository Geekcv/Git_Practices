import { AsyncPipe, CommonModule } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';


interface Patient {
 
patient_age: string;
patient_email: string;
patient_gender: string;
patient_name:string;
user_contact_number:string;
user_password:string;
user_row_id:string;
}
 


@Component({
  selector: 'app-patients-details',
  imports:[   
    // AsyncPipe,
    MatButtonModule,
     MatIconModule,
    CommonModule,
    MatTableModule,
   ],
  templateUrl: './patients-details.component.html'
})
export class PatientsDetailsComponent {

  patientsId!: string | null; // Holds the patientsId ID from the route
  
  patient: Patient[] = [];
   
    displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      'patient_gender'
    ];
  
  
  
    constructor(
      private route: ActivatedRoute,
      private router: Router,
      private apiController: ApicontrollerService,
      private authService: AuthService
    ) {
      
    }
  
    ngOnInit() {
      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchdoctor();
  
    }
  
  
    async fetchdoctor(): Promise<void> {
      try {
        const response = await this.apiController.fetchSefesficpatients(this.patientsId);
        this.patient = response.data || []; // Ensure `data` exists in the API response
        // console.log("doctor----",this.patient)
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }
  
  
    goback(){
      // console.log("click this button")
      this.router.navigate(['/Viewpatients'])
    }
  

}
