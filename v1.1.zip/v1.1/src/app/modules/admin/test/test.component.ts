import { AsyncPipe, CommonModule } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { map, Observable, startWith } from 'rxjs';


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
}
 


@Component({
  selector: 'app-test',
  standalone   : true,
  templateUrl: './test.component.html',
   encapsulation: ViewEncapsulation.None,
   imports:[   FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
   // AsyncPipe,
   CommonModule,
   MatTableModule
  ]
})
export class TestComponent implements OnInit {

  researchersId!: string | null; // Holds the researchersId ID from the route

  doctor: Doctor[] = [];

  displayedColumns: string[] = [
    'user_row_id',
    'doctor_name',
    'doctor_email',
    'user_contact_number',
    'doctor_gender'
  ];



  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.researchersId = this.route.snapshot.paramMap.get('id');
    console.log("researchersId",this.researchersId)

    this.fetchdoctor();

  }


  async fetchdoctor(): Promise<void> {
    try {
      const response = await this.apiController.fetchSefesficdoctor(this.researchersId);
      this.doctor = response.data || []; // Ensure `data` exists in the API response
      console.log("doctor----",this.doctor)
    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }




}
