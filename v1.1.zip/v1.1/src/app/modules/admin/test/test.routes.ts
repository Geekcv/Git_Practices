import { Routes } from '@angular/router';
import { TestComponent } from 'app/modules/admin/test/test.component';

export default [
    {
        path: '',
        component: TestComponent,
    },
] as Routes;
