import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
}
 



@Component({
  selector: 'app-viewresearchers',
  imports: [MatTableModule,MatPaginatorModule],
  templateUrl: './viewresearchers.component.html',
})
export class ViewresearchersComponent { 
  role :any ='';
 // doctor: Doctor[] = [];
  displayedColumns: string[] = [
      'user_row_id', 
      'doctor_name', 
      'doctor_email', 
      'doctor_gender', 
      'user_contact_number'
  ];

  doctor = new MatTableDataSource<Doctor>([]); // Use MatTableDataSource for pagination

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router
  ) { 

    this.role=  localStorage.getItem('role')

    // console.log("my role",this.role)
  }

  ngOnInit(): void {
    this.mydoctor();
  }

  ngAfterViewInit() {
    this.doctor.paginator = this.paginator; // Set paginator after view init
  }

  page: number = 1; // Default to first page

  async mydoctor() {
    try {
      const resp = await this.Apicontroller.fetchdoctor('common',this.page);
      // console.log("doctor", resp);
      this.doctor.data = resp.data as Doctor[]; // Type assert to Doctor[]
    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }


  viewDoctorDetails(doctor: Doctor) {
    this.router.navigate(['researchersDetails', doctor.user_row_id]);
  }
     
}
