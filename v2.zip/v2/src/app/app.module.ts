import { NgModule } from '@angular/core';
import {  DatePipe } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import { AppRoutingModule } from './app-routing.module';
import { MatButtonModule } from '@angular/material/button';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from './services/auth.service';
import { HttpClientModule } from '@angular/common/http';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { MenubarModule } from 'primeng/menubar';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DropdownModule } from 'primeng/dropdown';
import { FormBuilderComponent } from './custom-components/form-builder/form-builder.component';
import { InputNumberModule } from 'primeng/inputnumber';
import { RadioButtonModule } from 'primeng/radiobutton';
import { CheckboxModule } from 'primeng/checkbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { EditorModule } from 'primeng/editor';
import { TableBuilderComponent } from './custom-components/table-builder/table-builder.component';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { FileUploadModule } from 'primeng/fileupload';
import { FileUploadComponent } from './custom-components/file-upload/file-upload.component';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './services/auth.guard';
import { HomeComponent } from './components/home/home.component';
import { StudentComponent } from './components/student/student.component';
import { CheckerComponent } from './components/checker/checker.component';
import { ExamComponent } from './components/exam/exam.component';
import { ExamCenterComponent } from './components/exam-center/exam-center.component';
import { ClassesComponent } from './components/classes/classes.component';
import { BranchComponent } from './components/branch/branch.component';
import { AttendanceComponent } from './components/attendance/attendance.component';
import { BandalComponent } from './components/bandal/bandal.component';
import { MarksComponent } from './components/marks/marks.component';
import { StudentCenterAssignmentComponent } from './components/student-center-assignment/student-center-assignment.component';
import { ListStudentComponent } from './components/list-student/list-student.component';
import { CenterWiseStudentComponent } from './components/center-wise-student/center-wise-student.component';
import { CityWiseStudentComponent } from './components/city-wise-student/city-wise-student.component';
import { CenterWiseStudentTotalComponent } from './components/center-wise-student-total/center-wise-student-total.component';
import { AdmissionCardComponent } from './components/admission-card/admission-card.component';
import { RejectStudentExamComponent } from './components/reject-student-exam/reject-student-exam.component';
import { StudentMarksReportComponent } from './components/student-marks-report/student-marks-report.component';
import { MeritListComponent } from './components/merit-list/merit-list.component';
import { CenterWiseAmountComponent } from './components/center-wise-amount/center-wise-amount.component';
import { StudentMarksFilterReportComponent } from './components/student-marks-filter-report/student-marks-filter-report.component';
import { MeritListCenterWiseComponent } from './components/merit-list-center-wise/merit-list-center-wise.component';
import { MediumWiseReportComponent } from './components/medium-wise-report/medium-wise-report.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    
    TableBuilderComponent,FileUploadComponent,FormBuilderComponent, StudentComponent, CheckerComponent, ExamComponent, ExamCenterComponent, ClassesComponent, BranchComponent, AttendanceComponent, BandalComponent, MarksComponent, StudentCenterAssignmentComponent, ListStudentComponent, CenterWiseStudentComponent, CityWiseStudentComponent, CenterWiseStudentTotalComponent, AdmissionCardComponent, RejectStudentExamComponent, StudentMarksReportComponent, MeritListComponent, CenterWiseAmountComponent, StudentMarksFilterReportComponent, MeritListCenterWiseComponent, MediumWiseReportComponent, 
  ],
  imports: [
    InputTextModule,AutoCompleteModule,
    PasswordModule, MenubarModule,
    ButtonModule, FileUploadModule,DialogModule,
    CardModule, CalendarModule,
    BrowserModule, BrowserAnimationsModule, ReactiveFormsModule, TableModule, FormsModule, MatCardModule, MatInputModule, MultiSelectModule, MatSnackBarModule, DropdownModule, RadioButtonModule,
    AppRoutingModule, MatFormFieldModule, FlexLayoutModule, MatButtonModule, HttpClientModule, InputTextareaModule, EditorModule, InputNumberModule, CheckboxModule
  ],
  providers: [DatePipe,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
