import { Component, ViewChild, OnInit } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;

  constructor(
    public formsService: FormsService,
    private apiController: ApicontrollerService,
    public utiltiesService: UtiltiesService,
    public jsonlist: JsonListService
  ) { }

  selectedRowId: any;
  searchFields: any = this.formsService.studentTableData.searchFields;
  students: any[] = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any = this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any = 100;
  limit: any = 100;
  noofpage: any = 1;
  page: any = 1;
  bundleNo: any;
  displayDialog: boolean = false;
  selectedStudent: any = null;
  exams: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
  checkers: any[] = [];
  filteredCenters: any[] = [];
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedClass: any = null;
  selectedCenter: any = null;
  selectedStudents: any[] = [];
  displayRejectDialog: boolean = false;
  rejectionRemarks: string = '';
  studentToReject: any = null;

  ngOnInit(): void {
    this.loadInitialData();
    this.loadInitialFilters();
  }

  loadInitialData() {
    this.exams = [];
    this.classes = [];
    this.centers = [];
    this.checkers = [];
    this.fetchExams();
    this.fetchExamCenter();
  }

  async loadInitialFilters() {
    // Example: Fetch initial dropdown data
    // this.exams = await this.apiController.fetchExams();
    // this.centers = await this.apiController.fetchCenters();
    // ... fetch other necessary data ...
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }

  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async onFilterChange() {
    if (this.selectedFaculty && this.selectedExam && this.selectedClass && this.selectedCenter) {
      await this.fetchStudentsForAttendance();
    } else {
      this.students = [];
    }
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.exams = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.exams.push({
          title: tempClientDAta[i].session_name,
          data: tempClientDAta[i],
          value: tempClientDAta[i].row_id
        });
      }
    }
  }

  async fetchClasses(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(this.selectedFaculty, page, limit);
    if (tempClientDAta != false) {
      this.classes = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.classes.push({
          title: tempClientDAta[i].class_name,
          data: tempClientDAta[i],
          value: tempClientDAta[i].row_id
        });
      }
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push({
          title: tempClientDAta[i].center,
          data: tempClientDAta[i],
          value: tempClientDAta[i].row_id
        });
      }
    }
  }

  async fetchStudentsForAttendance() {
    console.log('Fetching students for:', this.selectedFaculty, this.selectedExam, this.selectedClass, this.selectedCenter);
    this.students = await this.apiController.fetchStudentAttendance(
      this.selectedCenter,
      this.selectedExam,
      this.selectedClass,
     this.page,this.limit 
    ) || [];
    console.log('Fetched students:', this.students);
  }

  editClient(cl: any) {
    this.savedForm = cl.originalData;
    this.selectedRowId = cl.rowId;
  }

  deleteClient(cl: any) {
    // console.log(cl);
  }

  fetchNextData(row: any) {
    // If pagination is needed for filtered results, call fetchFilteredStudents
    // const page = row.page;
    // const limit = row.limit;
    // this.fetchFilteredStudents(page, limit);
  }

  async fetchCount() {
    var totRec = await this.apiController.fetchCount('attendance');
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
    }
  }

  showActionDialog(student: any) {
    this.selectedStudent = student;
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedCenter = null;
    this.filteredCenters = [];
    this.displayDialog = true;
  }

  hideDialog() {
    this.displayDialog = false;
    this.selectedStudent = null;
  }

  searchCenter(event: any) {
    let query = event.query;
    this.filteredCenters = this.centers.filter(center => {
      return center.title.toLowerCase().includes(query.toLowerCase());
    });
  }

  openRejectDialog(student: any) {
    this.studentToReject = student;
    this.rejectionRemarks = student.remarks || '';
    this.displayRejectDialog = true;
  }

  hideRejectDialog() {
    this.displayRejectDialog = false;
    this.studentToReject = null;
    this.rejectionRemarks = '';
  }

  submitRejection() {
    if (this.studentToReject && this.rejectionRemarks) {
      this.updateAttendance(this.studentToReject, 2, this.rejectionRemarks);
      this.hideRejectDialog();
    } else {
      this.utiltiesService.openSnackBar("Please enter rejection remarks.");
    }
  }

  async updateAttendance(student: any, status: number, remarks: string | null = null) {
    console.log(`Updating attendance for ${student.attendance_row_id} (ID: ${student.id}) to status ${status} with remarks: ${remarks}`);

   await this.apiController.updateAttendance(student.attendance_row_id,this.selectedExam, this.selectedClass,this.selectedFaculty, this.selectedCenter, status, remarks);

  this.fetchStudentsForAttendance(); // Refresh the student list after update
  }
}
