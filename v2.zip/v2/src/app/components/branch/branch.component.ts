import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent {
 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.branchTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.branchTableData.tableDataHeader;
  tableTitle: any =  this.formsService.branchTableData.title;
  tableDataRows:any = this.formsService.branchTableData.tableDataRows;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  ngOnInit() {
    this.fetchCount();
    this.fetchBranches();
  }

  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.saveBranch(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchBranches();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchBranches(page = 1, limit = 100) {
    var tempClientDAta = await this.apiController.fetchBranches(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push(
          {
            "branch_name": tempClientDAta[i].branch_name,
            "branch_head_name": tempClientDAta[i].branch_head_name,
            "mobile": tempClientDAta[i].mobile_no,
            "address": tempClientDAta[i].address,
            "city": tempClientDAta[i].city,
            "data": tempClientDAta[i],
            "rowId": tempClientDAta[i].row_id
          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
  editClient(cl: any) {
   console.log(cl);
    this.savedForm=cl.data;
    
    this.selectedRowId = cl.rowId;
   // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchBranches(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('branch');
   // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchBranches();
  }

}
