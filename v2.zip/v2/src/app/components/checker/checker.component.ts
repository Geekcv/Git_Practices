import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-checker',
  templateUrl: './checker.component.html',
  styleUrls: ['./checker.component.css']
})
export class CheckerComponent {
@ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.sheetCheckerTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.sheetCheckerTableData.tableDataHeader;
  tableDataRows:any = this.formsService.sheetCheckerTableData.tableDataRows;
  tableTitle: any =  this.formsService.sheetCheckerTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  ngOnInit() {
    this.fetchCount();
    this.fetchStudents();
  }

  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.saveSheetChecker(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchStudents();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = 100) {
    var tempClientDAta = await this.apiController.fetchSheetCheckers(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push(
          {
            "name": tempClientDAta[i].name,
            "mobile": tempClientDAta[i].mobile,
            "address": tempClientDAta[i].address,
            
            "data": tempClientDAta[i],
            "rowId": tempClientDAta[i].row_id,
            "account_no": tempClientDAta[i].account_no,
            "account_name": tempClientDAta[i].account_name,
            "bank_name": tempClientDAta[i].bank_name,
            "branch_name": tempClientDAta[i].branch_name,
            "ifsc_code": tempClientDAta[i].ifsc_code,



            

          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
  editClient(cl: any) {
   // console.log(cl);
    this.savedForm=cl.data;
    
    this.selectedRowId = cl.rowId;
   // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('copy_checkers');
   // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchStudents();
  }
}
