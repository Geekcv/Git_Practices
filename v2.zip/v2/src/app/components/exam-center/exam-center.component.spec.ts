import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExamCenterComponent } from './exam-center.component';

describe('ExamCenterComponent', () => {
  let component: ExamCenterComponent;
  let fixture: ComponentFixture<ExamCenterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ExamCenterComponent]
    });
    fixture = TestBed.createComponent(ExamCenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
