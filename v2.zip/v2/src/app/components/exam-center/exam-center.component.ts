import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-exam-center',
  templateUrl: './exam-center.component.html',
  styleUrls: ['./exam-center.component.css']
})
export class ExamCenterComponent {
 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.examCenterTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.examCenterTableData.tableDataHeader;
  tableDataRows:any = this.formsService.examCenterTableData.tableDataRows;
  tableTitle: any =  this.formsService.examCenterTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  branches:any=[];
  ngOnInit() {
    this.fetchCount();
    this.fetchStudents();
    this.fetchBranches();
  }

  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.saveExamCenter(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchStudents();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = 5) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    console.log("res-->",tempClientDAta)
    if (tempClientDAta != false) {
      this.tableData = [];
    // console.log("tempClientDAta========",tempClientDAta);
      for (var i = 0; i < tempClientDAta.length; i++) {

        this.tableData.push(
          {
            "center": tempClientDAta[i].center,
            "center_head_name": tempClientDAta[i].center_head_name,
            "mobile": tempClientDAta[i].mobile_no,
            "email": tempClientDAta[i].email,
            "address": tempClientDAta[i].address,
            
            "data": tempClientDAta[i],
            "rowId": tempClientDAta[i].row_id,
            "center_code":tempClientDAta[i].center_code,
            "phone_no":tempClientDAta[i].phone_no,
            "account_no":tempClientDAta[i].account_no,
            "account_name":tempClientDAta[i].account_name,
            "bank_name":tempClientDAta[i].bank_name,
            "ifsc_code":tempClientDAta[i].ifsc_code,





          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }
  async fetchBranches(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchBranches(page, limit);
    if (tempClientDAta != false) {
      this.branches = [];
      var tempOptions: { value: any; title: any; }[] = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        const branch = tempClientDAta[i];
        this.branches.push(
          {
            "branch_name": branch.branch_name,
            "branch_head_name": branch.branch_head_name,
            "mobile": branch.mobile_no,
            "city": branch.city,
            
            "data": branch,
            "rowId": branch.row_id
          }
        );
        // Populate tempOptions with appropriate value and title
        tempOptions.push({ value: branch.row_id, title: branch.branch_name });
      }
            
      var tempInd = this.utiltiesService.findIndexByKeyValue(this.formsService.examCenterForm.elements, 'id', 'branch_id');

      // Use type assertion 'as any' or define a proper type for elements with options
      (this.formsService.examCenterForm.elements[tempInd] as any)['options'] = [...tempOptions];
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
  editClient(cl: any) {
   // console.log(cl);
    this.savedForm=cl.data;
    
    this.selectedRowId = cl.rowId;
   // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('centers');
   // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchStudents();
  }

}
