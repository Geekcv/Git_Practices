import { Component, OnInit, ViewChild } from '@angular/core'; // Import OnInit
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-list-student',
  templateUrl: './list-student.component.html',
  styleUrls: ['./list-student.component.css']
})
// Add OnInit implementation
export class ListStudentComponent implements OnInit {
 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService,public jsonlist:JsonListService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.studentTableData.searchFields;
  // Rename tableData to students to match the template binding [value]="students"
  students: any = []; // Renamed from tableData
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableTitle: any =  this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 5;
  noofpage: any = 1;
  Examlogdata:any = [];

  // --- Add properties for the dialog ---
  displayDialog: boolean = false;
  selectedStudent: any = null; // Declare selectedStudent
  exams: any[] = []; // Example: [{label: 'Exam 1', value: 'E1'}, {label: 'Exam 2', value: 'E2'}]
  classes: any[] = []; // Example: [{label: 'Class A', value: 'C1'}, {label: 'Class B', value: 'C2'}]
  centers: any[] = []; // Example: [{id: 1, name: 'Center A'}, {id: 2, name: 'Center B'}] - This holds all centers
  filteredCenters: any[] = []; // For autocomplete suggestions
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedClass: any = null;
  selectedCenter: any = null;
  // --- End of dialog properties ---


  ngOnInit() {
    // this.fetchCount();
    this.fetchStudents();
    // Initialize dropdown/autocomplete data if needed
    this.loadInitialData();
  }

  loadInitialData() {
    // Placeholder: Load your exam, class, and center data here
    // Example:
    this.exams = [];
    this.classes = [];
    this.centers = [];
    // this.fetchClasses();
    this.fetchExams();
    this.fetchExamCenter();
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
    // console.log("exams========",tempClientDAta);
      this.exams = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.exams.push(
          {
            title: tempClientDAta[i].session_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }
  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,page, limit);
    if (tempClientDAta != false) {
    // console.log("classes========",tempClientDAta);
      this.classes = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.classes.push(
          {
            title: tempClientDAta[i].class_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }
  async fetchExamCenter(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
      // console.log("centers========",tempClientDAta);
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.centers.push(
          {
            title: tempClientDAta[i].center, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }
  async fetchStudents(page = 1, limit = 100) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchStudents(page, limit);
    if (tempClientDAta != false) {
      console.log("response dta============",tempClientDAta);
      this.students = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.students.push(
          {
            name: tempClientDAta[i].student_name, // Assuming student_name maps to name
            rollNo: tempClientDAta[i].roll_no || `TEMP-${i}`, // Assuming roll_no exists, or provide a placeholder
            father_name: tempClientDAta[i].father_name,
            dob: this.utiltiesService.formateDatetoddmmyyyy(new Date(tempClientDAta[i].dob)),
            gender:tempClientDAta[i].gender=='m'?"Male":"Female",
            address: tempClientDAta[i].address,
            city: tempClientDAta[i].city,
            phone: tempClientDAta[i].phone_r,
            originalData: tempClientDAta[i], // Keep original data if needed
            rowId: tempClientDAta[i].row_id
          }
        );
      }
    }
  }

  editClient(cl: any) {
    this.savedForm=cl.originalData; // Use original data if needed for other forms
    this.selectedRowId = cl.rowId;
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
    const page = row.page;
    const limit = row.limit;
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('qu'); // Replace 'qu' if needed
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
    }
    // No need to call fetchStudents here again if called in ngOnInit
  }

  // --- Add methods for the dialog ---
  showActionDialog(student: any) {
    
    this.selectedStudent = student; // Set the selected student
    

    // Reset form fields when opening dialog
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedCenter = null;
    this.filteredCenters = [];
    this.displayDialog = true; // Show the dialog

    this.fetchExamlogStudent()
  }

  hideDialog() {
    this.displayDialog = false; // Hide the dialog
    this.selectedStudent = null; // Clear selected student
  }

  searchCenter(event: any) {
    // Basic filtering example, adjust as needed
    let query = event.query;

    this.filteredCenters = this.centers.filter(center => {
      return center.title.toLowerCase().includes(query.toLowerCase());
    });
  }

  async assignDetails() {
    if (this.selectedStudent && this.selectedExam && this.selectedClass && this.selectedCenter) {
    // console.log('Assigning Details:', {
      //   studentId: this.selectedStudent.rowId, // or another unique ID
      //   studentName: this.selectedStudent.name,
      //   exam: this.selectedExam,
      //   class: this.selectedClass,
      //   center: this.selectedCenter // This will be the selected center object
      // });
   

await this.apiController.assignExamtoStudent(this.selectedStudent.rowId, this.selectedExam, this.selectedClass, this.selectedCenter,this.selectedFaculty);
      this.hideDialog(); // Close dialog on successful assignment
    } else {
      console.error('Form is not complete');
      // Optionally show a message to the user
    }
  }
  // --- End of dialog methods ---

  async fetchExamlogStudent(){
    console.log("selected students",this.selectedStudent.rowId)
    var exallogdata = await this.apiController.StudentExamLog(this.selectedStudent.rowId);
   
    console.log("res-->",exallogdata)
    if (exallogdata != false) {
      console.log("response dta============",exallogdata);
      this.Examlogdata = []; // Clear existing students
      for (var i = 0; i < exallogdata.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.Examlogdata.push(
          {
            name: exallogdata[i].student_name, 
            className: exallogdata[i].class_name,
            center: exallogdata[i].center,
            sessionName:exallogdata[i].session_name,
            examDate: exallogdata[i].exam_date,
            marks: exallogdata[i].marks,
          
          }
        );
      }
    }else{
      this.Examlogdata = []; // Clear existing students
    }
  }
}