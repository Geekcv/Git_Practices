import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private apiController: ApicontrollerService,private authService:AuthService,private router:Router) { }
 
  ngOnInit(): void {
    const token = this.authService.getToken();
   // console.log('Token', token);
    if (token) {
      this.router.navigate(['/']);  // Redirect to ClientComponent if token exists
    }
  }
  loginform = {
    "username": "",
    "password": ""
  }
  async login() {
    // Login logic here
    // console.log('Login', this.loginform);
    await this.apiController.loginUser(this.loginform);
  }
}
