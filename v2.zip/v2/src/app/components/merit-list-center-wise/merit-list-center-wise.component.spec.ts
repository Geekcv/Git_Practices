import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeritListCenterWiseComponent } from './merit-list-center-wise.component';

describe('MeritListCenterWiseComponent', () => {
  let component: MeritListCenterWiseComponent;
  let fixture: ComponentFixture<MeritListCenterWiseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MeritListCenterWiseComponent]
    });
    fixture = TestBed.createComponent(MeritListCenterWiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
