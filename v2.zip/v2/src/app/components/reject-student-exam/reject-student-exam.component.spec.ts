import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectStudentExamComponent } from './reject-student-exam.component';

describe('RejectStudentExamComponent', () => {
  let component: RejectStudentExamComponent;
  let fixture: ComponentFixture<RejectStudentExamComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RejectStudentExamComponent]
    });
    fixture = TestBed.createComponent(RejectStudentExamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
