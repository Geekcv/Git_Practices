import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-reject-student-exam',
  templateUrl: './reject-student-exam.component.html',
  styleUrls: ['./reject-student-exam.component.css']
})
export class RejectStudentExamComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];

  // Selected filter values
  selectedExamSession: any = null;

  // Data for the report table
  rejectedStudents: any[] = []; // e.g., [{ name: '...', fatherHusbandName: '...', ..., remarks: '...' }, ...]
  submitted: boolean = false; // To track if submit was clicked

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = []; // Adapt API call
    this.fetchExams();
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }

  async fetchRejectedStudents() {
    this.submitted = true;
    this.rejectedStudents = []; // Clear previous results
    if (!this.selectedExamSession) {
      console.error("Please select an Exam Session.");
      return;
    }
    console.log('Fetching rejected students for session:', this.selectedExamSession);

    // Call API to fetch rejected students based on the selected session
    const fetchedData = await this.apiController.fetchRejectStudentExam(
        this.selectedExamSession
    ) || []; // Create this API call

    // Map fetchedData to the structure needed by the table
    this.rejectedStudents = fetchedData.map((item: any) => ({
        name: item.student_name, // Adjust field names based on API response
        fatherHusbandName: item.father_name,
        address: item.address,
        centerCode: item.center_code,
        centerName: item.center,
        rollNo: item.roll_no,
        phoneNo: item.phone_no,
        mobileNo: item.mobile_no,
        remarks: item.remarks, // Reason for rejection
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched rejected students:', this.rejectedStudents);
  }

  // --- Helper method for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }
  // --- End Helper method ---

  exportData() {
    if (this.rejectedStudents && this.rejectedStudents.length > 0) {
      console.log("Exporting data...", this.rejectedStudents);
      this.rejectedStudents.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.rejectedStudents, 'RejectedExamStudentsReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'RejectedExamStudentsReport'); // Adjust the ID of the report section
  }
}
