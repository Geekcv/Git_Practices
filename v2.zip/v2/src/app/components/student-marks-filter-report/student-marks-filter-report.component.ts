import { Component } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student-marks-filter-report',
  templateUrl: './student-marks-filter-report.component.html',
  styleUrls: ['./student-marks-filter-report.component.css']
})
export class StudentMarksFilterReportComponent {

  // Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];
  centers: any[] = [];

  // Selected filter values
  selectedFaculty: string = '0'; // Default value
  selectedExamSession: any = null;
  selectedClass: any = null; // Optional filter
  selectedCenter: any = null; // Optional filter
  marksFrom: number | null = null;
  marksTo: number | null = null;

  // Data for the report table
  filteredMarksData: any[] = [];
  submitted: boolean = false;

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService,
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = [];
    // Fetch centers (assuming you want all centers initially)
    this.centers =  [];
    this.fetchExams();
    this.fetchExamCenter();
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push(
          {
            name: tempClientDAta[i].center, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i], // Keep original data if needed (e.g., for code)
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchClasses() {
    this.selectedClass = null; // Reset class when faculty changes
    this.classes = [];
    this.submitted = false;
    if (this.selectedFaculty) {
      console.log(`Fetching classes for faculty: ${this.selectedFaculty}`);
      // Fetch classes based on selectedFaculty ('Board' or 'Thokra')
      // You might need separate API calls or pass the faculty type
      this.classes = await this.apiController.fetchClassesByFaculty(this.selectedFaculty,1,100) || []; // Adapt/Create this API call
      // Map data if needed
      console.log('Fetched classes:', this.classes);
    }
  }


  async fetchFilteredMarks() {
    this.submitted = true;
    this.filteredMarksData = []; // Clear previous results
    if (!this.selectedFaculty || !this.selectedExamSession) {
      console.error("Please select Faculty and Exam Session.");
      return;
    }

    // Validate marks range if both are entered
    if (this.marksFrom !== null && this.marksTo !== null && this.marksFrom > this.marksTo) {
        this.utiltiesService.openSnackBar("Marks 'From' value cannot be greater than 'To' value.");
        return;
    }


    console.log('Fetching filtered marks for:', this.selectedFaculty, this.selectedExamSession, this.selectedClass, this.selectedCenter, this.marksFrom, this.marksTo);

    // Call API to fetch filtered marks list
    const fetchedData = await this.apiController.fetchStudentMarks(
        this.selectedFaculty,
        this.selectedExamSession,
        this.selectedClass, // Pass null if not selected
        this.selectedCenter, // Pass null if not selected
        this.marksFrom, // Pass null if not entered
        this.marksTo // Pass null if not entered
    ) || []; // Create this API call

    // Map fetchedData to the structure needed by the table
    this.filteredMarksData = fetchedData.map((item: any) => ({
        rollNo: item.roll_no,
        bandalNo: item.bandal_no,
        centerCode: item.center_code,
        centerName: item.center_name,
        sheetChecker: item.sheet_checker_name, // Adjust field name based on API
        className: item.class_name,
        marks: item.marks,
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched filtered marks:', this.filteredMarksData);
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.filteredMarksData && this.filteredMarksData.length > 0) {
      console.log("Exporting data...", this.filteredMarksData);
      this.filteredMarksData.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.filteredMarksData, 'FilteredMarksReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'StudentMarksFilterReport'); // Adjust the ID of the report section
  }

  getFacultyName(id: any): string | null {
    const item = this.jsonlist.faculty.find(e => e.value === id);
    return item ? item.title : null;
  }

}
