import { TestBed } from '@angular/core/testing';

import { JsonListService } from './json-list.service';

describe('JsonListService', () => {
  let service: JsonListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JsonListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
