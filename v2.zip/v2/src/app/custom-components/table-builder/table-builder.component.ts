import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { FormsService } from 'src/app/constants/forms.service';

@Component({
  selector: 'app-table-builder',
  templateUrl: './table-builder.component.html',
  styleUrls: ['./table-builder.component.css']
})
export class TableBuilderComponent {
  @ViewChild('dt') dt: Table | undefined;
  @Output() editEvent = new EventEmitter();
  @Output() deleteEvent = new EventEmitter();
  @Output() fetchNextData = new EventEmitter();
  @Input() selectedtableData: any = [];
  @Input() searchFields: any = [];
  @Input() tableTitle: any = "Record List";
  @Input() totalRecords: any = 4;
  @Input() rows: any = 4;
  @Input() noofpages: any = 4;
  @Input() allowDelete: any = false;
  @Input() allowEdit: any = true;
@Input() width: any = '75rem';
@Input() height: any = '85rem';
  @Input() tableData: any = [

  ];
  @Input() filteredData: any = this.tableData;
  loading: any = false;
  viewDialog: boolean = false;
  selectedViewData: any = null;
  constructor(public formsService: FormsService) {
  }

  ngOnChanges() {
    this.filteredData = this.tableData;
  }

  ngOnInit() {
    this.filteredData = this.tableData;
  }
  @Input() tableDataHeader: any = [
  ];
  

  //  tableDataRows: any = this.formsService.studentTableData.tableDataRows;

  @Input() tableDataRows:any =[

  ]


  edit(pr: any) {
    this.editEvent.emit(pr);   
  }

  delete(pr: any) {
    this.deleteEvent.emit(pr);
  }


  
  openViewDialog(rowItem: any): void {
    this.selectedViewData = rowItem;
    this.viewDialog = true;
  }

  filterGlobal(event: Event) {

    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
    this.tableData = this.filterItems(this.filteredData, value);
  }
  onPageChagne(event: any) {
    this.loading = true;
   // console.log(event);
    var page = (event.first / event.rows) + 1;

    var nextPage = { page: page, limit: event.rows };
    this.fetchNextData.emit(nextPage);
    this.loading = false;
  }

  sortItems(items: any[], sortField: string, sortOrder: number): any[] {
    if (!sortField || sortOrder === 0) {
      return items;
    }

    return items.sort((a, b) => {
      const value1 = a[sortField];
      const value2 = b[sortField];
      const result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
      return sortOrder * result;
    });
  }
  filterItems(items: any[], filter: string): any[] {
    if (!filter) {
      return items;
    }
    return items.filter(item => {
      return this.searchFields.some((field: string | number) => {
        return item[field]?.toString().toLowerCase().includes(filter.toLowerCase());
      });
    });
  }
  onSort(event: any) {
   // console.log(event);
    this.loading = true;
    this.tableData = this.sortItems(this.tableData, event.field, event.order);

    this.loading = false;
  }

  applyFilters(items: any[], filters: any): any[] {
    if (!filters || Object.keys(filters).length === 0) {
      return items;
    }

    return items.filter(item => {
      // console.log("item=====qq=======", item);

      return Object.keys(filters).every(field => {
        return Object.keys(filters[field]).every(chfield => {
          // console.log("chfield============", chfield);
          // console.log("item[field]============");
          // console.log(filters[field][chfield]);
          const filterValue = filters[field][chfield].value??'';
          const filterMatchMode = filters[field][chfield].matchMode || 'contains';
          const fieldValue = item[chfield]? item[chfield].toString().toLowerCase() : '';

          if (filterMatchMode === 'contains') {
            return fieldValue.includes(filterValue.toLowerCase());
          }
          else if (filterMatchMode === 'startsWith') {
            return fieldValue.startsWith(filterValue.toLowerCase());
          }
          else if (filterMatchMode === 'endsWith') {
            return fieldValue.endsWith(filterValue.toLowerCase());
          }
          else if (filterMatchMode === 'equals') {
            return fieldValue === filterValue.toLowerCase();
          }
          else if (filterMatchMode === 'notEquals') {
            return fieldValue !== filterValue.toLowerCase();
          }
          else if (filterMatchMode === 'notContains') {
            return !fieldValue.includes(filterValue.toLowerCase());
          }
          else if(filterMatchMode==='nofilter'){
            return true;
          }
          return true; // Handle other match modes as needed
        });
      });
    });
  }


  onFilterChange(filter: any) {
   // console.log(filter);
    this.tableData = this.applyFilters(this.filteredData, filter);
  }
}
