import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { JsonListService } from '../constants/json-list.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {



  private isloggedIn: boolean;
  private token: string | undefined | null;

  constructor(private router: Router, private jsonListService: JsonListService) {
    this.isloggedIn = false;
  }
  isAuthenticated(): boolean {
    // Check for user authentication status
    return !!window.sessionStorage.getItem('token'); // Example, adjust according to your implementation
  }
  isUserLoggedIn(): boolean {
   // console.log('authService', this.isloggedIn);
    return this.isloggedIn;
  }
  setUserLoggedIn(isLoggedIn: boolean) {
    this.isloggedIn = isLoggedIn;
  }

  setCurrentRole(role: string | undefined | null) {

    if (role != undefined && role != null && role != '') {
      var userRole = this.jsonListService.userType.filter((roleData: any) => roleData.value == role)[0];
      window.sessionStorage.setItem('userRole', JSON.stringify(userRole));
    }
  }
  getUserRole() {
    var userrole = window.sessionStorage.getItem('userRole'); // 
    if (userrole != null) {
      return JSON.parse(userrole);
    }
    return null;
  }
  setToken(token: string | undefined | null) {
    this.token = token;
    if (this.token != undefined && this.token != null && this.token != '') {
      window.sessionStorage.setItem('token', this.token);
      this.setUserLoggedIn(true);
      this.router.navigate(['/']);
    }
  }
  getToken() {
    if (this.token == undefined || this.token == null || this.token == '') {
      var ttoken = window.sessionStorage.getItem('token') != null ? window.sessionStorage.getItem('token') : undefined;

      this.setToken(ttoken);
    }

    return this.token;
  }
  getUserAllowedPanels() {

    var userRole = this.getUserRole();
    if (userRole != null) {

      var allowedPanels = userRole.allowedPanels;
      return allowedPanels;
    }
    return null;
  }

  logoutUser(): void {
    this.isloggedIn = false;
    this.token = '';
    window.sessionStorage.removeItem('token');
    window.sessionStorage.removeItem('userRole');
    this.router.navigate(['/login'])

  }
}
