import { Injectable } from '@angular/core';
import { ApiService } from '../Services/api.service';

@Injectable({
  providedIn: 'root'
})
export class ApicontrollerService {

  constructor(private apiService: ApiService) { }

  async loginuser(logindata: any, url: string = 'common/registration') {
    const data = {
      "fn": "common_fn",
      "se": "lo_us",
      "data": logindata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async createClient(clientdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_up",
      "data": clientdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchdoctor(url: string = 'common',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_docs",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async createdoctor(doctordata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "si_up_doc",
      "data": doctordata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchSefesficdoctor(doctorrow_id:string ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_docs",
      "data": {row_id:doctorrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }




  async fetchPatients(url: string = 'common',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_pats",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }


  async AddPatients(Patientsdata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "si_up_pat",
      "data": Patientsdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchSefesficpatients(patientsrrow_id:string ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_pats",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async appointment(appointmentdata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_apt",
      "data": appointmentdata
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }


  


  async fetchappointment(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_apt_pats",
      "data": ""
    };

  //  console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
  //  console.log(resp);
    return resp;
  }



  async fetchappointmentdoctor(appdata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_apt_docs",
      "data": {pat_row_id:appdata}
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }



  async uploadmedia(mediadata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "up_media",
      "data": mediadata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

    async fetchmedia(mediadata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_media",
      "data": mediadata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }



  
  async updateAppointment(statusdata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "up_apt",
      "data": statusdata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

}