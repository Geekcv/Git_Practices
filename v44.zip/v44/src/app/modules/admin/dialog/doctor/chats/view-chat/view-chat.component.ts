import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-view-chat',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './view-chat.component.html',
  styleUrl: './view-chat.component.scss'
})
export class ViewChatComponent {

}
