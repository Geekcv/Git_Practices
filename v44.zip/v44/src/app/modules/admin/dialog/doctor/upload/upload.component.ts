import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-upload',
  imports: [ MatDialogModule,MatButtonModule
    ,MatIconModule,MatInputModule,MatCardModule,FormsModule
  ],
  templateUrl: './upload.component.html',
  styleUrl: './upload.component.scss'
})
export class UploadComponent {
  file_name: any;
  file_description: any;

  constructor(
    private dialogRef: MatDialogRef<UploadComponent> // Inject MatDialogRef
  ){
   
  }
  onFileSelected($event: any) {
    throw new Error('Method not implemented.');
    }

    exitbtn(){
      this.dialogRef.close();
    }

}
