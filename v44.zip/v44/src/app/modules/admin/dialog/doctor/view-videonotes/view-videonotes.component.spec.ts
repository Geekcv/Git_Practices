import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewVideonotesComponent } from './view-videonotes.component';

describe('ViewVideonotesComponent', () => {
  let component: ViewVideonotesComponent;
  let fixture: ComponentFixture<ViewVideonotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewVideonotesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewVideonotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
