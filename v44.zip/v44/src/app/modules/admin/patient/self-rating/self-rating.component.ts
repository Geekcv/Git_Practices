import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-self-rating',
  imports: [MatDividerModule,  MatInputModule,MatSelectModule,FormsModule,
    MatButtonModule
  ],
  templateUrl: './self-rating.component.html'
})
export class SelfRatingComponent {
  scale: string = '';

  // slot: string = '';
  availablescale: string[] = ['1', '2'];
}
