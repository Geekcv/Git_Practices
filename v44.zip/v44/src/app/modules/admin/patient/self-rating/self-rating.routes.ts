import { Routes } from '@angular/router';
import { SelfRatingComponent } from 'app/modules/admin/patient/self-rating/self-rating.component';

export default [
    {
        path: '',
        component: SelfRatingComponent,
    },
] as Routes;
