import { Routes } from '@angular/router';
import { TeleSessionsComponent } from 'app/modules/admin/patient/tele-sessions/tele-sessions.component';

export default [
    {
        path: '',
        component: TeleSessionsComponent,
    },
] as Routes;
