import { Routes } from '@angular/router';
import { VideoNotesComponent } from 'app/modules/admin/patient/video-notes/video-notes.component';

export default [
    {
        path: '',
        component: VideoNotesComponent,
    },
] as Routes;
