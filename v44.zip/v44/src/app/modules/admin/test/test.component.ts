import { Component } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { FormsModule } from '@angular/forms';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
}

@Component({
  selector: 'app-test',
  standalone: true,
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
  imports: [NgFor, NgIf, DragDropModule, CommonModule, FormsModule],
})
export class TestComponent {
  // Available form elements to drag
  availableElements: FormElement[] = [
    { type: 'text', label: 'Text Field', placeholder: 'Enter text' },
    { type: 'email', label: 'Email Field', placeholder: 'Enter email' },
    { type: 'password', label: 'Password Field', placeholder: 'Enter password' },
  ];

  // Dropped elements in the form builder
  formItems: FormElement[] = [];

  // Index of selected element for editing
  selectedElementIndex: number | null = null;

  // Dynamic styles for selected element
  fontSize: string = '16px';
  fontColor: string = '#000000';
  fontFamily: string = 'Arial';
  fontWeight: string = 'normal';
  borderStyle: string = 'solid';
  padding: string = '10px';
  bgColor: string = '#ffffff';

  /**
   * Handles the drag & drop event.
   */
  onDrop(event: CdkDragDrop<FormElement[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(this.formItems, event.previousIndex, event.currentIndex);
    } else {
      // Clone the dragged item so the original remains in the available list
      const clonedItem = { ...event.previousContainer.data[event.previousIndex] };
      this.formItems.splice(event.currentIndex, 0, clonedItem);
    }
  }

  /**
   * Select an element for editing.
   */
  selectElement(index: number) {
    this.selectedElementIndex = index;
    const selectedElement = this.formItems[index];
    this.fontSize = selectedElement.fontSize || '16px';
    this.fontColor = selectedElement.fontColor || '#000000';
    this.fontFamily = selectedElement.fontFamily || 'Arial';
    this.fontWeight = selectedElement.fontWeight || 'normal';
    this.borderStyle = selectedElement.borderStyle || 'solid';
    this.padding = selectedElement.padding || '10px';
    this.bgColor = selectedElement.bgColor || '#ffffff';
  }

  /**
   * Remove an element from the form.
   */
  removeElement(index: number) {
    this.formItems.splice(index, 1);
    if (this.selectedElementIndex === index) {
      this.selectedElementIndex = null;
    }
  }

  /**
   * Save the form (send data to backend).
   */
  saveForm() {
    console.log('Saved Form:', this.formItems);
    alert('Form saved successfully!');
  }

  /**
   * Validate label (required field)
   */
  isLabelInvalid(): boolean {
    return this.selectedElementIndex !== null &&
      !this.formItems[this.selectedElementIndex].label.trim();
  }

  /**
   * Validate placeholder (required field)
   */
  isPlaceholderInvalid(): boolean {
    return this.selectedElementIndex !== null &&
      !this.formItems[this.selectedElementIndex].placeholder?.trim();
  }

  /**
   * Validate all fields and mark as invalid if needed
   */
  validateLabel() {
    const label = this.formItems[this.selectedElementIndex!].label;
    if (!label || label.trim().length === 0) {
      this.formItems[this.selectedElementIndex!].invalid = true;
    } else {
      this.formItems[this.selectedElementIndex!].invalid = false;
    }
  }

  validatePlaceholder() {
    const placeholder = this.formItems[this.selectedElementIndex!].placeholder;
    if (!placeholder || placeholder.trim().length === 0) {
      this.formItems[this.selectedElementIndex!].invalid = true;
    } else {
      this.formItems[this.selectedElementIndex!].invalid = false;
    }
  }

  /**
   * Update the selected element's styles.
   */
  updateStyles() {
    if (this.selectedElementIndex !== null) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      selectedElement.fontSize = this.fontSize;
      selectedElement.fontColor = this.fontColor;
      selectedElement.fontFamily = this.fontFamily;
      selectedElement.fontWeight = this.fontWeight;
      selectedElement.borderStyle = this.borderStyle;
      selectedElement.padding = this.padding;
      selectedElement.bgColor = this.bgColor;
    }
  }
}
