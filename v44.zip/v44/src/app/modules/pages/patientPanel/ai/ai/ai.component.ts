import { CurrencyPipe, NgClass } from '@angular/common';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ViewEncapsulation,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatRippleModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoModule } from '@jsverse/transloco';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
// import { ProjectService } from 'app/modules/admin/dashboards/project/project.service';
import { ApexOptions, NgApexchartsModule } from 'ng-apexcharts';
import { Subject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-ai',
  imports: [
    TranslocoModule,
        MatIconModule,
        MatButtonModule,
        MatRippleModule,
        MatMenuModule,
        MatTabsModule,
        MatButtonToggleModule,
        NgApexchartsModule,
        MatTableModule,
  ],
  templateUrl: './ai.component.html'
})
export class AiComponent {

   patientsId: string;
    patientname: any;
  
  
      constructor(     
              private _matDialog: MatDialog,
                   private Apicontroller: ApicontrollerService,
                    private route: ActivatedRoute,
                           private router: Router,
              
            ) {      
            
            }
  
  
    ngOnInit(): void {
     
      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchSefesficpatients();  
    }
  
  
    async fetchSefesficpatients(): Promise<void> {
      try {
        const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
        this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
        console.log("patient----",response.data[0].patient_name)
  
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

}
