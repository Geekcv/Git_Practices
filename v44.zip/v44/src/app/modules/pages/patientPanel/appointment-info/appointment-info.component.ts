import { AsyncPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnInit, Pipe, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { EditappointmentInfoComponent } from 'app/modules/admin/dialog/editappointment-info/editappointment-info.component';

interface appointment {
  apt_row_id: string;
  date_of_apt: string;
  // date_of_req:string;
  pat_cont_no: string;
  patient_name: string;
  time_of_apt: string;
  // time_of_req:string;
  appointment_details: any;
}

@Component({
  selector: 'app-appointment-info',
  imports: [MatTableModule,
    MatIconModule],
  templateUrl: './appointment-info.component.html',
  //  encapsulation: ViewEncapsulation.None,
  //  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppointmentInfoComponent implements OnInit{
  patientsId!: string | null; // Holds the patientsId ID from the route

  appointmentdata: appointment[] = [];

  appointmentColumns: string[] = [
    'apt_row_id',
    'date_of_apt',
    // 'date_of_req',
    'pat_cont_no',
    'patient_name',
    'time_of_apt',
    // 'time_of_req'
    // 'actions'
    'appointment_status',
    'appointment_type'

  ];
  role: number;


  constructor(
    private route: ActivatedRoute,
    private apiController: ApicontrollerService,
    private router: Router,
        private _matDialog: MatDialog
    

  ) {
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number    
     
  }



  ngOnInit() {
    this.patientsId = this.route.snapshot.paramMap.get('id');
    // console.log("patientsId",this.patientsId) 
    this.viewappointment();

  }

  async viewappointment() {
    //console.log("patientsId",this.patientsId)
    const resp1 = await this.apiController.fetchappointmentdoctor(this.patientsId);
    this.appointmentdata = resp1.data || []
    console.log(" viewappointment ----", resp1)
  }


  editAppointment(appointment: appointment) {

    console.log(appointment.apt_row_id)

    // this.router.navigate(['appointmentdetails', appointment.apt_row_id, this.patientsId]);

     const dialogRef = this._matDialog.open(EditappointmentInfoComponent, {data: {appointment: appointment.apt_row_id}}
     );
  }


  refresh(){
    console.log("refresh----")
    this.viewappointment();
  }

}
