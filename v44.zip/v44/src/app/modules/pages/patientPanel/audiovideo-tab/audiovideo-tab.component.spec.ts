import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AudiovideoTabComponent } from './audiovideo-tab.component';

describe('AudiovideoTabComponent', () => {
  let component: AudiovideoTabComponent;
  let fixture: ComponentFixture<AudiovideoTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AudiovideoTabComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AudiovideoTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
