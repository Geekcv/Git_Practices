import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}


interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  row_id:string;
  }
  


@Component({
  selector: 'app-audiovideo-tab',
  imports: [
      MatButtonModule,
         MatIconModule,
        CommonModule,
        MatTableModule,
        MatFormFieldModule, MatSelectModule,FormsModule,MatGridListModule,MatCardModule
  ],
  templateUrl: './audiovideo-tab.component.html',
  styleUrl: './audiovideo-tab.component.scss'
})
export class AudiovideoTabComponent {

  patientsId!: string | null; // Holds the patientsId ID from the route
  
  patient: Patient[] = [];


  role: any = '';
        errorMessage: string = '';
        successMessage: string = '';
        config: any = config.apiBaseURL;
        
        userDetails: Doctor | null = null;
        patientDetails: Patient | null = null;
  
        uploadedFiles: { filePath: string; mediaType: string;sender:string; time:string }[] = [];
    Formate: string = '';
    // availableFormate: string[] = [ 'video/mp4', 'audio/mpeg' ];
  
    availableFormate: any[] = [
      {value :'video/mp4',show:'video'},
      {value:'audio/mpeg',show:'audio'},
  
    ];
  
    filename: string = '';
    filepath: string = '';
    mediatype: string = '';
  
    appointment:string ='';
    
      constructor(
        private route: ActivatedRoute,
        private router: Router,
        private apiController: ApicontrollerService,
            private http: HttpClient
        
      ) {
      this.patientsId = this.route.snapshot.paramMap.get('id');

        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
        this.loadUserDetails();
      }

      private loadUserDetails(): void {
        const userData = localStorage.getItem('userDeatials');
        if (userData) {
          if (this.role === 1) {
            this.userDetails = JSON.parse(userData);
          } else {
            this.patientDetails = JSON.parse(userData);
          }
        }
      }


      ngOnInit() {
        this.patientsId = this.route.snapshot.paramMap.get('id');
        // console.log("patientsId",this.patientsId)  
    
      }

  /** Handle File Selection & Upload */  


  onFileSelected(event: Event): void {
    //console.log("click this event 1")
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {

      const files = Array.from(input.files); // Handle multiple files

      files.forEach((files) => {
        let file = input.files[0];
        const formData = new FormData();
        formData.append('file', file);
  
     // console.log("click this event before api hit 2")
  
      this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: async (response: any) => {
          if (response) {
            this.filename = response.data.name;
            this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
            this.mediatype = response.data.mimetype;

            console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

            // const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
            // if (!rowId) {
            //   this.errorMessage = 'User ID not found.';
            //   return;
            // }
            // console.log("row_id",rowId)
            const data = {
              receiver_row_id: this.patientsId,
              file_name: this.filename,
              file_path: this.filepath,
              media_type: this.mediatype,
            };

            try {
   // console.log("click this event before upload api hit 2")

              const resp = await this.apiController.uploadmedia(data);
             console.log("Upload Response:", resp);
              this.successMessage = 'File uploaded successfully!';
    //console.log("click this event after upload api hit 3")
    input.value = ''
    
            } catch (error) {
              console.error("Upload failed:", error);
              this.errorMessage = 'File upload failed. Please try again.';
             
            }
          } else {
            this.errorMessage = 'Invalid server response.';
          }
        },
        error: (error) => {
       //   console.error('Upload failed:', error);
          this.errorMessage = 'File upload failed. Please try again.';
        },
      });
      
      
      })
    
   
    }
    else{
       console.warn('No files selected.');
    }
   }


   async fetchFiles() {

    // if (!this.patientDetails.row_id) {
    //   this.errorMessage = 'Patient ID missing.';
    //   return;
    // }

    // if (!this.Formate) {
    //   this.errorMessage = 'Please select a format.';
    //   return;
    // }

    const data = {
      pat_row_id: this.patientsId,
      media_type: this.Formate,
    };

    try {
      const resp = await this.apiController.fetchmedia(data);
      
      //console.log("resp---",resp)
      this.uploadedFiles = resp.data.map(file => ({
        filePath: file.media_link,
        mediaType: file.media_type,
        sender:file.sender,
        time:file.time
      }));

     // console.log("Fetched media:", this.uploadedFiles);
    } catch (error) {
      console.error("Fetch error:", error);
      this.errorMessage = "Failed to fetch media.";
    }
  }


}
