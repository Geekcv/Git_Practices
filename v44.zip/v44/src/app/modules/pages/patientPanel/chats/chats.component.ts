import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/chats/diagnosis/diagnosis.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/chats/formulation/formulation.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/chats/history/history.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/chats/rate/rate.component';
import { ViewChatComponent } from 'app/modules/admin/dialog/doctor/chats/view-chat/view-chat.component';


interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }

@Component({
  selector: 'app-chats',
  imports: [
    MatButtonModule,
    MatIconModule,
    MatTableModule, 
    MatInputModule,
    MatPaginatorModule
  ],
  templateUrl: './chats.component.html'
})
export class ChatsComponent {
  patient: any;
  patientname: any;
isclicked: any;

    
  

   constructor(     
          private _matDialog: MatDialog,
               private Apicontroller: ApicontrollerService,
                private route: ActivatedRoute,
                       private router: Router,
          
        ) {      
        
        }


        displayedColumns: string[] = [
          'user_row_id',
          'patient_name',
          // 'patient_email',
          // 'user_contact_number',
          // 'patient_gender',    
          
    
          'actions'
        ];

  selectedRow: any = null;

  patientsId!: string | null; // Holds the patientsId ID from the route

  isviewchatboxbtn:any = false;
  ishistorybtn:any = false;
  isformulationbtn:any = false;
  isdiagnosisbtn:any =false;
  isratebtn:any = false;

  selectedAction: string | null = null; // Store selected action separately


    viewchatboxbtn(Patient:any){
        // const dialogRef = this._matDialog.open(ViewChatComponent);
        this.patientname = Patient.patient_name;
        this.selectedRow = Patient;
        this.isviewchatboxbtn= true
        this.ishistorybtn= false
        this.isformulationbtn= false
        this.isdiagnosisbtn= false
        this.isratebtn= false
        this.selectedAction = 'view';

        
      }

      historybtn(Patient:any){
        // const dialogRef = this._matDialog.open(HistoryComponent);
        this.patientname = Patient.patient_age;
        this.selectedRow = Patient;
        this.ishistorybtn= true
        this.isviewchatboxbtn= false
        this.isformulationbtn= false
        this.isdiagnosisbtn= false
        this.isratebtn= false
        this.selectedAction = 'history';

       
      }

      formulationbtn(Patient:any){
        // const dialogRef = this._matDialog.open(FormulationComponent);
        this.patientname = Patient.patient_email;
        this.selectedRow = Patient;
        this.isformulationbtn= true
        this.isdiagnosisbtn= false
        this.isratebtn= false
        this.ishistorybtn= false
        this.isviewchatboxbtn= false
        
        this.selectedAction = 'formulation';

       
      }

      diagnosisbtn(Patient:any){
        // const dialogRef = this._matDialog.open(DiagnosisComponent);
        this.patientname = Patient.user_contact_number;
        this.selectedRow = Patient;
        this.isdiagnosisbtn= true
        this.isratebtn= false
        this.isformulationbtn= false
        this.ishistorybtn= false
        this.isviewchatboxbtn= false

        this.selectedAction = 'diagnosis';

       
      }

      ratebtn(Patient:any){
        // const dialogRef = this._matDialog.open(RateComponent);
        this.patientname = Patient.patient_gender;
        this.selectedRow = Patient;
        this.isratebtn= true
        this.isdiagnosisbtn= false
        this.isformulationbtn= false
        this.ishistorybtn= false
        this.isviewchatboxbtn= false

        this.selectedAction = 'rate';


      }



    ngOnInit(): void {
      this.Patients();

      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchSefesficpatients();  
    }


    async fetchSefesficpatients(): Promise<void> {
      try {
        const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
        this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
        console.log("patient----",response.data[0].patient_name)

      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

    page: number = 1; // Default to first page
    async Patients() {
      try {
        const resp = await this.Apicontroller.fetchPatients('common',this.page);
       //  console.log("Patients", resp);
        this.patient = resp.data as Patient[]; // Type assert to Doctor[]
      } catch (error) {
        console.error("Error fetching doctors:", error);
      }
  
    }


}
