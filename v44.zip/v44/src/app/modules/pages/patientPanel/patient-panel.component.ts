import { NgClass } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDrawer, MatSidenavModule } from '@angular/material/sidenav';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { Subject, takeUntil } from 'rxjs';
import { ClinicalComponent } from './clinical/clinical/clinical.component';
import { AiComponent } from './ai/ai/ai.component';
import { ProfileComponent } from './profile/profile/profile.component';
import { chats } from 'app/mock-api/apps/chat/data';
import { ChatsComponent } from './chats/chats.component';
import audioNotesRoutes from 'app/modules/admin/patient/audio-notes/audio-notes.routes';
import { AudioNotesComponent } from './audio-notes/audio-notes.component';
import { VideoNotesComponent } from './video-notes/video-notes.component';
import { TelepsychiatrySessionsComponent } from './telepsychiatry-sessions/telepsychiatry-sessions.component';
import { InpersonSessionComponent } from './inperson-session/inperson-session.component';
import { Router } from '@angular/router';
import { AppointmentInfoComponent } from './appointment-info/appointment-info.component';
import { AudiovideoTabComponent } from './audiovideo-tab/audiovideo-tab.component';


@Component({
  selector: 'app-patient-panel',
  // encapsulation: ViewEncapsulation.None,
  // changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatSidenavModule,
    MatButtonModule,
    MatIconModule,
    NgClass,
    ClinicalComponent,
    AiComponent,
    ProfileComponent,
    ChatsComponent,
    AudioNotesComponent,
    VideoNotesComponent,
    TelepsychiatrySessionsComponent,
    InpersonSessionComponent,
    AppointmentInfoComponent,
    AudiovideoTabComponent
  ],
  templateUrl: './patient-panel.component.html'
})
export class PatientPanelComponent {
  @ViewChild('drawer') drawer: MatDrawer;
  drawerMode: 'over' | 'side' = 'side';
  drawerOpened: boolean = true;
  panels: any[] = [];
  selectedPanel: string = 'clinical';
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  role: number;

  /**
   * Constructor
   */
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _fuseMediaWatcherService: FuseMediaWatcherService,
      private router: Router,
  ) {
    this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
   }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Setup available panels
    this.panels = [
      {
        id: 'clinical',
        // icon: 'heroicons_outline:user-circle',
        title: 'Clinical Summery',

      },
      {
        id: 'ai',
        // icon: 'heroicons_outline:lock-closed',
        title: 'AI Insights',

      },
      {
        id: 'chats',
        // icon: 'heroicons_outline:credit-card',
        title: 'Chats',

      },
      {
        id: 'profile',
        // icon: 'heroicons_outline:credit-card',
        title: 'Profile',

      },
      {
        id: 'audio-notes',
        // icon: 'heroicons_outline:credit-card',
        title: 'Audio Notes',

      },
      {
        id: 'videoNotes',
        // icon: 'heroicons_outline:credit-card',
        title: 'Video Notes',

      },
      {
        id: 'telepsychiatrySessions',
        // icon: 'heroicons_outline:credit-card',
        title: 'Telepsychiatry Sessions',

      },
      {
        id: 'inpersonSession',
        // icon: 'heroicons_outline:credit-card',
        title: 'Inperson Session',

      },
      {
        id: 'appointmentInfo',
        // icon: 'heroicons_outline:credit-card',
        title: 'Appointment Info',

      },
      {
        id: 'audiovideo',
        // icon: 'heroicons_outline:credit-card',
        title: 'Audio Video',

      },

    ];

    // Subscribe to media changes
    this._fuseMediaWatcherService.onMediaChange$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(({ matchingAliases }) => {
        // Set the drawerMode and drawerOpened
        if (matchingAliases.includes('lg')) {
          this.drawerMode = 'side';
          this.drawerOpened = true;
        } else {
          this.drawerMode = 'over';
          this.drawerOpened = false;
        }

        // Mark for check
        this._changeDetectorRef.markForCheck();
      });
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Navigate to the panel
   *
   * @param panel
   */
  goToPanel(panel: string): void {
    this.selectedPanel = panel;

    // Close the drawer on 'over' mode
    if (this.drawerMode === 'over') {
      this.drawer.close();
    }
  }

  /**
   * Get the details of the panel
   *
   * @param id
   */
  getPanelInfo(id: string): any {
    return this.panels.find((panel) => panel.id === id);
  }

  /**
   * Track by function for ngFor loops
   *
   * @param index
   * @param item
   */
  trackByFn(index: number, item: any): any {
    return item.id || index;
  }





  goback(){
    // console.log("click this button")
    this.router.navigate(['/Viewpatients'])
  }


  goback1(){
    // console.log("click this button")
    this.router.navigate(['/myappointment'])
  }
}
