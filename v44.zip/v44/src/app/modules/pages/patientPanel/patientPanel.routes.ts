import { Routes } from '@angular/router';
import { PatientPanelComponent } from 'app/modules/pages/patientPanel/patient-panel.component';

export default [
    {
        path: '',
        component: PatientPanelComponent,
    },
] as Routes;
