import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  row_id:string;
  }

  interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    doctor_name: string;
    user_contact_number: string;
    user_password: string;
    row_id: string;
  }
  

  
@Component({
  selector: 'app-profile',
  imports: [
     MatButtonModule,
         MatIconModule,
        CommonModule,
        MatTableModule,
        MatFormFieldModule, MatSelectModule,FormsModule,MatGridListModule,MatCardModule,
  ],
  templateUrl: './profile.component.html'
})
export class ProfileComponent {

  patient: Patient[] = [];
   
  displayedColumns: string[] = [
    // 'user_row_id',
    'patient_name',
    'patient_email',
    'user_contact_number',
    'patient_gender',
    'patient_age',
    'user_password'

  ];
  role: number;
  userDetails: Doctor | null = null;
      patientDetails: Patient | null = null;
  patientsId!: string | null; // Holds the patientsId ID from the route
  patientname: any;



   constructor(
        private route: ActivatedRoute,
        private router: Router,
        private apiController: ApicontrollerService,
        
      ) {
        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
      this.loadUserDetails();
      }
  
  
      /** Load User Details from localStorage */
    private loadUserDetails(): void {
      const userData = localStorage.getItem('userDeatials');
      if (userData) {
        if (this.role === 1) {
          this.userDetails = JSON.parse(userData);
        } else {
          this.patientDetails = JSON.parse(userData);
        }
      }
    }


    ngOnInit() {
      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchSefesficpatients();  

      this.fetchSefesficpatientsname();  
      
    }

    async fetchSefesficpatients(): Promise<void> {
      try {
        const response = await this.apiController.fetchSefesficpatients(this.patientsId);
        this.patient = response.data || []; // Ensure `data` exists in the API response
        // console.log("doctor----",this.patient)
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

    async fetchSefesficpatientsname(): Promise<void> {
      try {
        const response = await this.apiController.fetchSefesficpatients(this.patientsId);
        this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
        // console.log("doctor----",this.patient)
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }

}
