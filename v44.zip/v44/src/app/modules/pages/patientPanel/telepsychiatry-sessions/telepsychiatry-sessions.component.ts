import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/chats/diagnosis/diagnosis.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/chats/formulation/formulation.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/chats/history/history.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/chats/rate/rate.component';
import { ViewChatComponent } from 'app/modules/admin/dialog/doctor/chats/view-chat/view-chat.component';
import { UploadComponent } from 'app/modules/admin/dialog/doctor/upload/upload.component';

@Component({
  selector: 'app-telepsychiatry-sessions',
  imports: [MatButtonModule,MatIconModule,MatInputModule,MatCardModule],
  templateUrl: './telepsychiatry-sessions.component.html'
})
export class TelepsychiatrySessionsComponent {




  uploadbtn(){
        const dialogRef = this._matDialog.open(UploadComponent);

  }


   viewchatboxbtn(){
          const dialogRef = this._matDialog.open(ViewChatComponent);
        }
  
        historybtn(){
          const dialogRef = this._matDialog.open(HistoryComponent);
        }
  
        formulationbtn(){
          const dialogRef = this._matDialog.open(FormulationComponent);
        }
  
        diagnosisbtn(){
          const dialogRef = this._matDialog.open(DiagnosisComponent);
        }
  
        ratebtn(){
          const dialogRef = this._matDialog.open(RateComponent);
  
        }


         patientsId: string;
              patientname: any;
            
            
                constructor(     
                        private _matDialog: MatDialog,
                             private Apicontroller: ApicontrollerService,
                              private route: ActivatedRoute,
                                     private router: Router,
                        
                      ) {      
                      
                      }
            
                    
                  
            
              ngOnInit(): void {
               
                this.patientsId = this.route.snapshot.paramMap.get('id');
                // console.log("patientsId",this.patientsId)
            
                this.fetchSefesficpatients();  
              }
            
            
              async fetchSefesficpatients(): Promise<void> {
                try {
                  const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
                  this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
                  console.log("patient----",response.data[0].patient_name)
            
                } catch (error) {
                  // console.error('Error fetching clients:', error);
                }
              }

}
