import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { ViewVideonotesComponent } from 'app/modules/admin/dialog/doctor/view-videonotes/view-videonotes.component';

@Component({
  selector: 'app-video-notes',
  imports: [MatButtonModule,MatIconModule],
  templateUrl: './video-notes.component.html'
})
export class VideoNotesComponent { 
        
     


      patientsId: string;
          patientname: any;
        
        
            constructor(     
                    private _matDialog: MatDialog,
                         private Apicontroller: ApicontrollerService,
                          private route: ActivatedRoute,
                                 private router: Router,
                    
                  ) {      
                  
                  }
        
                 
        
          ngOnInit(): void {
           
            this.patientsId = this.route.snapshot.paramMap.get('id');
            // console.log("patientsId",this.patientsId)
        
            this.fetchSefesficpatients();  
          }
        
        
          async fetchSefesficpatients(): Promise<void> {
            try {
              const response = await this.Apicontroller.fetchSefesficpatients(this.patientsId);
              this.patientname = response.data[0].patient_name || []; // Ensure `data` exists in the API response
              console.log("patient----",response.data[0].patient_name)
        
            } catch (error) {
              // console.error('Error fetching clients:', error);
            }
          }

          viewvieodialogboxbtn(){
            const dialogRef = this._matDialog.open(ViewVideonotesComponent);
          }

}
