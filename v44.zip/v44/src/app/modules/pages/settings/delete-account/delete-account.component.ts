import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-account',
  imports: [],
  templateUrl: './delete-account.component.html',
})
export class DeleteAccountComponent {

}
