export const config = {
    // apiBaseURL : 'http://192.168.1.5:3000',
    // apiBaseURL : 'https://clientlogs.ftisindia.com',
    // apiBaseURL : 'http://localhost:3000',

    // apiBaseURL:'https://4bfd-223-185-15-178.ngrok-free.app'

    apiBaseURL: 'https://research.ftisindia.com',

    // cryptoSecret: "AmnVRMN38h",
};
