import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';


@Component({
  selector: 'app-addresearchers',
  imports: [
    //RouterLink,
   // FuseAlertComponent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
],
  templateUrl: './addresearchers.component.html'
})
export class AddresearchersComponent {
 @ViewChild('signUpNgForm') signUpNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signUpForm: UntypedFormGroup;
    showAlert: boolean = false;
    role :any ='';
    /**
     * Constructor
     */
    constructor(
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private Apicontroller: ApicontrollerService,private router: Router,
    ) {

      this.role=  localStorage.getItem('role')

      // console.log("my role",this.role)
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
        this.signUpForm = this._formBuilder.group({
          doctor_name: ['', Validators.required],
          doctor_email: ['', [Validators.required, Validators.email]],
          doctor_phone: ['', Validators.required],
          doctor_password: ['', Validators.required],
          doctor_type: ['', Validators.required],
          doctor_gender: ['', Validators.required],

            //company: [''],
            //agreements: ['', Validators.requiredTrue],
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign up
     */
    // async signUp() {
    //     // Do nothing if the form is invalid
    //     if (this.signUpForm.invalid) {
    //         console.log('signup form data',this.signUpForm.value)
    //         return;
    //     }

    //     // Disable the form
    //     // this.signUpForm.disable();

    //     // // Hide the alert
    //     // this.showAlert = false;

    //     //Sign up
    //     this._authService.signUp(this.signUpForm.value).subscribe(
    //         (response) => {
    //             // Navigate to the confirmation required page
    //             this._router.navigateByUrl('/confirmation-required');
    //         },
    //         (response) => {
    //             // Re-enable the form
    //             this.signUpForm.enable();

    //             // Reset the form
    //             this.signUpNgForm.resetForm();

    //             // Set the alert
    //             this.alert = {
    //                 type: 'error',
    //                 message: 'Something went wrong, please try again.',
    //             };

    //             // Show the alert
    //             this.showAlert = true;
    //         }
    //     );




    // }


    async addresearchers(){

      // console.log(this.signUpForm.value)

      const resp = await this.Apicontroller.createdoctor(this.signUpForm.value);


        // console.log("resp------------>",resp)

      // // console.log("resp",resp)
      // // Checking resp
      if (resp.status === 0) {
      
        // localStorage.setItem('token', resp.token)
        // console.log("register successfully ")
        this._router.navigate(['/Viewresearchers'])


      }else{
       // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
       console.log("error ")
      } 
    }

}
