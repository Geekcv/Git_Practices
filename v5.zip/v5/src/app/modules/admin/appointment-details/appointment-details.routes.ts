import { Routes } from '@angular/router';
import { AppointmentDetailsComponent } from 'app/modules/admin/appointment-details/appointment-details.component';

export default [
    {
        path: '',
        component: AppointmentDetailsComponent,
    },
] as Routes;
