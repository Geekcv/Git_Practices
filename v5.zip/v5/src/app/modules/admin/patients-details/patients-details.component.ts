import { AsyncPipe, CommonModule } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { config } from '../../../../../config';
import { HttpClient } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';


interface Patient {
 
patient_age: string;
patient_email: string;
patient_gender: string;
patient_name:string;
user_contact_number:string;
user_password:string;
row_id:string;
}


interface appointment{
  apt_row_id:string;
  date_of_apt:string;
  // date_of_req:string;
  pat_cont_no:string;
  patient_name:string;
  time_of_apt:string;
  // time_of_req:string;
  appointment_details:any;
}
 
interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}


@Component({
  selector: 'app-patients-details',
  imports:[   
    // AsyncPipe,
    MatButtonModule,
     MatIconModule,
    CommonModule,
    MatTableModule,
    MatFormFieldModule, MatSelectModule,FormsModule,MatGridListModule,MatCardModule,
   ],
  templateUrl: './patients-details.component.html'
})
export class PatientsDetailsComponent {

  patientsId!: string | null; // Holds the patientsId ID from the route
  
  patient: Patient[] = [];
   
    displayedColumns: string[] = [
      // 'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      'patient_gender'
    ];

    appointmentdata : appointment[] = [];

    appointmentColumns: string[] = [
      'apt_row_id',
      'date_of_apt',
      // 'date_of_req',
      'pat_cont_no',
      'patient_name',
      'time_of_apt',
      // 'time_of_req'
      // 'actions'
      'appointment_status',
      'appointment_type'

    ];
  

      role: any = '';
      errorMessage: string = '';
      successMessage: string = '';
      config: any = config.apiBaseURL;
      
      userDetails: Doctor | null = null;
      patientDetails: Patient | null = null;

      uploadedFiles: { filePath: string; mediaType: string;sender:string; time:string }[] = [];
  Formate: string = '';
  availableFormate: string[] = [ 'video/mp4', 'audio/mpeg' ];

  filename: string = '';
  filepath: string = '';
  mediatype: string = '';

  appointment:string ='';
  
    constructor(
      private route: ActivatedRoute,
      private router: Router,
      private apiController: ApicontrollerService,
      private authService: AuthService,
          private http: HttpClient
      
    ) {
      this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
    this.loadUserDetails();
    }


    /** Load User Details from localStorage */
  private loadUserDetails(): void {
    const userData = localStorage.getItem('userDeatials');
    if (userData) {
      if (this.role === 1) {
        this.userDetails = JSON.parse(userData);
      } else {
        this.patientDetails = JSON.parse(userData);
      }
    }
  }
  
    ngOnInit() {
      this.patientsId = this.route.snapshot.paramMap.get('id');
      // console.log("patientsId",this.patientsId)
  
      this.fetchdoctor();

      this.viewappointment();
  
    }
  
  
    async fetchdoctor(): Promise<void> {
      try {
        const response = await this.apiController.fetchSefesficpatients(this.patientsId);
        this.patient = response.data || []; // Ensure `data` exists in the API response
        // console.log("doctor----",this.patient)
      } catch (error) {
        // console.error('Error fetching clients:', error);
      }
    }
  
  
    goback(){
      // console.log("click this button")
      this.router.navigate(['/Viewpatients'])
    }


    goback1(){
      // console.log("click this button")
      this.router.navigate(['/myappointment'])
    }


    async viewappointment(){
      console.log("patientsId",this.patientsId)
      const resp1 = await this.apiController.fetchappointmentdoctor(this.patientsId);
      this.appointmentdata = resp1.data || []
          console.log(" viewappointment ----",resp1)
     }



   /** Handle File Selection & Upload */
   onFileSelected(event: Event): void {
    console.log("click this event 1")
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length === 0) 
      return;

      let file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);

    console.log("click this event before api hit 2")

      this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: async (response: any) => {
          if (response) {
            this.filename = response.data.name;
            this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
            this.mediatype = response.data.mimetype;

            console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

            // const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
            // if (!rowId) {
            //   this.errorMessage = 'User ID not found.';
            //   return;
            // }
            // console.log("row_id",rowId)
            const data = {
              receiver_row_id: this.patientsId,
              file_name: this.filename,
              file_path: this.filepath,
              media_type: this.mediatype,
            };

            try {
    console.log("click this event before upload api hit 2")

              const resp = await this.apiController.uploadmedia(data);
              console.log("Upload Response:", resp);
              this.successMessage = 'File uploaded successfully!';
    console.log("click this event after upload api hit 3")
    input.value = ''
    
            } catch (error) {
              console.error("Upload failed:", error);
              this.errorMessage = 'File upload failed. Please try again.';
             
            }
          } else {
            this.errorMessage = 'Invalid server response.';
          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
          this.errorMessage = 'File upload failed. Please try again.';
        },
      });
    }
  


     async fetchFiles() {

      // if (!this.patientDetails.row_id) {
      //   this.errorMessage = 'Patient ID missing.';
      //   return;
      // }
  
      // if (!this.Formate) {
      //   this.errorMessage = 'Please select a format.';
      //   return;
      // }
  
      const data = {
        pat_row_id: this.patientsId,
        media_type: this.Formate,
      };
  
      try {
        const resp = await this.apiController.fetchmedia(data);
        
        console.log("resp---",resp)
        this.uploadedFiles = resp.data.map(file => ({
          filePath: file.media_link,
          mediaType: file.media_type,
          sender:file.sender,
          time:file.time
        }));
  
        console.log("Fetched media:", this.uploadedFiles);
      } catch (error) {
        console.error("Fetch error:", error);
        this.errorMessage = "Failed to fetch media.";
      }
    }


    // editAppointment(): void {
    //   // Logic to handle the edit action for the selected appointment
    //   console.log('Edit appointment:');
    // }
  

    editAppointment(appointment: appointment) {
      this.router.navigate(['appointmentdetails',appointment.apt_row_id,this.patientsId]);
    }
  

}



