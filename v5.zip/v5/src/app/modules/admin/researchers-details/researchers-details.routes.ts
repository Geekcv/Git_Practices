import { Routes } from '@angular/router';
import { ResearchersDetailsComponent } from 'app/modules/admin/researchers-details/researchers-details.component';

export default [
    {
        path: '',
        component: ResearchersDetailsComponent,
    },
] as Routes;
