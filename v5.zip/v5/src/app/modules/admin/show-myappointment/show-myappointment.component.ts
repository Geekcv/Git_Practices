import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';

interface appointment{
  apt_row_id:string;
  date_of_apt:string;
  // date_of_req:string;
  doctor_name:string;
  user_contact_number:string;
  time_of_apt:string;
  // time_of_req:string;
  appointment_details:any;
  // appointment_details:{appt_status:any,appt_type:any,virtual_link:any};
}


interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  row_id:string;
  }
  



@Component({
  selector: 'app-show-myappointment',
  imports: [ MatButtonModule,
       MatIconModule,
      CommonModule,
      MatTableModule,],
  templateUrl: './show-myappointment.component.html'
})
export class ShowMyappointmentComponent {


  patientsId!: string | null; // Holds the patientsId ID from the route
  appointmentdata : appointment[] = [];

  // appointment_details: appointmentDetails[]=[]

  appointmentColumns: string[] = [
    'apt_row_id',
    'date_of_apt',
    // 'date_of_req',
    'doctor_name',
    'user_contact_number',
    'time_of_apt',
    // 'time_of_req',
    'appointment_status',

    'appointment_Type'
    

  ];

  patientDetails: Patient | null = null;
  
      constructor(
        private route: ActivatedRoute,
        private router: Router,
        private apiController: ApicontrollerService,
        private authService: AuthService
      ) {
        
      }
    
      ngOnInit() {
        // console.log("patientsId",this.patientsId)   
        this.patientsId = this.route.snapshot.paramMap.get('id');
        this.viewappointment();

        const userData = localStorage.getItem('userDeatials');
    
        this.patientDetails = JSON.parse(userData);
      
    }
    
      
    
    
      
    
    
  
      async viewappointment(){
        const resp1 = await this.apiController.fetchappointment();
        this.appointmentdata = resp1.data || []
            console.log(" viewappointment ----",resp1)
       }


       editAppointment(appointment: appointment) {
        this.router.navigate(['appointmentdetails',appointment.apt_row_id,this.patientDetails.row_id]);
      }
    
}
