// import { Component } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatSelectModule } from '@angular/material/select';
// import { ActivatedRoute, Router } from '@angular/router';
// import { ApicontrollerService } from 'app/controller/apicontroller.service';
// import { AuthService } from 'app/Services/auth.service';
// import { MatButtonModule } from '@angular/material/button';
// import { MatCardModule } from '@angular/material/card';
// import { HttpClient } from '@angular/common/http';
// import { config } from '../../../../../config';
// import { MatGridListModule } from '@angular/material/grid-list';


// interface Patient {
//   patient_age: string;
//   patient_email: string;
//   patient_gender: string;
//   patient_name: string;
//   user_contact_number: string;
//   user_password: string;
//   row_id: string;
// }

// interface Doctor {
//   doctor_email: string;
//   doctor_gender: string;
//   doctor_name: string;
//   user_contact_number: string;
//   user_password: string;
//   row_id: string;
// }

// @Component({
//   selector: 'app-uploadmedia',
//   imports: [MatFormFieldModule, MatSelectModule, FormsModule, MatButtonModule, MatCardModule,MatGridListModule],
//   templateUrl: './uploadmedia.component.html'
// })
// export class UploadmediaComponent {
//   role: number;
//   errorMessage: string = '';
//   successMessage: string = '';
//   config: string = config.apiBaseURL;

//   userDetails: Doctor | null = null;
//   patientDetails: Patient | null = null;

//   uploadedFiles: { filePath: string; mediaType: string,sender:string; time:string }[] = [];
//   Formate: string = '';
//   availableFormate: string[] = ['video/mp4', 'audio/mpeg'];

//   filename: string = '';
//   filepath: string = '';
//   mediatype: string = '';

//   constructor(
//     private route: ActivatedRoute,
//     private router: Router,
//     private apiController: ApicontrollerService,
//     private authService: AuthService,
//     private http: HttpClient
//   ) {
//     this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
//     this.loadUserDetails();
//   }

//   /** Load User Details from localStorage */
//   private loadUserDetails(): void {
//     const userData = localStorage.getItem('userDeatials');
//     if (userData) {
//       if (this.role === 1) {
//         this.userDetails = JSON.parse(userData);
//       } else {
//         this.patientDetails = JSON.parse(userData);
//       }
//     }
//   }

//   /** Handle File Selection & Upload */
//   onFileSelected(event: Event): void {
//     console.log("click this event 1")
//     const input = event.target as HTMLInputElement;
//     if (input.files && input.files.length === 0) 
//       return;

//       let file = input.files[0];
//       const formData = new FormData();
//       formData.append('file', file);

//     console.log("click this event before api hit 2")

//       this.http.post(`${this.config}/common/upload`, formData).subscribe({
//         next: async (response: any) => {
//           if (response) {
//             this.filename = response.data.name;
//             this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
//             this.mediatype = response.data.mimetype;

//             console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

//             const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
//             if (!rowId) {
//               this.errorMessage = 'User ID not found.';
//               return;
//             }
//             console.log("row_id",rowId)
//             const data = {
//               receiver_row_id: null,
//               file_name: this.filename,
//               file_path: this.filepath,
//               media_type: this.mediatype,
//             };

//             try {
//     console.log("click this event before upload api hit 2")

//               const resp = await this.apiController.uploadmedia(data);
//               console.log("Upload Response:", resp);
//               this.successMessage = 'File uploaded successfully!';
//     console.log("click this event after upload api hit 3")
//     input.value = ''

//             } catch (error) {
//               console.error("Upload failed:", error);
//               this.errorMessage = 'File upload failed. Please try again.';
             
//             }
//           } else {
//             this.errorMessage = 'Invalid server response.';
//           }
//         },
//         error: (error) => {
//           console.error('Upload failed:', error);
//           this.errorMessage = 'File upload failed. Please try again.';
//         },
//       });
//     }
  

//   /** Fetch Media from Server */
//   async fetchFiles() {


//     if(this.role==2){
//       this.patientDetails = JSON.parse(localStorage.getItem("userDeatials"));   


//     }else{
      
//       this.userDetails = JSON.parse(localStorage.getItem("userDeatials"));
      
//     }


//     const rowId = this.role === 1 ? this.userDetails?.row_id : this.patientDetails?.row_id;
//     if (!rowId) {
//       this.errorMessage = 'User ID not found.';
//       return;
//     }

//     const data = {
//       row_id: rowId,
//       media_type: this.Formate,
//     };

//     try {
//       const resp = await this.apiController.fetchmedia(data);
//       this.uploadedFiles = resp.data.map((file: any) => ({
//         filePath: file.media_link,
//         mediaType: file.media_type,
//         sender:file.sender,
//         time:file.time
//       }));

//       console.log("Fetched media:", this.uploadedFiles);
//     } catch (error) {
//       console.error("Fetch error:", error);
//       this.errorMessage = "Failed to fetch media.";
//     }
//   }
// }



import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../config';
import { MatGridListModule } from '@angular/material/grid-list';

interface UploadedFile {
  filePath: string;
  mediaType: string;
  time: string;
}

@Component({
  selector: 'app-uploadmedia',
  templateUrl: './uploadmedia.component.html',
    imports: [MatFormFieldModule, MatSelectModule, FormsModule, MatButtonModule, MatCardModule,MatGridListModule],

})
export class UploadmediaComponent {
  availableFormate: string[] = ['video/mp4', 'audio/mpeg'];
  Formate: string = '';

  uploadedFiles: UploadedFile[] = [];

  constructor() {
    this.loadFilesFromLocalStorage();
  }

  /** Handle File Selection & Upload */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const file = input.files[0];
    const fileURL = URL.createObjectURL(file);
    const fileType = file.type;

    if (!this.availableFormate.includes(fileType)) {
      alert('Invalid file type! Please upload audio or video.');
      return;
    }

    const newFile: UploadedFile = {
      filePath: fileURL,
      mediaType: fileType,
      time: new Date().toLocaleTimeString(),
    };

    this.uploadedFiles.push(newFile);
    this.saveFilesToLocalStorage();
  }

  /** Fetch Files from LocalStorage */
  fetchFiles(): void {
    this.loadFilesFromLocalStorage();
  }

  /** Load Files from LocalStorage */
  private loadFilesFromLocalStorage(): void {
    const savedFiles = localStorage.getItem('uploadedFiles');
    if (savedFiles) {
      this.uploadedFiles = JSON.parse(savedFiles);
    }
  }

  /** Save Files to LocalStorage */
  private saveFilesToLocalStorage(): void {
    localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles));
  }


  

}
