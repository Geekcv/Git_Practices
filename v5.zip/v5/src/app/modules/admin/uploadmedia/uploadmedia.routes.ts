import { Routes } from '@angular/router';
import { UploadmediaComponent } from 'app/modules/admin/uploadmedia/uploadmedia.component';

export default [
    {
        path     : '',
        component: UploadmediaComponent,
    },
] as Routes;
