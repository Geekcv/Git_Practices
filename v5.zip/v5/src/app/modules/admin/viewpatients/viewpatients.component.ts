import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';



interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }
   

@Component({
  selector: 'app-viewpatients',
imports: [MatTableModule, MatButtonModule,
  MatIconModule,MatInputModule],
  templateUrl: './viewpatients.component.html'
})
export class ViewpatientsComponent {

  patient: Patient[] = [];
   
    displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      'patient_gender'
    ];
  

   role :any ='';
   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.mydoctor();
   }
 
   async mydoctor() {
     try {
       const resp = await this.Apicontroller.fetchPatients();
      //  console.log("doctor", resp);
       this.patient = resp.data as Patient[]; // Type assert to Doctor[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 
 
   viewDoctorDetails(patient: Patient) {
     this.router.navigate(['patientDetails', patient.user_row_id]);
   }

}
