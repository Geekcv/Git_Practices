import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';



interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
}
 



@Component({
  selector: 'app-viewresearchers',
  imports: [MatTableModule,MatPaginatorModule,MatButtonModule,
    MatIconModule,
    MatInputModule],
  templateUrl: './viewresearchers.component.html',
})
export class ViewresearchersComponent { 
  role :any ='';
  // doctor: Doctor[] = [];

  doctor = new MatTableDataSource<Doctor>([]); // Use MatTableDataSource for pagination

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  
  displayedColumns: string[] = [
      'user_row_id', 
      'doctor_name', 
      'doctor_email', 
      'doctor_gender', 
      'user_contact_number'
  ];
  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router
  ) { 

    this.role=  localStorage.getItem('role')

    // console.log("my role",this.role)
  }

  ngOnInit(): void {
    this.mydoctor();
  }
  
  ngAfterViewInit() {
    this.doctor.paginator = this.paginator; // Set paginator after view init
  }

  page: number = 1; // Default to first page

  async mydoctor() {
    try {
      const resp = await this.Apicontroller.fetchdoctor('common',this.page);
      // console.log("doctor", resp);
      this.doctor.data = resp.data as Doctor[]; // Type assert to Doctor[]
    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

  filterByQuery(query: string): void {
    this.doctor.filter = query.trim().toLowerCase();
  }


  viewDoctorDetails(doctor: Doctor) {
    this.router.navigate(['researchersDetails', doctor.user_row_id]);
  }


  exportToExcel(): void {
    const dataToExport = this.doctor.data.map((doctor) => ({
      ID: doctor.user_row_id,
      Name: doctor.doctor_name,
      Email: doctor.doctor_email,
      Gender: doctor.doctor_gender,
      Contact: doctor.user_contact_number,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    saveAs(data, 'Doctors_List.xlsx');
  }

     
}
