import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';



@Component({
  selector: 'app-addpatients',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,MatSelectModule
  ],
  templateUrl: './addpatients.component.html'
})
export class AddpatientsComponent {
  @ViewChild('signUpNgForm') signUpNgForm: NgForm;

  alert: { type: FuseAlertType; message: string } = {
      type: 'success',
      message: '',
  };
  signUpForm: UntypedFormGroup;
  showAlert: boolean = false;
  role :any ='';

  genders: string[] = ['Male', 'Female', 'Other']; // List of genders
  ages:string[]=[
    '1','2','3','4','5','6','7','8','9','10',
    '11','12','13','14','15','16','17','18','19','20',
    '21','22','23','24','25','26','27','28','29','30',
    '31','32','33','34','35','36','37','38','39','40',
    '41','42','43','44','45','46','47','48','49','50',
    '51','52','53','54','55','56','57','58','59','60',
    '61','62','63','64','65','66','67','68','69','70',
    '71','72','73','74','75','76','77','78','79','80',    

  ]
  /**
   * Constructor
   */
  constructor(
      private _authService: AuthService,
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private Apicontroller: ApicontrollerService,private router: Router,
  ) {

  this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)

  }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
      // Create the form
      this.signUpForm = this._formBuilder.group({
        patient_name: ['', Validators.required],
        patient_email: ['', [Validators.required, Validators.email]],
        patient_number: ['', Validators.required],
        patient_password: ['', Validators.required],
        patient_age: ['', Validators.required],
        patient_gender: ['', Validators.required],

          //company: [''],
          //agreements: ['', Validators.requiredTrue],
      });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Sign up
   */
  // async signUp() {
  //     // Do nothing if the form is invalid
  //     if (this.signUpForm.invalid) {
  //         console.log('signup form data',this.signUpForm.value)
  //         return;
  //     }

  //     // Disable the form
  //     // this.signUpForm.disable();

  //     // // Hide the alert
  //     // this.showAlert = false;

  //     //Sign up
  //     this._authService.signUp(this.signUpForm.value).subscribe(
  //         (response) => {
  //             // Navigate to the confirmation required page
  //             this._router.navigateByUrl('/confirmation-required');
  //         },
  //         (response) => {
  //             // Re-enable the form
  //             this.signUpForm.enable();

  //             // Reset the form
  //             this.signUpNgForm.resetForm();

  //             // Set the alert
  //             this.alert = {
  //                 type: 'error',
  //                 message: 'Something went wrong, please try again.',
  //             };

  //             // Show the alert
  //             this.showAlert = true;
  //         }
  //     );




  // }


  async addresearchers(){

    console.log(this.signUpForm.value)

    const resp = await this.Apicontroller.AddPatients(this.signUpForm.value);


      // console.log("resp------------>",resp)

    // // console.log("resp",resp)
    // // Checking resp
    if (resp.status === 0) {
    
      this._router.navigate(['/Viewpatients'])


    }else{
     // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
     console.log("error ")
    } 
  }
}
