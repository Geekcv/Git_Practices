import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddoctordialogComponent } from './adddoctordialog.component';

describe('AdddoctordialogComponent', () => {
  let component: AdddoctordialogComponent;
  let fixture: ComponentFixture<AdddoctordialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdddoctordialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdddoctordialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
