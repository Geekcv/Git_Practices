import { Routes } from '@angular/router';
import { PatientsDetailsComponent } from 'app/modules/admin/patients-details/patients-details.component';

export default [
    {
        path: '',
        component: PatientsDetailsComponent,
    },
] as Routes;
