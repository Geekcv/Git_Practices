import { Routes } from '@angular/router';
import { ShowMyappointmentComponent } from 'app/modules/admin/show-myappointment/show-myappointment.component';

export default [
    {
        path: '',
        component: ShowMyappointmentComponent,
    },
] as Routes;
