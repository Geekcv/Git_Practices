import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }
   

@Component({
  selector: 'app-viewpatients',
imports: [MatTableModule, MatButtonModule,
  MatIconModule,MatInputModule,MatPaginatorModule],
  templateUrl: './viewpatients.component.html'
})
export class ViewpatientsComponent {

  // patient: Patient[] = [];
   
    displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      // 'patient_gender'
    ];
  

   role :any ='';

   isSearchActive = false;

    patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.mydoctor();
   }

   ngAfterViewInit() {
    this.patient.paginator = this.paginator; // Set paginator after view init
  }

   page: number = 1; // Default to first page
   async mydoctor() {
     try {
       const resp = await this.Apicontroller.fetchPatients('common',this.page);
      //  console.log("Patients", resp);
       this.patient.data = resp.data as Patient[]; // Type assert to Doctor[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 
 
   viewDoctorDetails(patient: Patient) {
     this.router.navigate(['patientDetails', patient.user_row_id]);
   }



  filterByQuery(query: string): void {
    if (query.trim()) {
      this.isSearchActive = true;
      this.patient.filter = query.trim().toLowerCase();
    } else {
      this.isSearchActive = false;
      // Reset `doctor` to original data
    }    
  }


  exportToExcel(): void {
      const dataToExport = this.patient.data.map((patient) => ({
        ID: patient.user_row_id,
        Name: patient.patient_name,
        Email: patient.patient_email,
        Gender: patient.patient_gender,
        Contact: patient.user_contact_number,
      }));
  
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
  
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      saveAs(data, 'Patients_List.xlsx');
    }
}
