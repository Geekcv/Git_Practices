import { Routes } from '@angular/router';
import { ViewpatientsComponent } from 'app/modules/admin/viewpatients/viewpatients.component';

export default [
    {
        path     : '',
        component: ViewpatientsComponent,
    },
] as Routes;
