const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { Pool } = require("pg");

const app = express();
const PORT = 3000;
const SECRET_KEY = "your_secret_key"; // Change this for security

app.use(cors());
app.use(bodyParser.json());

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "wpf_crud",
  password: "Admin",
  port: 5432,
});

// Middleware to Verify JWT Token
const authenticateToken = (req, res, next) => {
  const token = req.headers["authorization"];
  if (!token) return res.status(401).json({ message: "Unauthorized" });

  jwt.verify(token.split(" ")[1], SECRET_KEY, (err, user) => {
    if (err) return res.status(403).json({ message: "Invalid token" });
    req.user = user;
    next();
  });
};

// **REGISTER USER**
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const existingUser = await pool.query(
      "SELECT * FROM users WHERE email = $1",
      [email]
    );
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // const hashedPassword = await bcrypt.hash(password, 10);
    await pool.query(
      "INSERT INTO users (name, email, password) VALUES ($1, $2, $3)",
      [name, email, password]
    );

    res.json({ message: "User registered successfully" });
  } catch (err) {
    res.status(500).json({ message: "Internal server error" });
  }
});

// **LOGIN USER**
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const result = await pool.query(
    "SELECT * FROM users WHERE email = $1 and password = $2",
    [email, password]
  );

  if (result.rows.length === 0)
    return res.status(401).json({ message: "Invalid credentials" });

  const user = result.rows[0];
  // const isValid = await bcrypt.compare(password, user.password);
  // if (!isValid) return res.status(401).json({ message: "Invalid credentials" });

  const token = jwt.sign({ id: user.id, email: user.email }, SECRET_KEY, {
    expiresIn: "1h",
  });
  res.json({ token });
});

// **GET ALL CLIENTS (User-Specific)**
app.get("/clients", authenticateToken, async (req, res) => {
  const result = await pool.query("SELECT * FROM clients WHERE user_id = $1", [
    req.user.id,
  ]);
  res.json(result.rows);
});

// **ADD CLIENT**
app.post("/clients", authenticateToken, async (req, res) => {
  const { Name, Email, Phone } = req.body;

  try {
    await pool.query(
      "INSERT INTO clients (user_id, name, email, phone) VALUES ($1, $2, $3, $4)",
      [req.user.id, Name, Email, Phone]
    );
    res.json({ message: "Client added successfully" });
  } catch (err) {
    res.status(400).json({ message: "Client with this email already exists" });
  }
});

// **UPDATE CLIENT**
app.put("/clients/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { name, email, phone } = req.body;

  await pool.query(
    "UPDATE clients SET name = $1, email = $2, phone = $3 WHERE id = $4 AND user_id = $5",
    [name, email, phone, id, req.user.id]
  );
  res.json({ message: "Client updated successfully" });
});

// **DELETE CLIENT**
app.delete("/clients/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  await pool.query("DELETE FROM clients WHERE id = $1 AND user_id = $2", [
    id,
    req.user.id,
  ]);
  res.json({ message: "Client deleted successfully" });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

// users
// - id ineger
// - name varchar
// - email varchar
// - password

// - clients
// id integer
// user_id interger
// name
// email
// phone
